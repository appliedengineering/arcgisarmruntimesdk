// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file EncDisplaySettings.h

#ifndef QRT_EncDisplaySettings_H
#define QRT_EncDisplaySettings_H

// C++ API headers
#include "EncMarinerSettings.h"
#include "EncTextGroupVisibilitySettings.h"
#include "EncViewingGroupSettings.h"
#include "Object.h"

// STL headers
#include <memory>

namespace QRTImpl { class EncDisplaySettingsImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class EncDisplaySettings : public Object
  {
    Q_OBJECT

  public:
    ~EncDisplaySettings() override;

    EncMarinerSettings* marinerSettings() const;
    EncTextGroupVisibilitySettings* textGroupVisibilitySettings() const;
    EncViewingGroupSettings* viewingGroupSettings() const;

    /*! \internal */
    EncDisplaySettings(std::shared_ptr<QRTImpl::EncDisplaySettingsImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(EncDisplaySettings)
    std::shared_ptr<QRTImpl::EncDisplaySettingsImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_EncDisplaySettings_H
