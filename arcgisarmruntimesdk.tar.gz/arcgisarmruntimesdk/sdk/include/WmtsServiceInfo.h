// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file WmtsServiceInfo.h

#ifndef QRT_WmtsServiceInfo_H
#define QRT_WmtsServiceInfo_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "WmtsLayerInfo.h"
#include "WmtsTileMatrixSet.h"

// Qt headers
#include <QList>
#include <QUrl>

// STL headers
#include <memory>

namespace QRTImpl { class WmtsServiceInfoImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class WmtsServiceInfo
  {
  public:
    WmtsServiceInfo();
    WmtsServiceInfo(const WmtsServiceInfo& other);
    WmtsServiceInfo(WmtsServiceInfo&& other) noexcept;
    ~WmtsServiceInfo();
    WmtsServiceInfo& operator=(const WmtsServiceInfo& other);
    WmtsServiceInfo& operator=(WmtsServiceInfo&& other) noexcept;

    bool isEmpty() const;

    QString description() const;

    QStringList keywords() const;

    QList<WmtsLayerInfo> layerInfos() const;

    QList<WmtsTileMatrixSet> tileMatrixSets() const;

    QString title() const;

    QString version() const;

    /*!
       \internal
     */
    explicit WmtsServiceInfo(std::shared_ptr<QRTImpl::WmtsServiceInfoImpl> impl);

  private:
    std::shared_ptr<QRTImpl::WmtsServiceInfoImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_WmtsServiceInfo_H
