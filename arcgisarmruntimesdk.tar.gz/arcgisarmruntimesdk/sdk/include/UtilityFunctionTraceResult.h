// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityFunctionTraceResult.h

#ifndef QRT_UtilityFunctionTraceResult_H
#define QRT_UtilityFunctionTraceResult_H

// C++ API headers
#include "UtilityTraceResult.h"

namespace QRTImpl {
  class UtilityFunctionTraceResultImpl;
  class UtilityTraceFunctionOutputImpl;
}

namespace Esri {
namespace ArcGISRuntime {

class UtilityTraceFunctionOutput;

class UtilityFunctionTraceResult : public UtilityTraceResult
{
  Q_OBJECT
public:
  ~UtilityFunctionTraceResult() override;

  QList<UtilityTraceFunctionOutput*> functionOutputs() const;

  UtilityFunctionTraceResult(std::shared_ptr<QRTImpl::UtilityTraceResultImpl> impl, QObject* parent);

  std::shared_ptr<QRTImpl::UtilityFunctionTraceResultImpl> getImpl() const;

private:
  Q_DISABLE_COPY(UtilityFunctionTraceResult)
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityFunctionTraceResult_H
