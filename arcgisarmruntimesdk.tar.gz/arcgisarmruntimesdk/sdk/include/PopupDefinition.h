// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PopupDefinition.h

#ifndef QRT_PopupDefinition_H
#define QRT_PopupDefinition_H

// C++ API headers
#include "Deprecated.h"
#include "GeoElement.h"
#include "Object.h"
#include "PopupExpression.h"
#include "PopupField.h"
#include "PopupMedia.h"
#include "PopupRelatedFeaturesDefinition.h"
#include "PopupSource.h"
#include "PopupTypes.h"

// Qt headers
#include <QString>

namespace QRTImpl { class PopupDefinitionImpl; }

namespace Esri {
namespace ArcGISRuntime {

class PopupDefinition : public Object
{
  Q_OBJECT

public:
  explicit PopupDefinition(QObject* parent = nullptr);
  explicit PopupDefinition(GeoElement* geoElement, QObject* parent = nullptr);
  explicit PopupDefinition(PopupSource* popupSource, QObject* parent = nullptr);
  ~PopupDefinition() override;

  bool isDeleteAllowed() const;
  void setDeleteAllowed(bool deleteAllowed);

  bool isEditingAllowed() const;
  void setEditingAllowed(bool editingAllowed);

  bool isEditGeometryAllowed() const;
  void setEditGeometryAllowed(bool editGeometryAllowed);

  QString description() const;
  void setDescription(const QString& description);

  void setExpressions(const QList<PopupExpression*>& fields);
  QList<PopupExpression*> expressions() const;

  QList<PopupField*> fields() const;
  void setFields(const QList<PopupField*>& fields);

  QList<PopupMedia*> media() const;
  void setMedia(const QList<PopupMedia*>& media);

  bool isShowAttachments() const;
  void setShowAttachments(bool showAttachments);

  bool isShowEditSummary() const;
  void setShowEditSummary(bool showEditSummary);

  PopupRelatedFeaturesDefinition* relatedFeaturesDefinition() const;
  void setRelatedFeaturesDefinition(PopupRelatedFeaturesDefinition* relatedFeaturesDefinition);

  QRT_DEPRECATED bool isShowRelatedRecords() const;
  QRT_DEPRECATED void setShowRelatedRecords(bool showRelatedRecords);

  QString title() const;
  void setTitle(const QString& title);

  /*!
     \internal
   */
  PopupDefinition(std::shared_ptr<QRTImpl::PopupDefinitionImpl> impl, QObject* parent);
  std::shared_ptr<QRTImpl::PopupDefinitionImpl> getImpl() const;

private:
  Q_DISABLE_COPY(PopupDefinition)

  std::shared_ptr<QRTImpl::PopupDefinitionImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PopupDefinition_H
