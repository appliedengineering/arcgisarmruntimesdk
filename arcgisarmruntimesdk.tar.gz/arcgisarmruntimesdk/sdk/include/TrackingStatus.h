// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file TrackingStatus.h

#ifndef QRT_TrackingStatus_H
#define QRT_TrackingStatus_H

// C++ API headers
#include "Object.h"

// STL headers
#include <memory>

namespace QRTImpl { class TrackingStatusImpl; }

namespace Esri {
namespace ArcGISRuntime {

enum class DestinationStatus;

class TrackingProgress;
class Location;
class RouteResult;

class TrackingStatus : public Object
{
  Q_OBJECT

public:
  ~TrackingStatus() override;

  int currentManeuverIndex() const;

  TrackingProgress* destinationProgress() const;

  DestinationStatus destinationStatus() const;

  Location displayLocation() const;

  bool isRouteCalculating() const;

  Location locationOnRoute() const;

  TrackingProgress* maneuverProgress() const;

  int remainingDestinationCount() const;

  TrackingProgress* routeProgress() const;

  RouteResult routeResult() const;

  bool isOnRoute() const;

  bool isApproachingFinalDestination() const;

  QList<int> stopIndexesAtNextDestination() const;

  /*!
     \internal
   */
  TrackingStatus(std::shared_ptr<QRTImpl::TrackingStatusImpl> impl, QObject* parent);

private:
  Q_DISABLE_COPY(TrackingStatus)
  TrackingStatus() = delete;

  std::shared_ptr<QRTImpl::TrackingStatusImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_TrackingStatus_H
