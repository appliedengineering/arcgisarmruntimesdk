// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeoprocessingTask.h

#ifndef QRT_GeoprocessingTask_H
#define QRT_GeoprocessingTask_H

// C++ API headers
#include "GeoprocessingJob.h"
#include "GeoprocessingParameters.h"
#include "GeoprocessingTaskInfo.h"
#include "Loadable.h"
#include "Object.h"
#include "RemoteResource.h"
#include "TaskWatcher.h"

// Qt headers
#include <QUrl>

namespace QRTImpl { class GeoprocessingTaskImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class GeoprocessingTask : public Object, public Loadable, public RemoteResource
  {
    Q_OBJECT

  public:
    explicit GeoprocessingTask(const QUrl& url, QObject* parent = nullptr);
    GeoprocessingTask(const QUrl& url, Credential* credential, QObject* parent = nullptr);

    ~GeoprocessingTask() override;

    TaskWatcher createDefaultParameters();

    GeoprocessingTaskInfo geoprocessingTaskInfo() const;

    GeoprocessingJob* createJob(const GeoprocessingParameters& parameters);

    Error loadError() const override;
    LoadStatus loadStatus() const override;
    void cancelLoad() override;
    void load() override;
    void retryLoad() override;

    // RemoteResource interface methods
    QUrl url() const override;
    Credential* credential() const override;
    RequestConfiguration requestConfiguration() const override;
    void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

    /*!
       \internal
     */
    GeoprocessingTask(std::shared_ptr<QRTImpl::GeoprocessingTaskImpl> impl, QObject* parent);

  signals:
    void doneLoading(Esri::ArcGISRuntime::Error loadError);
    void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);
    void createDefaultParametersCompleted(QUuid taskId, const Esri::ArcGISRuntime::GeoprocessingParameters& parameters);

  private:
    std::shared_ptr<QRTImpl::GeoprocessingTaskImpl> m_impl;
    void connectSignals();
    Q_DISABLE_COPY(GeoprocessingTask)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeoprocessingTask_H
