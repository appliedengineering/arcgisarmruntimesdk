// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file FeatureServiceLayerIdInfo.h

#ifndef QRT_FeatureServiceLayerIdInfo_H
#define QRT_FeatureServiceLayerIdInfo_H

// C++ API headers
#include "IdInfo.h"

namespace QRTImpl { class FeatureServiceLayerIdInfoImpl; }

namespace Esri {
namespace ArcGISRuntime {

enum class ArcGISFeatureLayerInfoServiceType;
enum class GeometryType;

  class FeatureServiceLayerIdInfo : public IdInfo
  {
  public:
    FeatureServiceLayerIdInfo();

    FeatureServiceLayerIdInfo(const FeatureServiceLayerIdInfo& other);
    FeatureServiceLayerIdInfo(FeatureServiceLayerIdInfo&& other) noexcept;
    FeatureServiceLayerIdInfo(const IdInfo& other);

    FeatureServiceLayerIdInfo& operator=(const FeatureServiceLayerIdInfo& other);
    FeatureServiceLayerIdInfo& operator=(FeatureServiceLayerIdInfo&& other) noexcept;

    ~FeatureServiceLayerIdInfo() override;

    bool isValid() const;

    bool isDefaultVisibility() const;

    double maxScale() const;

    double minScale() const;

    ArcGISFeatureLayerInfoServiceType serviceType() const;

    GeometryType geometryType() const;

    /*! \internal */
    explicit FeatureServiceLayerIdInfo(std::shared_ptr<QRTImpl::FeatureServiceLayerIdInfoImpl> impl);
  };

  /*! \internal */
  template<> inline FeatureServiceLayerIdInfo
  idinfo_cast<FeatureServiceLayerIdInfo>(const IdInfo& idInfo)
  {
    return idInfo.idInfoType() == IdInfoType::FeatureServiceLayerIdInfo ? static_cast<FeatureServiceLayerIdInfo>(idInfo) : FeatureServiceLayerIdInfo();
  }

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_FeatureServiceLayerIdInfo_H
