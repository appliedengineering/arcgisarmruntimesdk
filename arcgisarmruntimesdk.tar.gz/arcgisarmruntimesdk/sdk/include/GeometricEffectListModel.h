// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeometricEffectListModel.h

#ifndef QRT_GeometricEffectListModel_H
#define QRT_GeometricEffectListModel_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "GeometricEffect.h"
#include "Iterable.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl { class GeometricEffectListImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class GeometricEffectListModel : public QAbstractListModel, public Iterable<GeometricEffect*>
  {
    Q_OBJECT

  public:

    enum GeometricEffectRoles
    {
      GeometricEffectTypeRole = Qt::UserRole + 1
    };

    ~GeometricEffectListModel() override;

    bool isEmpty() const;

    void clear();

    int size() const override;

    void append(GeometricEffect* geometricEffect);

    void insert(int index, GeometricEffect* geometricEffect);

    void removeAt(int index);

    void removeOne(GeometricEffect* geometricEffect);

    void move(int from, int to);

    GeometricEffect* at(int index) const override;

    bool contains(GeometricEffect* geometricEffect) const;

    int indexOf(GeometricEffect* geometricEffect) const;

    GeometricEffect* first() const;

    GeometricEffect* last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*! \internal */
    GeometricEffectListModel(std::shared_ptr<QRTImpl::GeometricEffectListImpl> impl, QObject* parent);

  signals:
    void geometricEffectAdded(int index);
    void geometricEffectRemoved(int index);
    void errorOccurred(Esri::ArcGISRuntime::Error error);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(GeometricEffectListModel)

    GeometricEffectListModel() = delete;
    void setupRoles();
    void connectSignals();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::GeometricEffectListImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeometricEffectListModel_H
