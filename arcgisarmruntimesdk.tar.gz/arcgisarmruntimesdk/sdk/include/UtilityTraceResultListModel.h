// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityTraceResultListModel.h

#ifndef QRT_UtilityTraceResultListModel_H
#define QRT_UtilityTraceResultListModel_H

// C++ API headers
#include "Iterable.h"

// Qt headers
#include <QAbstractListModel>
#include <QList>
#include <QUuid>

// STL headers
#include <memory>

namespace QRTImpl {
  class UtilityNetworkImpl;
  class UtilityTraceResultImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class UtilityTraceResult;

  class UtilityTraceResultListModel : public QAbstractListModel, public Iterable<UtilityTraceResult*>
  {
    Q_OBJECT

  public:
    ~UtilityTraceResultListModel() override;

    bool isEmpty() const;

    int size() const override;

    UtilityTraceResult* at(int index) const override;

    bool contains(UtilityTraceResult* result) const;

    int indexOf(UtilityTraceResult* result) const;

    UtilityTraceResult* first() const;

    UtilityTraceResult* last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    /*!
       \internal
     */
    UtilityTraceResultListModel(const std::shared_ptr<QRTImpl::UtilityNetworkImpl>& impl,
                                QObject* parent);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(UtilityTraceResultListModel)

    UtilityTraceResultListModel() = delete;
    void setupRoles();

    QHash<int, QByteArray> m_roles;
    QList<std::shared_ptr<QRTImpl::UtilityTraceResultImpl>> m_data;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityTraceResultListModel_H
