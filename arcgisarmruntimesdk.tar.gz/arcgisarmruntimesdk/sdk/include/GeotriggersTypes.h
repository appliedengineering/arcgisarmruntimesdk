// COPYRIGHT 2021 ESRI
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeotriggersTypes.h

#ifndef QRT_GeotriggersTypes_H
#define QRT_GeotriggersTypes_H

namespace Esri {
namespace ArcGISRuntime {

  enum class FenceEnterExitSpatialRelationship
  {
    EnterIntersectsAndExitDoesNotIntersect = 0,
    EnterContainsAndExitDoesNotContain = 1,
    EnterContainsAndExitDoesNotIntersect = 2
  };

  enum class FenceGeotriggerFeedAccuracyMode
  {
    UseGeometry = 0,
    UseGeometryWithAccuracy = 1
  };

  enum class FenceNotificationType
  {
    Entered = 0,
    Exited = 1
  };

  enum class FenceParametersType
  {
    GraphicFenceParameters = 0,
    FeatureFenceParameters = 1,
    GraphicsOverlayFenceParameters = 2
  };

  enum class FenceRuleType
  {
    Enter = 0,
    Exit = 1,
    EnterOrExit = 2
  };

  enum class GeotriggerFeedType
  {
    LocationGeotriggerFeed = 0
  };

  enum class GeotriggerMonitorStatus
  {
    Stopped = 0,
    Starting = 1,
    Started = 2,
    FailedToStart = 3
  };

  enum class GeotriggerNotificationInfoType
  {
    FenceGeotriggerNotificationInfo = 0
  };

  enum class GeotriggerType
  {
    FenceGeotrigger = 0
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeotriggersTypes_H

