// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file OrderBy.h

#ifndef QRT_OrderBy_H
#define QRT_OrderBy_H

// C++ API headers
#include "CoreTypes.h"

// Qt headers
#include <QString>

// STL headers
#include <memory>

namespace QRTImpl {
  class OrderByImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class OrderBy
  {
  public:
    OrderBy();
    OrderBy(const QString& fieldName, SortOrder sortOrder);
    OrderBy(const OrderBy& other);
    OrderBy(OrderBy&& other) noexcept;
    ~OrderBy();

    OrderBy& operator=(const OrderBy& other);
    OrderBy& operator=(OrderBy&& other) noexcept;

    bool isEmpty() const;
    void clear();

    QString fieldName() const;
    void setFieldName(const QString& fieldName);

    SortOrder sortOrder() const;
    void setSortOrder(SortOrder sortOrder);

    explicit OrderBy(const std::shared_ptr<QRTImpl::OrderByImpl>& impl);
    std::shared_ptr<QRTImpl::OrderByImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::OrderByImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_OrderBy_H
