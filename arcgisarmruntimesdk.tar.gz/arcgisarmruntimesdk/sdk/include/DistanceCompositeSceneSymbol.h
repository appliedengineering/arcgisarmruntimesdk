// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file DistanceCompositeSceneSymbol.h

#ifndef QRT_DistanceCompositeSceneSymbol_H
#define QRT_DistanceCompositeSceneSymbol_H

// C++ API headers
#include "Iterable.h"
#include "Symbol.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl {
  class DistanceCompositeSceneSymbolImpl;
  class DistanceSymbolRangeListImpl;
  class DistanceSymbolRangeImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class DistanceSymbolRange : public Object
  {
    Q_OBJECT

  public:
    DistanceSymbolRange(QObject* parent = nullptr);
    explicit DistanceSymbolRange(Symbol* symbol, QObject* parent = nullptr);
    DistanceSymbolRange(Symbol* symbol, double minDistance, double maxDistance, QObject* parent = nullptr);
    ~DistanceSymbolRange() override;

    double maxDistance() const;
    void setMaxDistance(double maxDistance);

    double minDistance() const;
    void setMinDistance(double minDistance);

    Symbol* symbol() const;
    void setSymbol(Symbol* symbol);

    /*!
      \internal
     */
    DistanceSymbolRange(std::shared_ptr<QRTImpl::DistanceSymbolRangeImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::DistanceSymbolRangeImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(DistanceSymbolRange)

    std::shared_ptr<QRTImpl::DistanceSymbolRangeImpl> m_impl;
  };

  class DistanceSymbolRangeListModel : public QAbstractListModel, public Iterable<DistanceSymbolRange*>
  {
    Q_OBJECT

  public:

    enum DistanceSymbolRangeRoles
    {
      DistanceSymbolRangeMaxDistanceRole = Qt::UserRole + 1,
      DistanceSymbolRangeMinDistanceRole = Qt::UserRole + 2,
      DistanceSymbolRangeSymbolRole = Qt::UserRole + 3
    };

    ~DistanceSymbolRangeListModel() override;

    bool isEmpty() const;

    void clear();

    int size() const override;

    void append(DistanceSymbolRange* distanceSymbolRange);

    void insert(int index, DistanceSymbolRange* distanceSymbolRange);

    void removeAt(int index);

    void removeOne(DistanceSymbolRange* distanceSymbolRange);

    void move(int from, int to);

    DistanceSymbolRange* at(int index) const override;

    bool contains(DistanceSymbolRange* distanceSymbolRange) const;

    int indexOf(DistanceSymbolRange* distanceSymbolRange) const;

    DistanceSymbolRange* first() const;

    DistanceSymbolRange* last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool setData(const QModelIndex& index, const QVariant& value, int role = Qt::EditRole) override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*!
      \internal
     */
    DistanceSymbolRangeListModel(std::shared_ptr<QRTImpl::DistanceSymbolRangeListImpl> impl, QObject* parent);

  signals:
    void distanceSymbolRangeAdded(int index);
    void distanceSymbolRangeRemoved(int index);
    void errorOccurred(Esri::ArcGISRuntime::Error error);

/*!
  \internal
 */
  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(DistanceSymbolRangeListModel)

    DistanceSymbolRangeListModel() = delete;
    void setupRoles();
    void connectSignals();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::DistanceSymbolRangeListImpl> m_impl;
  };

  class DistanceCompositeSceneSymbol : public Symbol
  {
    Q_OBJECT

  public:
    explicit DistanceCompositeSceneSymbol(QObject* parent = nullptr);
    ~DistanceCompositeSceneSymbol() override;

    DistanceSymbolRangeListModel* ranges() const;

    /*!
      \internal
     */
    DistanceCompositeSceneSymbol(std::shared_ptr<QRTImpl::SymbolImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(DistanceCompositeSceneSymbol)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_DistanceCompositeSceneSymbol_H
