// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityNetwork.h

#ifndef QRT_UtilityNetwork_H
#define QRT_UtilityNetwork_H

// C++ API headers
#include "Loadable.h"
#include "Object.h"
#include "RemoteResource.h"

// Qt headers
#include <QList>
#include <QUrl>
#include <QUuid>

namespace QRTImpl { class UtilityNetworkImpl; }

namespace Esri {
namespace ArcGISRuntime {

  enum class UtilityAssociationType;
  class ArcGISFeature;
  class ArcGISFeatureListModel;
  class Credential;
  class Envelope;
  class Geodatabase;
  class Map;
  class ServiceGeodatabase;
  class TaskWatcher;
  class UtilityNamedTraceConfiguration;
  class UtilityNamedTraceConfigurationQueryParameters;
  class UtilityAssociation;
  class UtilityTraceParameters;
  class UtilityNetworkDefinition;
  class UtilityElement;
  class UtilityAssetType;
  class UtilityTerminal;
  class UtilityTraceResultListModel;

  class UtilityNetwork : public Object, public Loadable, public RemoteResource
  {
    Q_OBJECT

  public:
    explicit UtilityNetwork(const QUrl& url, QObject* parent = nullptr);
    UtilityNetwork(const QUrl& url, Credential* credential, QObject* parent = nullptr);
    UtilityNetwork(const QUrl& url, Map* map, QObject* parent = nullptr);
    UtilityNetwork(const QUrl& url, Map* map, Credential* credential, QObject* parent = nullptr);
    ~UtilityNetwork() override;

    UtilityNetworkDefinition* definition() const;

    Geodatabase* geodatabase() const;

    QString name() const;

    ServiceGeodatabase* serviceGeodatabase() const;

    UtilityElement* createElementWithArcGISFeature(ArcGISFeature* arcGISFeature,
                                                   UtilityTerminal* terminal = nullptr,
                                                   QObject* parent = nullptr);

    UtilityElement* createElementWithAssetType(UtilityAssetType* assetType,
                                               const QUuid& globalId,
                                               UtilityTerminal* terminal = nullptr,
                                               QObject* parent = nullptr);

    TaskWatcher featuresForElements(const QList<UtilityElement*>& elements);

    ArcGISFeatureListModel* featuresForElementsResult() const;

    TaskWatcher trace(UtilityTraceParameters* traceParameters);

    UtilityTraceResultListModel* traceResult() const;

    TaskWatcher associations(UtilityElement* element);

    TaskWatcher associations(UtilityElement* element, UtilityAssociationType type);

    TaskWatcher associations(const Envelope& extent);

    TaskWatcher associations(const Envelope& extent, UtilityAssociationType type);

    TaskWatcher queryNamedTraceConfigurations(UtilityNamedTraceConfigurationQueryParameters* queryParameters);

    Error loadError() const override;
    LoadStatus loadStatus() const override;
    void cancelLoad() override;
    void load() override;
    void retryLoad() override;

    // RemoteResource interface methods
    QUrl url() const override;
    Credential* credential() const override;
    RequestConfiguration requestConfiguration() const override;
    void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

    /*!
       \internal
     */
    UtilityNetwork(std::shared_ptr<QRTImpl::UtilityNetworkImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::UtilityNetworkImpl> getImpl() const;

  signals:
    void traceCompleted(QUuid taskId);
    void featuresForElementsCompleted(QUuid taskId);
    void associationsCompleted(QUuid taskId, const QList<Esri::ArcGISRuntime::UtilityAssociation*>& associations);
    void doneLoading(Esri::ArcGISRuntime::Error loadError);
    void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);
    void queryNamedTraceConfigurationsCompleted(QUuid taskId, const QList<Esri::ArcGISRuntime::UtilityNamedTraceConfiguration*>& utilityNamedTraceConfigurationResults);

  private:
    Q_DISABLE_COPY(UtilityNetwork)
    UtilityNetwork() = delete;

    void connectSignals();

    mutable ArcGISFeatureListModel* m_featuresForElementsResult = nullptr;
    mutable UtilityTraceResultListModel* m_traceResult = nullptr;
    std::shared_ptr<QRTImpl::UtilityNetworkImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityNetwork_H
