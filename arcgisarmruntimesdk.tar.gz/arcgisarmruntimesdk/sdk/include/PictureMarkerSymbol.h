// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PictureMarkerSymbol.h

#ifndef QRT_PictureMarkerSymbol_H
#define QRT_PictureMarkerSymbol_H

// C++ API headers
#include "Credential.h"
#include "Loadable.h"
#include "MarkerSymbol.h"
#include "RemoteResource.h"

// Qt headers
#include <QImage>
#include <QUrl>

namespace QRTImpl { class PictureMarkerSymbolImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class MultilayerPointSymbol;

  class PictureMarkerSymbol : public MarkerSymbol, public Loadable, public RemoteResource
  {
    Q_OBJECT

  public:
    explicit PictureMarkerSymbol(const QImage& image, QObject* parent = nullptr);
    explicit PictureMarkerSymbol(const QUrl& url, QObject* parent = nullptr);
    PictureMarkerSymbol(const QUrl& url, Credential* credential, QObject* parent = nullptr);
    ~PictureMarkerSymbol() override;

    QImage image() const;

    float height() const;
    void setHeight(float height);

    float width() const;
    void setWidth(float width);

    float opacity() const;
    void setOpacity(float opacity);

    MultilayerPointSymbol* toMultilayerSymbol() const;

    // Loadable Interface methods
    Error loadError() const override;
    LoadStatus loadStatus() const override;
    void cancelLoad() override;
    void load() override;
    void retryLoad() override;

    // RemoteResource interface methods
    QUrl url() const override;
    Credential* credential() const override;
    RequestConfiguration requestConfiguration() const override;
    void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

    /*! \internal */
    PictureMarkerSymbol(std::shared_ptr<QRTImpl::SymbolImpl> impl, QObject* parent);

  signals:
    void doneLoading(Esri::ArcGISRuntime::Error loadError);
    void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

  private:
    Q_DISABLE_COPY(PictureMarkerSymbol)

    PictureMarkerSymbol() = delete;

    void connectSignals();
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PictureMarkerSymbol_H
