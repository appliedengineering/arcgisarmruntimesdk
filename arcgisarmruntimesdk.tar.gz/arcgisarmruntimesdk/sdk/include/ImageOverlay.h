// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ImageOverlay.h

#ifndef QRT_ImageOverlay_H
#define QRT_ImageOverlay_H

// C++ API headers
#include "Object.h"

namespace QRTImpl { class ImageOverlayImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class ImageFrame;
  class Envelope;

  class ImageOverlay : public Object
  {
    Q_OBJECT

  public:
    explicit ImageOverlay(QObject* parent = nullptr);
    explicit ImageOverlay(ImageFrame* imageFrame, QObject* parent = nullptr);
    ~ImageOverlay() override;

    bool isVisible() const;
    void setVisible(bool visible);

    float opacity() const;
    void setOpacity(float opacity);

    Envelope extent() const;

    ImageFrame* imageFrame() const;
    void setImageFrame(ImageFrame* imageFrame);

    /*! \internal */
    ImageOverlay(std::shared_ptr<QRTImpl::ImageOverlayImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::ImageOverlayImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(ImageOverlay)

    std::shared_ptr<QRTImpl::ImageOverlayImpl> m_impl;
  };
} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ImageOverlay_H
