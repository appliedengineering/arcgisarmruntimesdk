// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file OfflineMapSyncTask.h

#ifndef QRT_OfflineMapSyncTask_H
#define QRT_OfflineMapSyncTask_H

// C++ API headers
#include "Credential.h"
#include "Loadable.h"
#include "Map.h"
#include "Object.h"
#include "OfflineMapSyncJob.h"
#include "OfflineMapSyncParameters.h"
#include "RemoteResource.h"
#include "TaskWatcher.h"

namespace QRTImpl
{
  class OfflineMapSyncTaskImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class OfflineMapUpdateCapabilities;
  class OfflineMapUpdatesInfo;

  class OfflineMapSyncTask : public Object, public Loadable, public RemoteResource
  {
    Q_OBJECT

  public:
    explicit OfflineMapSyncTask(Map* map, QObject* parent = nullptr);
    QRT_DEPRECATED OfflineMapSyncTask(Map* map, Credential* credential, QObject* parent = nullptr);
    ~OfflineMapSyncTask() override;

    Map* map() const;
    OfflineMapUpdateCapabilities* updateCapabilities() const;

    TaskWatcher createDefaultOfflineMapSyncParameters();
    TaskWatcher checkForUpdates();

    OfflineMapSyncJob* syncOfflineMap(const OfflineMapSyncParameters& parameters);

    // Loadable Interface methods
    Error loadError() const override;
    LoadStatus loadStatus() const override;
    void cancelLoad() override;
    void load() override;
    void retryLoad() override;

    QUrl url() const override;

    // RemoteResource interface methods
    QRT_DEPRECATED Credential* credential() const override;
    QRT_DEPRECATED RequestConfiguration requestConfiguration() const override;
    QRT_DEPRECATED void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

  signals:
    void createDefaultOfflineMapSyncParametersCompleted(
        QUuid taskId, const Esri::ArcGISRuntime::OfflineMapSyncParameters& parameters);
    void checkForUpdatesCompleted(QUuid taskId, Esri::ArcGISRuntime::OfflineMapUpdatesInfo* updatesInfo);

    void doneLoading(Esri::ArcGISRuntime::Error loadError);
    void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

  private:
    OfflineMapSyncTask() = delete;
    Q_DISABLE_COPY(OfflineMapSyncTask)
    std::shared_ptr<QRTImpl::OfflineMapSyncTaskImpl> m_impl;

    void connectSignals_();
  };
}
}
#endif // QRT_OfflineMapSyncTask_H
