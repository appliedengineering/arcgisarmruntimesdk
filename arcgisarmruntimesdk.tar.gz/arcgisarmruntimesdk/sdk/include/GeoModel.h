// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeoModel.h

#ifndef QRT_GeoModel_H
#define QRT_GeoModel_H

// C++ API headers
#include "Basemap.h"
#include "BookmarkListModel.h"
#include "Deprecated.h"
#include "FeatureTableListModel.h"
#include "Item.h"
#include "JsonSerializable.h"
#include "LayerListModel.h"
#include "LegendInfoListModel.h"
#include "LoadSettings.h"
#include "Loadable.h"
#include "Object.h"
#include "OfflineSettings.h"
#include "Portal.h"
#include "PortalFolder.h"
#include "PortalItem.h"
#include "SpatialReference.h"
#include "TransportationNetworkDataset.h"
#include "Viewpoint.h"

namespace QRTImpl { class GeoModelImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class FloorManager;
  class GeoModelFloorDefinition;

  class GeoModel : public Object, public Loadable
  {
    Q_OBJECT
  public:
    ~GeoModel() override;

    Basemap* basemap() const;
    void setBasemap(Basemap* basemap);

    BasemapStyle basemapStyle() const;

    BookmarkListModel* bookmarks() const;

    GeoModelFloorDefinition* floorDefinition() const;
    void setFloorDefinition(GeoModelFloorDefinition* floorDefinition);

    FloorManager* floorManager() const;

    Viewpoint initialViewpoint() const;
    void setInitialViewpoint(const Viewpoint& viewpoint);

    Item* item() const;
    void setItem(Item* item);

    LoadSettings* loadSettings() const;
    void setLoadSettings(LoadSettings* loadSettings);

    LayerListModel* operationalLayers() const;

    SpatialReference spatialReference() const;

    FeatureTableListModel* tables() const;

    QList<TransportationNetworkDataset*> transportationNetworks() const;

    QString version() const;

    bool isAutoFetchLegendInfos() const;
    void setAutoFetchLegendInfos(bool autoFetchLegendInfos);

    LegendInfoListModel* legendInfos() const;

    // Loadable Interface methods
    void cancelLoad() override;
    void load() override;
    void retryLoad() override;
    Error loadError() const override;
    LoadStatus loadStatus() const override;

    explicit GeoModel(std::shared_ptr<QRTImpl::GeoModelImpl> impl, QObject* parent = nullptr);

    std::shared_ptr<QRTImpl::GeoModelImpl> getImpl() const;

  signals:
    void basemapChanged(Esri::ArcGISRuntime::Basemap* oldBasemap);

    void doneLoading(Esri::ArcGISRuntime::Error loadError);
    void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

  protected:
    std::shared_ptr<QRTImpl::GeoModelImpl> m_impl;

  private:
    Q_DISABLE_COPY(GeoModel)
    GeoModel() = delete;

    void connectSignals();
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeoModel_H
