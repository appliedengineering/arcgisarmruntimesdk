// COPYRIGHT 2021 ESRI
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file DimensionLayer.h

#ifndef QRT_DimensionLayer_H
#define QRT_DimensionLayer_H

// C++ API headers
#include "Layer.h"
#include "RemoteResource.h"

class QUrl;

namespace QRTImpl { class DimensionLayerImpl; }

namespace Esri {
  namespace ArcGISRuntime {

    class ArcGISFeatureTable;
    class Feature;
    class FeatureQueryResult;
    class Item;
    class QueryParameters;

    class DimensionLayer : public Layer, public RemoteResource
    {
      Q_OBJECT
    public:
      explicit DimensionLayer(ArcGISFeatureTable* featureTable, QObject* parent = nullptr);

      DimensionLayer(Item* item, qint64 serviceLayerId, QObject* parent = nullptr);

      explicit DimensionLayer(const QUrl& url, QObject* parent = nullptr);

      ~DimensionLayer() override;

      QString definitionExpression() const;
      void setDefinitionExpression(const QString& definitionExpression);

      ArcGISFeatureTable* featureTable() const;

      qint64 serviceLayerId() const;

      double referenceScale() const;

      void clearSelection();

      TaskWatcher selectedFeatures() const;

      void resetFeaturesVisible();

      void selectFeature(Feature* feature);

      void selectFeatures(const QList<Feature*>& features);

      TaskWatcher selectFeatures(const QueryParameters& parameters, SelectionMode mode);

      void setFeaturesVisible(const QList<Feature*>& features, bool visible);

      void setFeatureVisible(Feature* feature, bool visible);

      void unselectFeature(Feature* feature);

      void unselectFeatures(const QList<Feature*>& features);

      // RemoteResource interface methods
      Credential* credential() const override;
      QUrl url() const override;
      RequestConfiguration requestConfiguration() const override;
      void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

      DimensionLayer(std::shared_ptr<QRTImpl::LayerImpl> impl, QObject* parent);

    signals:
      void selectedFeaturesCompleted(QUuid taskId, Esri::ArcGISRuntime::FeatureQueryResult* featureQueryResult);
      void selectFeaturesCompleted(QUuid taskId, Esri::ArcGISRuntime::FeatureQueryResult* featureQueryResult);

    private:
      Q_DISABLE_COPY(DimensionLayer)
      void connectSignals_();

    };

  } // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_DimensionLayer_H
