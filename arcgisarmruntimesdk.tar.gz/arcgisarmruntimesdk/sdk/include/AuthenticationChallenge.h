// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file AuthenticationChallenge.h

#ifndef QRT_AuthenticationChallenge_H
#define QRT_AuthenticationChallenge_H

// C++ API headers
#include "CoreTypes.h"
#include "Credential.h"
#include "Error.h"
#include "Object.h"

// Qt headers
#include <QNetworkReply>
#include <QSslError>

namespace QRTImpl { class AuthenticationChallengeImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class AuthenticationChallenge : public Object
  {
    Q_OBJECT

    Q_ENUM(AuthenticationChallengeType)

    Q_PROPERTY(Esri::ArcGISRuntime::AuthenticationChallengeType authenticationChallengeType READ authenticationChallengeType CONSTANT)
    Q_PROPERTY(int failureCount READ failureCount CONSTANT)
    Q_PROPERTY(QUrl requestUrl READ requestUrl CONSTANT)
    Q_PROPERTY(QUrl authenticatingHost READ authenticatingHost CONSTANT)
    Q_PROPERTY(QUrl authorizationUrl READ authorizationUrl CONSTANT)

  public:
    ~AuthenticationChallenge() override;

    AuthenticationChallengeType authenticationChallengeType() const;

    int failureCount() const;

    Credential* proposedCredential() const;

    Error error() const;

    QUrl requestUrl() const;

    QUrl authenticatingHost() const;

    QUrl authorizationUrl() const;

    QList<QSslError> sslErrors() const;

    void continueWithCredential(Credential* credential);
    Q_INVOKABLE void continueWithUsernamePassword(const QString& username, const QString& password);
    Q_INVOKABLE void continueWithOAuthAuthorizationCode(const QString& oAuthAuthorizationCode);
    Q_INVOKABLE void continueWithClientCertificate(int clientCertificateIndex);
    Q_INVOKABLE void continueWithSslHandshake(bool trust, bool remember);
    Q_INVOKABLE void cancel();
    Q_INVOKABLE void cancelWithError(const QString& title, const QString& html);

    /*!
       \internal
     */
    AuthenticationChallenge(std::shared_ptr<QRTImpl::AuthenticationChallengeImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(AuthenticationChallenge)
    AuthenticationChallenge() = delete;

    std::shared_ptr<QRTImpl::AuthenticationChallengeImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_AuthenticationChallenge_H
