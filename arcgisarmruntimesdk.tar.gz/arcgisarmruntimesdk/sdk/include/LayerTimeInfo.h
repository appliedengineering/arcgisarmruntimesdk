// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LayerTimeInfo.h

#ifndef QRT_LayerTimeInfo_H
#define QRT_LayerTimeInfo_H

// C++ API headers
#include "Deprecated.h"
#include "ServiceTypes.h"
#include "TimeExtent.h"
#include "TimeReference.h"
#include "TimeValue.h"

namespace QRTImpl { class LayerTimeInfoImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class LayerTimeInfo
  {
  public:
    LayerTimeInfo();
    LayerTimeInfo(const LayerTimeInfo& other);
    LayerTimeInfo(LayerTimeInfo&& other) noexcept;
    ~LayerTimeInfo();

    LayerTimeInfo& operator=(const LayerTimeInfo& other);
    LayerTimeInfo& operator=(LayerTimeInfo&& other) noexcept;

    bool isEmpty() const;

    QString endTimeField() const;

    bool hasLiveData() const;

    QString startTimeField() const;

    QRT_DEPRECATED qint64 timeInterval() const;

    TimeReference timeReference() const;

    QRT_DEPRECATED TimeUnit timeUnit() const;

    QString trackIdField() const;

    TimeExtent timeExtent() const;

    TimeValue interval() const;

    explicit LayerTimeInfo(std::shared_ptr<QRTImpl::LayerTimeInfoImpl> impl);

  private:
    std::shared_ptr<QRTImpl::LayerTimeInfoImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LayerTimeInfo_H
