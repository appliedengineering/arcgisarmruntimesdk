// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LocalFeatureEditsResult.h

#ifndef QRT_LocalFeatureEditsResult_H
#define QRT_LocalFeatureEditsResult_H

// C++ API headers
#include "Object.h"

namespace QRTImpl { class LocalFeatureEditsResultImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class LocalFeatureEditIterator;
  class LocalFeatureEditsResult : public Object
  {
    Q_OBJECT

  public:
    ~LocalFeatureEditsResult() override;

    LocalFeatureEditIterator iterator() const;

    LocalFeatureEditsResult(std::shared_ptr<QRTImpl::LocalFeatureEditsResultImpl> impl, QObject* parent);

  private:
    LocalFeatureEditsResult() = delete;
    Q_DISABLE_COPY(LocalFeatureEditsResult)

    std::shared_ptr<QRTImpl::LocalFeatureEditsResultImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LocalFeatureEditsResult_H
