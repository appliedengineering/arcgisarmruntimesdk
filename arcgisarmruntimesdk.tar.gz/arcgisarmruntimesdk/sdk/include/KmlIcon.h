// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlIcon.h

#ifndef QRT_KmlIcon_H
#define QRT_KmlIcon_H

namespace QRTImpl { class KmlIconImpl; }

#include "Object.h"

class QUrl;

namespace Esri {
namespace ArcGISRuntime {

  enum class KmlRefreshMode;
  enum class KmlViewRefreshMode;

  class KmlIcon : public Object
  {
    Q_OBJECT

  public:

    explicit KmlIcon(const QUrl& url, QObject* parent = nullptr);

    quint64 refreshInterval() const;
    void setRefreshInterval(quint64 refreshInterval);

    KmlRefreshMode refreshMode() const;
    void setRefreshMode(KmlRefreshMode refreshMode);

    QUrl url() const;
    void setUrl(const QUrl& url);

    KmlViewRefreshMode viewRefreshMode() const;
    void setViewRefreshMode(KmlViewRefreshMode viewRefreshMode);

    quint64 viewRefreshTime() const;
    void setViewRefreshTime(quint64 viewRefreshTime);

    /*! \internal */
    KmlIcon(std::shared_ptr<QRTImpl::KmlIconImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::KmlIconImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(KmlIcon)
    std::shared_ptr<QRTImpl::KmlIconImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlIcon_H
