// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file Basemap.h

#ifndef QRT_Basemap_H
#define QRT_Basemap_H

// C++ API headers
#include "ApiKeyResource.h"
#include "Deprecated.h"
#include "Item.h"
#include "JsonSerializable.h"
#include "Layer.h"
#include "LayerListModel.h"
#include "Loadable.h"
#include "MapTypes.h"
#include "Object.h"
#include "RemoteResource.h"

// Qt headers
#include <QUrl>

namespace QRTImpl { class BasemapImpl; }

namespace Esri {
namespace ArcGISRuntime {

class Basemap : public Object,
                public ApiKeyResource,
                public Loadable,
                public JsonSerializable,
                public RemoteResource
{
  Q_OBJECT

public:
  explicit Basemap(QObject* parent = nullptr);

  explicit Basemap(Item* item, QObject* parent = nullptr);

  explicit Basemap(const QUrl& url, QObject* parent = nullptr);

  explicit Basemap(Layer* baseLayer, QObject* parent = nullptr);

  explicit Basemap(BasemapStyle basemapStyle, QObject* parent = nullptr);

  Basemap(BasemapStyle basemapStyle, Credential* credential, QObject* parent = nullptr);

  Basemap(const QList<Layer*>& baseLayers, const QList<Layer*>& referenceLayers, QObject* parent = nullptr);

  ~Basemap() override;

  LayerListModel* baseLayers() const;

  LayerListModel* referenceLayers() const;

  QString name() const;

  void setName(const QString& name);

  Item* item() const;

  static Basemap* nationalGeographic(QObject* parent = nullptr);

  static Basemap* oceans(QObject* parent = nullptr);

  static Basemap* openStreetMap(QObject* parent = nullptr);

  static Basemap* imagery(QObject* parent = nullptr);

  static Basemap* imageryWithLabels(QObject* parent = nullptr);

  static Basemap* lightGrayCanvas(QObject* parent = nullptr);

  static Basemap* streets(QObject* parent = nullptr);

  static Basemap* terrainWithLabels(QObject* parent = nullptr);

  static Basemap* topographic(QObject* parent = nullptr);

  static Basemap* imageryWithLabelsVector(QObject* parent = nullptr);

  static Basemap* streetsVector(QObject* parent = nullptr);

  static Basemap* topographicVector(QObject* parent = nullptr);

  static Basemap* terrainWithLabelsVector(QObject* parent = nullptr);

  static Basemap* lightGrayCanvasVector(QObject* parent = nullptr);

  static Basemap* navigationVector(QObject* parent = nullptr);

  static Basemap* streetsNightVector(QObject* parent = nullptr);

  static Basemap* streetsWithReliefVector(QObject* parent = nullptr);

  static Basemap* darkGrayCanvasVector(QObject* parent = nullptr);

  // APIKeyResource interface methods
  QString apiKey() const override;
  void setApiKey(const QString& apiKey) override;

  // JsonSerializable Interface methods
  static Basemap* fromJson(const QString& json, QObject* parent = nullptr);
  QString toJson() const override;
  QJsonObject unknownJson() const override;
  QJsonObject unsupportedJson() const override;

  // Loadable Interface methods
  Error loadError() const override;
  LoadStatus loadStatus() const override;
  void cancelLoad() override;
  void load() override;
  void retryLoad() override;

  // RemoteResource interface methods
  QUrl url() const override;
  Credential* credential() const override;
  RequestConfiguration requestConfiguration() const override;
  void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

  /*!
     \internal
   */
  Basemap(std::shared_ptr<QRTImpl::BasemapImpl> impl, QObject* parent);
  std::shared_ptr<QRTImpl::BasemapImpl> getImpl() const;

signals:
  void doneLoading(Esri::ArcGISRuntime::Error loadError);
  void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

private:
  Q_DISABLE_COPY(Basemap)

  void connectSignals();

  std::shared_ptr<QRTImpl::BasemapImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_Basemap_H
