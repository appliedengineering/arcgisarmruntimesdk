// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file DirectionManeuver.h

#ifndef QRT_DirectionManeuver_H
#define QRT_DirectionManeuver_H

// C++ API headers
#include "DirectionEvent.h"
#include "DirectionMessage.h"
#include "Geometry.h"
#include "NetworkAnalystTypes.h"

// Qt headers
#include <QDateTime>
#include <QList>
#include <QString>

// STL headers
#include <memory>

namespace QRTImpl { class DirectionManeuverImpl; }

namespace Esri {
namespace ArcGISRuntime {

class DirectionManeuver
{
public:
  DirectionManeuver();
  DirectionManeuver(const DirectionManeuver& other);
  DirectionManeuver(DirectionManeuver&& other) noexcept;
  ~DirectionManeuver();

  DirectionManeuver& operator=(const DirectionManeuver& other);
  DirectionManeuver& operator=(DirectionManeuver&& other) noexcept;

  bool isEmpty() const;

  QList<DirectionEvent> directionEvents() const;

  QString directionText() const;

  double duration() const;

  QDateTime estimatedArrivalTime() const;

  double estimatedArrivalTimeShift() const;

  Geometry geometry() const;

  double length() const;

  QList<DirectionMessage> maneuverMessages() const;

  DirectionManeuverType directionManeuverType() const;

  int fromLevel() const;

  int toLevel() const;

  /*!
     \internal
   */
  explicit DirectionManeuver(std::shared_ptr<QRTImpl::DirectionManeuverImpl> impl);

private:
  std::shared_ptr<QRTImpl::DirectionManeuverImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_DirectionManeuver_H
