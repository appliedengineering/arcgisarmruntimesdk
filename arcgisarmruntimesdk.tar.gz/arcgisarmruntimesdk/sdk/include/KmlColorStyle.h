// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlColorStyle.h

#ifndef QRT_KmlColorStyle_H
#define QRT_KmlColorStyle_H

// C++ API headers
#include "Object.h"

// Qt headers
#include <QColor>

namespace QRTImpl { class KmlColorStyleImpl; }

namespace Esri {
namespace ArcGISRuntime {

  enum class KmlColorMode;

  class KmlColorStyle : public Object
  {
    Q_OBJECT
  public:
    ~KmlColorStyle() override;

    QColor color() const;
    void setColor(const QColor& color);

    KmlColorMode colorMode() const;
    void setColorMode(KmlColorMode colorMode);

    /*! \internal */
    KmlColorStyle(std::shared_ptr<QRTImpl::KmlColorStyleImpl> impl,
                  QObject* parent);

  protected:
    Q_DISABLE_COPY(KmlColorStyle)
    std::shared_ptr<QRTImpl::KmlColorStyleImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlColorStyle_H
