// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file WfsFeatureTable.h

#ifndef QRT_WfsFeatureTable_H
#define QRT_WfsFeatureTable_H

// C++ API headers
#include "FeatureTable.h"
#include "RemoteResource.h"

namespace QRTImpl { class WfsFeatureTableImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class Credential;
  enum class FeatureRequestMode;
  class WfsLayerInfo;
  class SpatialReference;
  class QueryParameters;
  class FeatureQueryResult;

  class WfsFeatureTable : public FeatureTable, public RemoteResource
  {
    Q_OBJECT

  public:
    explicit WfsFeatureTable(const WfsLayerInfo& layerInfo, QObject* parent = nullptr);
    WfsFeatureTable(const WfsLayerInfo& layerInfo, Credential* credential, QObject* parent = nullptr);

    WfsFeatureTable(const QUrl& url, const QString& tableName, QObject* parent = nullptr);
    WfsFeatureTable(const QUrl& url, const QString& tableName, Credential* credential, QObject* parent = nullptr);

    ~WfsFeatureTable() override;

    OgcAxisOrder axisOrder() const;
    void setAxisOrder(OgcAxisOrder axisOrder);

    FeatureRequestMode featureRequestMode() const;
    void setFeatureRequestMode(FeatureRequestMode featureRequestMode);

    OgcAxisOrder filterAxisOrder() const;
    void setFilterAxisOrder(OgcAxisOrder filterAxisOrder);

    WfsLayerInfo layerInfo() const;

    SpatialReference preferredSpatialReference() const;
    void setPreferredSpatialReference(const SpatialReference& preferredSpatialReference);

    TaskWatcher populateFromService(const QueryParameters& parameters,
                                    bool clearCache, const QStringList& outfields);

    TaskWatcher populateFromService(const QString& xmlRequest, bool clearCache);

    // RemoteResource interface methods
    Credential* credential() const override;
    QUrl url() const override;
    RequestConfiguration requestConfiguration() const override;
    void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

    /*! \internal */
    WfsFeatureTable(std::shared_ptr<QRTImpl::WfsFeatureTableImpl> impl, QObject* parent);

  signals:
    void populateFromServiceCompleted(QUuid taskId, Esri::ArcGISRuntime::FeatureQueryResult* featureQueryResult);

  private:
    Q_DISABLE_COPY(WfsFeatureTable)

    void connectSignals();

    WfsFeatureTable() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_WfsFeatureTable_H
