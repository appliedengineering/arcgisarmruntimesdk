// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file WfsLayerInfo.h

#ifndef QRT_WfsLayerInfo_H
#define QRT_WfsLayerInfo_H

// Qt headers
#include <QList>

// STL headers
#include <memory>

namespace QRTImpl {
  class WfsLayerInfoImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class Envelope;
  class SpatialReference;

  class WfsLayerInfo
  {
  public:
    WfsLayerInfo();
    WfsLayerInfo(const WfsLayerInfo& other);
    WfsLayerInfo(WfsLayerInfo&& other) noexcept;
    ~WfsLayerInfo();

    WfsLayerInfo& operator=(const WfsLayerInfo& other);
    WfsLayerInfo& operator=(WfsLayerInfo&& other) noexcept;

    bool isEmpty() const;

    QString description() const;

    Envelope extent() const;

    QStringList keywords() const;

    QString name() const;

    QList<SpatialReference> spatialReferences() const;

    QString title() const;

    /*! \internal */
    explicit WfsLayerInfo(std::shared_ptr<QRTImpl::WfsLayerInfoImpl> impl);
    std::shared_ptr<QRTImpl::WfsLayerInfoImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::WfsLayerInfoImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_WfsLayerInfo_H
