// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlPlacemark.h

#ifndef QRT_KmlPlacemark_H
#define QRT_KmlPlacemark_H

// C++ API headers
#include "AttributeListModel.h"
#include "Deprecated.h"
#include "GeoElement.h"
#include "KmlGeometry.h"
#include "KmlNode.h"
#include "MapTypes.h"

namespace Esri {
namespace ArcGISRuntime {

  class KmlGeometryListModel;

  class KmlPlacemark : public KmlNode, public GeoElement
  {
    Q_OBJECT

  public:
    explicit KmlPlacemark(const KmlGeometry& kmlGeometry, QObject* parent = nullptr);
    ~KmlPlacemark() override;

    QRT_DEPRECATED QList<KmlGeometry> geometries() const;

    KmlGeometryListModel* geometriesListModel() const;

    KmlGraphicType graphicType() const;

    AttributeListModel* attributes() const override;

    Geometry geometry() const override;
    void setGeometry(const Geometry& geometry) override;

    /*! \internal */
    KmlPlacemark(std::shared_ptr<QRTImpl::KmlNodeImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::GeoElementImpl> iGetImpl() const override;

  signals:
    void geometryChanged();

  private:
    Q_DISABLE_COPY(KmlPlacemark)
    KmlPlacemark() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlPlacemark_H
