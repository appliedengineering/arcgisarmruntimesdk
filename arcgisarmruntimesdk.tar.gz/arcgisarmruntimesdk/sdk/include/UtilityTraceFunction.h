// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityTraceFunction.h

#ifndef QRT_UtilityTraceFunction_H
#define QRT_UtilityTraceFunction_H

// C++ API
#include "Object.h"

namespace QRTImpl { class UtilityTraceFunctionImpl; }

namespace Esri {
namespace ArcGISRuntime {

enum class UtilityTraceFunctionType;

class UtilityNetworkAttribute;
class UtilityTraceCondition;

class UtilityTraceFunction : public Object
{
  Q_OBJECT
public:
  UtilityTraceFunction(UtilityTraceFunctionType functionType,
                       UtilityNetworkAttribute* networkAttribute,
                       QObject* parent = nullptr);
  UtilityTraceFunction(UtilityTraceFunctionType functionType,
                       UtilityNetworkAttribute* networkAttribute,
                       UtilityTraceCondition* condition,
                       QObject* parent = nullptr);

  ~UtilityTraceFunction() override;

  UtilityTraceCondition* condition() const;
  void setCondition(UtilityTraceCondition* condition);

  UtilityTraceFunctionType functionType() const;

  UtilityNetworkAttribute* networkAttribute() const;

  /*! \internal */
  UtilityTraceFunction(std::shared_ptr<QRTImpl::UtilityTraceFunctionImpl> impl, QObject* parent);
  std::shared_ptr<QRTImpl::UtilityTraceFunctionImpl> getImpl() const;

private:
  std::shared_ptr<QRTImpl::UtilityTraceFunctionImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityTraceFunction_H
