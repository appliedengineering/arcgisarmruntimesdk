// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlIconStyle.h

#ifndef QRT_KmlIconStyle_H
#define QRT_KmlIconStyle_H

namespace QRTImpl { class KmlIconStyleImpl; }

#include "KmlColorStyle.h"

namespace Esri {
namespace ArcGISRuntime {

  class KmlIcon;
  class KmlImageCoordinate;

  class KmlIconStyle : public KmlColorStyle
  {
    Q_OBJECT

  public:

    KmlIconStyle(KmlIcon* icon, double scale, QObject* parent = nullptr);

    ~KmlIconStyle() override;

    double heading() const;
    void setHeading(double heading);

    KmlImageCoordinate* hotSpot() const;
    void setHotSpot(KmlImageCoordinate* hotSpot);

    KmlIcon* icon() const;
    void setIcon(KmlIcon* icon);

    double scale() const;
    void setScale(double scale);

    /*! \internal */
    KmlIconStyle(std::shared_ptr<QRTImpl::KmlIconStyleImpl> impl,
                 QObject* parent);
    std::shared_ptr<QRTImpl::KmlIconStyleImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(KmlIconStyle)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlIconStyle_H
