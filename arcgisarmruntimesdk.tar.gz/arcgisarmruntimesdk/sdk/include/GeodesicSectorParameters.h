// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeodesicSectorParameters.h

#ifndef QRT_GeodesicSectorParameters_H
#define QRT_GeodesicSectorParameters_H

// C++ API headers
#include "AngularUnit.h"
#include "LinearUnit.h"
#include "Point.h"

namespace QRTImpl {
  class GeodesicSectorParametersImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class GeodesicSectorParameters
  {
  public:
    GeodesicSectorParameters();
    GeodesicSectorParameters(const Point& center,
                             double semiAxis1Length,
                             double semiAxis2Length,
                             double sectorAngle,
                             double startDirection);
    GeodesicSectorParameters(double axisDirection,
                             const AngularUnit& angularUnit,
                             const Point& center,
                             const LinearUnit& linearUnit,
                             unsigned int maxPointCount,
                             double maxSegmentLength,
                             GeometryType geometryType,
                             double sectorAngle,
                             double semiAxis1Length,
                             double semiAxis2Length,
                             double startDirection);
    GeodesicSectorParameters(const GeodesicSectorParameters& other);
    GeodesicSectorParameters(GeodesicSectorParameters&& other) noexcept;
    GeodesicSectorParameters& operator=(const GeodesicSectorParameters& other);
    GeodesicSectorParameters& operator=(GeodesicSectorParameters&& other) noexcept;
    ~GeodesicSectorParameters();

    AngularUnit angularUnit() const;
    void setAngularUnit(const AngularUnit& angularUnit);
    double axisDirection() const;
    void setAxisDirection(double direction);
    Point center() const;
    void setCenter(const Point& center);
    GeometryType geometryType() const;
    void setGeometryType(GeometryType type);
    LinearUnit linearUnit() const;
    void setLinearUnit(const LinearUnit& linearUnit);
    unsigned int maxPointCount() const;
    void setMaxPointCount(unsigned int count);
    double maxSegmentLength() const;
    void setMaxSegmentLength(double length);
    double sectorAngle() const;
    void setSectorAngle(double angle);
    double semiAxis1Length() const;
    void setSemiAxis1Length(double length);
    double semiAxis2Length() const;
    void setSemiAxis2Length(double length);
    double startDirection() const;
    void setStartDirection(double direction);

    /*!
       \internal
    */
    std::shared_ptr<QRTImpl::GeodesicSectorParametersImpl> getImpl() const;
    explicit GeodesicSectorParameters(std::shared_ptr<QRTImpl::GeodesicSectorParametersImpl> impl);

  private:
    std::shared_ptr<QRTImpl::GeodesicSectorParametersImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeodesicSectorParameters_H
