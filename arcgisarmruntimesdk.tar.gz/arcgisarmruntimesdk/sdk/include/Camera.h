// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file Camera.h

#ifndef QRT_Camera_H
#define QRT_Camera_H

// C++ API headers
#include "Point.h"

namespace QRTImpl { class CameraImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class TransformationMatrix;

  class Camera
  {
  public:
    Camera();
    Camera(double latitude, double longitude, double altitude, double heading, double pitch, double roll);
    Camera(const Point& locationPoint, double heading, double pitch, double roll);
    Camera(const Point& lookAtPoint, double distance, double heading, double pitch, double roll);
    explicit Camera(TransformationMatrix* transformationMatrix);
    Camera(const Camera& other);
    Camera(Camera&& other) noexcept;
    ~Camera();

    Camera& operator=(const Camera& other);
    Camera& operator=(Camera&& other) noexcept;

    bool operator==(const Camera& other) const;

    bool isEmpty() const;

    double heading() const;
    Point location() const;
    double pitch() const;
    double roll() const;

    Camera elevate(double deltaAltitude) const;
    Camera moveForward(double distance) const;
    Camera moveTo(const Point& location) const;
    Camera moveToward(const Point& targetPoint, double distance) const;
    Camera rotateAround(const Point& targetPoint, double deltaHeading, double deltaPitch, double deltaRoll) const;
    Camera rotateTo(double heading, double pitch, double roll) const;
    Camera zoomToward(const Point& targetPoint, double factor) const;

    TransformationMatrix* transformationMatrix(QObject* parent = nullptr) const;

    /*!
       \internal
     */
    explicit Camera(std::shared_ptr<QRTImpl::CameraImpl> impl);
    std::shared_ptr<QRTImpl::CameraImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::CameraImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_Camera_H
