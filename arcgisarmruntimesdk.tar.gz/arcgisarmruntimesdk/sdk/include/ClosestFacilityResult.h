// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ClosestFacilityResult.h

#ifndef QRT_ClosestFacilityResult_H
#define QRT_ClosestFacilityResult_H

// C++ API headers
#include "ClosestFacilityRoute.h"
#include "Facility.h"
#include "Incident.h"
#include "PointBarrier.h"
#include "PolygonBarrier.h"
#include "PolylineBarrier.h"

// Qt headers
#include <QDateTime>
#include <QList>
#include <QStringList>

// STL headers
#include <memory>

namespace QRTImpl { class ClosestFacilityResultImpl; }

namespace Esri {
namespace ArcGISRuntime {

class ClosestFacilityResult
{
public:
  ClosestFacilityResult();
  ClosestFacilityResult(const ClosestFacilityResult& other);
  ClosestFacilityResult(ClosestFacilityResult&& other) noexcept;
  ~ClosestFacilityResult();

  ClosestFacilityResult& operator=(const ClosestFacilityResult& other);
  ClosestFacilityResult& operator=(ClosestFacilityResult&& other) noexcept;

  bool isEmpty() const;

  QList<Facility> facilities() const;

  QList<Incident> incidents() const;

  QList<PointBarrier> pointBarriers() const;

  QList<PolygonBarrier> polygonBarriers() const;

  QList<PolylineBarrier> polylineBarriers() const;

  QStringList messages() const;

  QString directionsLanguage() const;

  ClosestFacilityRoute route(int facilityIndex, int incidentIndex) const;

  QList<double> facilityCosts(const QString& attributeName, int facilityIndex) const;

  QList<int> rankedFacilityIndexes(int incidentIndex) const;

  /*!
     \internal
   */
  explicit ClosestFacilityResult(std::shared_ptr<QRTImpl::ClosestFacilityResultImpl> impl);

private:
  std::shared_ptr<QRTImpl::ClosestFacilityResultImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::ClosestFacilityResult)

#endif // QRT_ClosestFacilityResult_H
