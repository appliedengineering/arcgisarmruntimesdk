// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlGeometryListModel.h

#ifndef QRT_KmlGeometryListModel_H
#define QRT_KmlGeometryListModel_H

// C++ API headers
#include "Error.h"
#include "Iterable.h"
#include "KmlGeometry.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl { class KmlGeometryListImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class KmlGeometryListModel : public QAbstractListModel,
                               public Iterable<KmlGeometry>
  {
    Q_OBJECT

  public:

    enum KmlGeometryRoles
    {
      KmlGeometryGeometryRole = Qt::UserRole + 1,
      KmlGeometryTessellatedRole,
      KmlGeometryExtrudedRole,
      KmlGeometryKmlAltitudeModeRole,
      KmlGeometryKmlGeometryTypeRole,
      KmlGeometryGeometryJsonRole
    };

    ~KmlGeometryListModel() override;

    bool isEmpty() const;

    void clear();

    int size() const override;

    void append(const KmlGeometry& kmlGeometry);

    void insert(int index, const KmlGeometry& kmlGeometry);

    void removeAt(int index);

    void removeOne(const KmlGeometry& kmlGeometry);

    void move(int from, int to);

    KmlGeometry at(int index) const override;

    bool contains(const KmlGeometry& kmlGeometry) const;

    int indexOf(const KmlGeometry& kmlGeometry) const;

    KmlGeometry first() const;

    KmlGeometry last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*!
       \internal
     */
    explicit KmlGeometryListModel(std::shared_ptr<QRTImpl::KmlGeometryListImpl> impl, QObject* parent = nullptr);

  signals:
    void kmlGeometryAdded(int index);
    void kmlGeometryRemoved(int index);
    void errorOccurred(Esri::ArcGISRuntime::Error error);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(KmlGeometryListModel)

    KmlGeometryListModel() = delete;
    void setupRoles();
    void connectSignals();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::KmlGeometryListImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlNodeListModel_H
