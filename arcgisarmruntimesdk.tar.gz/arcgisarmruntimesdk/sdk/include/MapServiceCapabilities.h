// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file MapServiceCapabilities.h

#ifndef QRT_MapServiceCapabilities_H
#define QRT_MapServiceCapabilities_H

// C++ API headers
#include "ArcGISQt_global.h"

// STL headers
#include <memory>

namespace QRTImpl {
  class MapServiceCapabilitiesImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class MapServiceCapabilities
  {
  public:
    MapServiceCapabilities();
    ~MapServiceCapabilities();
    MapServiceCapabilities(const MapServiceCapabilities& other);
    MapServiceCapabilities(MapServiceCapabilities&& other) noexcept;
    MapServiceCapabilities& operator=(const MapServiceCapabilities& other);
    MapServiceCapabilities& operator=(MapServiceCapabilities&& other) noexcept;

    bool isSupportsData() const;

    bool isSupportsMap() const;

    bool isSupportsQuery() const;

    bool isSupportsTilemap() const;

    bool isSupportsTilesOnly() const;

    /*!
       \internal
     */
    explicit MapServiceCapabilities(std::shared_ptr<QRTImpl::MapServiceCapabilitiesImpl> impl);

  private:
    std::shared_ptr<QRTImpl::MapServiceCapabilitiesImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_MapServiceCapabilities_H
