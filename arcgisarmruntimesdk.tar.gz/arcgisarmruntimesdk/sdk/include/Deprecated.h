// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file Deprecated.h

#ifndef QRT_Deprecated_H
#define QRT_Deprecated_H

// define QRT_DISABLE_DEPRECATED_WARNINGS to disable these
// deprecation warnings

#ifndef QRT_DISABLE_DEPRECATED_WARNINGS
  #if __cplusplus >= 201402L && defined(__has_cpp_attribute)
  #  if __has_cpp_attribute(deprecated)
       // Compiler supports deprecated attribute. C++14.
  #    define QRT_DEPRECATED [[deprecated]]
  #  endif
  #elif defined(__GNUC__) || defined (__clang__)
     // Compiler specific attributes for older compilers.
  #  define QRT_DEPRECATED __attribute__((deprecated))
#endif
#endif // QRT_DISABLE_DEPRECATED_WARNINGS

#ifndef QRT_DEPRECATED
   // Compiler does not support this feature, or disabled explicitly
#  define QRT_DEPRECATED
#endif

#endif // QRT_deprecated_H
