// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LabelingInfo.h

#ifndef QRT_LabelingInfo_H
#define QRT_LabelingInfo_H

// C++ API headers
#include "ServiceTypes.h"
#include "TextSymbol.h"

namespace QRTImpl { class LabelingInfoImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class LabelingInfo
  {
  public:
    LabelingInfo();
    LabelingInfo(const LabelingInfo& other);
    LabelingInfo(LabelingInfo&& other) noexcept;
    ~LabelingInfo();

    LabelingInfo& operator=(const LabelingInfo& other);
    LabelingInfo& operator=(LabelingInfo&& other) noexcept;

    bool isEmpty() const;

    QString labelExpression() const;

    LabelingPlacement labelPlacement() const;

    double maxScale() const;

    double minScale() const;

    TextSymbol* symbol(QObject* parent = nullptr) const;

    bool isUseCodedValues() const;

    QString where() const;

    explicit LabelingInfo(std::shared_ptr<QRTImpl::LabelingInfoImpl> impl);

  private:
    std::shared_ptr<QRTImpl::LabelingInfoImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LabelingInfo_H
