// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PopupAttachment.h

#ifndef QRT_PopupAttachment_H
#define QRT_PopupAttachment_H

// C++ API headers
#include "Attachment.h"
#include "CoreTypes.h"
#include "Loadable.h"
#include "Object.h"
#include "PopupTypes.h"

// Qt headers
#include <QString>
#include <QUrl>

namespace QRTImpl { class PopupAttachmentImpl; }

namespace Esri {
namespace ArcGISRuntime {

class PopupAttachment : public Object, public Loadable
{
  Q_OBJECT

public:
  ~PopupAttachment() override;

  QString contentType() const;

  bool isLocal() const;

  QString name() const;

  qint64 size() const;

  QUrl attachmentUrl() const;

  Attachment* attachment() const;

  PopupAttachmentType popupType() const;

  PopupAttachmentEditState editState() const;

  QUuid thumbnail(int width, int height, AspectRatioMode aspectRatioMode = AspectRatioMode::KeepAspectRatio);

  QUuid fullImage();

  Error loadError() const override;
  LoadStatus loadStatus() const override;
  void cancelLoad() override;
  void load() override;
  void retryLoad() override;

  /*!
     \internal
   */
  PopupAttachment(std::shared_ptr<QRTImpl::PopupAttachmentImpl> impl, QObject* parent);
  std::shared_ptr<QRTImpl::PopupAttachmentImpl> getImpl() const;

signals:
  void thumbnailCompleted(QUuid taskId, const QImage& thumbnail);
  void fullImageCompleted(QUuid taskId, const QImage& fullImage);
  void doneLoading(Esri::ArcGISRuntime::Error error);
  void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

private:
  PopupAttachment() = delete;
  Q_DISABLE_COPY(PopupAttachment)

  std::shared_ptr<QRTImpl::PopupAttachmentImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PopupAttachment_H
