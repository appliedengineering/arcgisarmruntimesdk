// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LicenseResult.h

#ifndef QRT_LicenseResult_H
#define QRT_LicenseResult_H

// C++ API headers
#include "CoreTypes.h"
#include "Deprecated.h"

// Qt headers
#include <QMap>

// STL headers
#include <memory>

namespace QRTImpl { class LicenseResultImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class LicenseResult
  {
  public:
    LicenseResult();
    LicenseResult(const LicenseResult& other);
    LicenseResult(LicenseResult&& other) noexcept;
    ~LicenseResult();

    LicenseResult& operator=(const LicenseResult& other);
    LicenseResult& operator=(LicenseResult&& other) noexcept;

    bool isEmpty() const;

    LicenseStatus licenseStatus() const;

    QMap<QString, LicenseStatus> extensionsStatus() const;
    QRT_DEPRECATED QMap<QString, LicenseStatus> extentionsStatus() const; // deprecated

    /*! \internal */
    explicit LicenseResult(std::shared_ptr<QRTImpl::LicenseResultImpl> impl);

  private:
    std::shared_ptr<QRTImpl::LicenseResultImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LicenseResult_H
