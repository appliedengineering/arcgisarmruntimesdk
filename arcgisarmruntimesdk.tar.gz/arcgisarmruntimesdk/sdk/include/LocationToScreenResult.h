// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LocationToScreenResult.h

#ifndef QRT_LocationToScreenResult_H
#define QRT_LocationToScreenResult_H

// C++ API headers
#include "SceneViewTypes.h"

// Qt headers
#include <QPointF>

// STL headers
#include <memory>

namespace QRTImpl { class LocationToScreenResultImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class LocationToScreenResult
  {
  public:
    LocationToScreenResult();
    LocationToScreenResult(const LocationToScreenResult& other);
    LocationToScreenResult(LocationToScreenResult&& other) noexcept;
    ~LocationToScreenResult();

    LocationToScreenResult& operator=(const LocationToScreenResult& other);
    LocationToScreenResult& operator=(LocationToScreenResult&& other) noexcept;

    bool isEmpty() const;

    QPointF screenPoint() const;
    SceneLocationVisibility visibility() const;

    /*!
       \internal
     */
    explicit LocationToScreenResult(std::shared_ptr<QRTImpl::LocationToScreenResultImpl> impl);

  private:
    std::shared_ptr<QRTImpl::LocationToScreenResultImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LocationToScreenResult_H
