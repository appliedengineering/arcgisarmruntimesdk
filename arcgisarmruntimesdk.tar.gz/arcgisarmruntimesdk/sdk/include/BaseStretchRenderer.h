// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file BaseStretchRenderer.h

#ifndef QRT_BaseStretchRenderer_H
#define QRT_BaseStretchRenderer_H

// C++ API headers
#include "RasterRenderer.h"
#include "StretchParameters.h"

namespace QRTImpl { class BaseStretchRendererImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class BaseStretchRenderer : public RasterRenderer
  {
    Q_OBJECT

  public:
    ~BaseStretchRenderer() override;

    StretchParameters stretchParameters() const;
    bool isEstimateStatistics() const;
    QList<double> gammas() const;

    /*!
       \internal
     */
    BaseStretchRenderer(std::shared_ptr<QRTImpl::BaseStretchRendererImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(BaseStretchRenderer)
    BaseStretchRenderer() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_BaseStretchRenderer_H
