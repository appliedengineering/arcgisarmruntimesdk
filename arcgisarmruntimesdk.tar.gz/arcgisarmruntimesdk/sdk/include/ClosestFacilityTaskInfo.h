// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ClosestFacilityTaskInfo.h

#ifndef QRT_ClosestFacilityTaskInfo_H
#define QRT_ClosestFacilityTaskInfo_H

// C++ API headers
#include "CoreTypes.h"
#include "CostAttribute.h"
#include "NetworkAnalystTypes.h"
#include "RestrictionAttribute.h"
#include "SpatialReference.h"
#include "TravelMode.h"

// Qt headers
#include <QDateTime>
#include <QMap>
#include <QStringList>

// STL headers
#include <memory>

namespace QRTImpl { class ClosestFacilityTaskInfoImpl; }

namespace Esri {
namespace ArcGISRuntime {

class ClosestFacilityTaskInfo
{
public:
  ClosestFacilityTaskInfo();
  ClosestFacilityTaskInfo(const ClosestFacilityTaskInfo& other);
  ClosestFacilityTaskInfo(ClosestFacilityTaskInfo&& other) noexcept;
  ~ClosestFacilityTaskInfo();

  ClosestFacilityTaskInfo& operator=(const ClosestFacilityTaskInfo& other);
  ClosestFacilityTaskInfo& operator=(ClosestFacilityTaskInfo&& other) noexcept;

  bool isEmpty() const;

  QString networkName() const;

  QMap<QString, CostAttribute> costAttributes() const;

  QMap<QString, RestrictionAttribute> restrictionAttributes() const;

  QStringList supportedRestrictionUsageParameterValues() const;

  QList<TravelMode> travelModes() const;

  QString defaultTravelModeName() const;

  QStringList accumulateAttributeNames() const;

  QDateTime startTime() const;

  StartTimeUsage startTimeUsage() const;

  int defaultTargetFacilityCount() const;

  double defaultImpedanceCutoff() const;

  TravelDirection travelDirection() const;

  RouteShapeType routeShapeType() const;

  SpatialReference outputSpatialReference() const;

  QStringList supportedLanguages() const;

  UnitSystem directionsDistanceUnits() const;

  QString directionsLanguage() const;

  DirectionsStyle directionsStyle() const;

  double maxLocatingDistance() const;

  NetworkDirectionsSupport directionsSupport() const;

  /*!
     \internal
   */
  explicit ClosestFacilityTaskInfo(std::shared_ptr<QRTImpl::ClosestFacilityTaskInfoImpl> impl);

private:
  std::shared_ptr<QRTImpl::ClosestFacilityTaskInfoImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ClosestFacilityTaskInfo_H
