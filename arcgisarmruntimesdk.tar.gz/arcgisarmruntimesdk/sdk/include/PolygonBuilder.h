// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PolygonBuilder.h

#ifndef QRT_PolygonBuilder_H
#define QRT_PolygonBuilder_H

// C++ API headers
#include "MultipartBuilder.h"
#include "Polygon.h"
#include "Polyline.h"
#include "SpatialReference.h"

namespace QRTImpl { class PolygonBuilderImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class PolygonBuilder : public MultipartBuilder
  {
    Q_OBJECT

  public:
    explicit PolygonBuilder(const SpatialReference& spatialReference, QObject* parent = nullptr);

    explicit PolygonBuilder(const Polygon& polygon, QObject* parent = nullptr);

    ~PolygonBuilder() override;

    Geometry toGeometry() const override;

    Polygon toPolygon() const;

    Polyline toPolyline() const;

    GeometryBuilderType geometryBuilderType() const override;

    /*!
     \internal
     */
    PolygonBuilder(std::shared_ptr<QRTImpl::PolygonBuilderImpl> impl, QObject* parent);

    std::shared_ptr<QRTImpl::GeometryBuilderImpl> getImpl() const override;

  private:
    Q_DISABLE_COPY(PolygonBuilder)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PolygonBuilder_H
