// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LabelExpression.h

#ifndef QRT_LabelExpression_H
#define QRT_LabelExpression_H

// C++ API headers
#include "LabelingTypes.h"
#include "Object.h"

namespace QRTImpl { class LabelExpressionImpl; }

namespace Esri {
namespace ArcGISRuntime {

class LabelExpression : public Object
{
  Q_OBJECT
public:
  ~LabelExpression() override;

  QString expression() const;
  void setExpression(const QString& expression);

  LabelExpressionType labelExpressionType() const;

  LabelExpression(std::shared_ptr<QRTImpl::LabelExpressionImpl> impl, QObject* parent);

  std::shared_ptr<QRTImpl::LabelExpressionImpl> getImpl() const;

protected:
  std::shared_ptr<QRTImpl::LabelExpressionImpl> m_impl;
private:
  Q_DISABLE_COPY(LabelExpression)
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LabelExpression_H
