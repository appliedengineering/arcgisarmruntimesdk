// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeodatabaseDataset.h

#ifndef QRT_GeodatabaseDataset_H
#define QRT_GeodatabaseDataset_H

// C++ API headers
#include "GeodatabaseTypes.h"
#include "Object.h"

namespace QRTImpl { class GeodatabaseDatasetImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class Geodatabase;

  class GeodatabaseDataset : public Object
  {
    Q_OBJECT

  public:
    ~GeodatabaseDataset() override;

    virtual Geodatabase* geodatabase() const = 0;
    virtual QString name() const = 0;
    virtual GeodatabaseDatasetType geodatabaseDatasetType() const = 0;

  protected:
    explicit GeodatabaseDataset(QObject* parent = nullptr);

  private:
    Q_DISABLE_COPY(GeodatabaseDataset)

  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeodatabaseDataset_H
