// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ExportVectorTilesJob.h

#ifndef QRT_ExportVectorTilesJob_H
#define QRT_ExportVectorTilesJob_H

// C++ API headers
#include "ExportVectorTilesParameters.h"
#include "ExportVectorTilesResult.h"
#include "Job.h"

namespace QRTImpl { class ExportVectorTilesJobImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class ExportVectorTilesJob : public Job
  {
    Q_OBJECT

  public:
    ~ExportVectorTilesJob() override;

    ExportVectorTilesResult* result() const;

    ExportVectorTilesParameters parameters() const;

    QString vectorTileCachePath() const;

    QString itemResourcePath() const;

    /*!
       \internal
     */
    ExportVectorTilesJob(std::shared_ptr<QRTImpl::ExportVectorTilesJobImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(ExportVectorTilesJob)

    ExportVectorTilesJob() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ExportVectorTilesJob_H
