// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityTraceFunctionBarrierListModel.h

#ifndef QRT_UtilityTraceFunctionBarriersListModel_H
#define QRT_UtilityTraceFunctionBarriersListModel_H

// C++ API headers
#include "Iterable.h"
#include "UtilityTraceFunctionBarrier.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl {
  class UtilityTraceFunctionBarrierListImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class UtilityTraceFunctionBarrierListModel : public QAbstractListModel, public Iterable<UtilityTraceFunctionBarrier*>
  {
    Q_OBJECT

  public:

    enum UtilityTraceFunctionBarrierRoles
    {
      UtilityTraceFunctionBarrierComparisonOperator = Qt::UserRole + 1,
      UtilityTraceFunctionBarrierValue = Qt::UserRole + 2
    };

    ~UtilityTraceFunctionBarrierListModel() override;

    bool isEmpty() const;

    void clear();

    int size() const override;

    void append(UtilityTraceFunctionBarrier* utilityTraceFunctionBarrier);

    void insert(int index, UtilityTraceFunctionBarrier* utilityTraceFunctionBarrier);

    void removeAt(int index);

    void removeOne(UtilityTraceFunctionBarrier* utilityTraceFunctionBarrier);

    void move(int from, int to);

    UtilityTraceFunctionBarrier* at(int index) const override;

    bool contains(UtilityTraceFunctionBarrier* utilityTraceFunctionBarrier) const;

    int indexOf(UtilityTraceFunctionBarrier* utilityTraceFunctionBarrier) const;

    UtilityTraceFunctionBarrier* first() const;

    UtilityTraceFunctionBarrier* last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*!
     \internal
     */
    UtilityTraceFunctionBarrierListModel(std::shared_ptr<QRTImpl::UtilityTraceFunctionBarrierListImpl> impl, QObject* parent);

  signals:
    void utilityTraceFunctionBarrierAdded(int index);
    void utilityTraceFunctionBarrierRemoved(int index);
    void errorOccurred(Esri::ArcGISRuntime::Error error);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(UtilityTraceFunctionBarrierListModel)

    UtilityTraceFunctionBarrierListModel() = delete;
    void setupRoles_();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::UtilityTraceFunctionBarrierListImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityTraceFunctionBarriersListModel_H
