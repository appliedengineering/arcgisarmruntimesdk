// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file AnnotationSublayer.h

#ifndef QRT_AnnotationSublayer_H
#define QRT_AnnotationSublayer_H

// C++ API headers
#include "LayerContent.h"

namespace QRTImpl {
  class AnnotationSublayerImpl;
}

namespace Esri {
namespace ArcGISRuntime {

class AnnotationSublayer : public LayerContent
{
  Q_OBJECT

public:
  ~AnnotationSublayer() override;

  QString definitionExpression() const;

  double maxScale() const;
  double minScale() const;
  float opacity() const;

  bool scaleSymbols() const;

  qint64 subLayerId() const;

  QString name() const override;

  bool isVisible() const override;

  void setVisible(bool visible) override;

  bool canChangeVisibility() const override;

  bool isVisibleAtScale(double scale) const override;

  bool isShowInLegend() const override;

  void setShowInLegend(bool showInLegend) override;

  QList<LayerContent*> subLayerContents() const override;

  bool isAutoFetchLegendInfos() const override;

  void setAutoFetchLegendInfos(bool autoFetchLegendInfos) override;

  LegendInfoListModel* legendInfos() const override;

  /*! \internal */
  std::shared_ptr<QRTImpl::LayerContentImpl> iGetImpl() const override;
  /*! \internal */
  AnnotationSublayer(std::shared_ptr<QRTImpl::AnnotationSublayerImpl> impl, QObject* parent);
  std::shared_ptr<QRTImpl::AnnotationSublayerImpl> getImpl() const;

private:
  Q_DISABLE_COPY(AnnotationSublayer)
  std::shared_ptr<QRTImpl::AnnotationSublayerImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_AnnotationSublayer_H
