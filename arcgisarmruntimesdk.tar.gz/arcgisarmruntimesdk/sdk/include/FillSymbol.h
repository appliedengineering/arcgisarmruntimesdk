// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file FillSymbol.h

#ifndef QRT_FillSymbol_H
#define QRT_FillSymbol_H

// C++ API headers
#include "LineSymbol.h"
#include "Symbol.h"

// Qt headers
#include <QColor>

namespace QRTImpl { class FillSymbolImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class FillSymbol : public Symbol
  {
    Q_OBJECT

  public:
    ~FillSymbol() override;

    QColor color() const;
    void setColor(const QColor& color);

    LineSymbol* outline() const;
    void setOutline(LineSymbol* outline);

    /*! \internal */
    FillSymbol(std::shared_ptr<QRTImpl::SymbolImpl> impl, QObject* parent);

  protected:
    explicit FillSymbol(QObject* parent = nullptr);

  private:
    Q_DISABLE_COPY(FillSymbol)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_FillSymbol_H
