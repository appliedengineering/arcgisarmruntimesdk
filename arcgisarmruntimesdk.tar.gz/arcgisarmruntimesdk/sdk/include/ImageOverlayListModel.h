// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ImageOverlayListModel.h

#ifndef QRT_ImageOverlaysListModel_H
#define QRT_ImageOverlaysListModel_H

// C++ API headers
#include "ImageOverlay.h"
#include "Iterable.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl {
  class ImageOverlayListImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class ImageOverlayListModel : public QAbstractListModel, public Iterable<ImageOverlay*>
  {
    Q_OBJECT

  public:

    enum ImageOverlayRoles
    {
      ImageOverlayOpacityRole = Qt::UserRole + 1,
      ImageOverlayVisibleRole = Qt::UserRole + 2
    };

    ~ImageOverlayListModel() override;

    bool isEmpty() const;

    void clear();

    int size() const override;

    void append(ImageOverlay* imageOverlay);

    void insert(int index, ImageOverlay* imageOverlay);

    void removeAt(int index);

    void removeOne(ImageOverlay* imageOverlay);

    void move(int from, int to);

    ImageOverlay* at(int index) const override;

    bool contains(ImageOverlay* imageOverlay) const;

    int indexOf(ImageOverlay* imageOverlay) const;

    ImageOverlay* first() const;

    ImageOverlay* last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool setData(const QModelIndex& index, const QVariant& value, int role = Qt::EditRole) override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*!
     \internal
     */
    ImageOverlayListModel(std::shared_ptr<QRTImpl::ImageOverlayListImpl> impl, QObject* parent);

  signals:
    void imageOverlayAdded(int index);
    void imageOverlayRemoved(int index);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(ImageOverlayListModel)

    ImageOverlayListModel() = delete;
    void setupRoles();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::ImageOverlayListImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ImageOverlaysListModel_H
