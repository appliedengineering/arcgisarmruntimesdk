// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file MarkerSymbol.h

#ifndef QRT_MarkerSymbol_H
#define QRT_MarkerSymbol_H

// C++ API headers
#include "Deprecated.h"
#include "Symbol.h"

namespace QRTImpl { class MarkerSymbolImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class MarkerSymbol : public Symbol
  {
    Q_OBJECT

  public:
    ~MarkerSymbol() override;

    float angle() const;
    void setAngle(float angle);

    SymbolAngleAlignment angleAlignment() const;
    void setAngleAlignment(SymbolAngleAlignment angleAlignment);

    float leaderOffsetX() const;
    void setLeaderOffsetX(float offset);

    float leaderOffsetY() const;
    void setLeaderOffsetY(float offset);

    float offsetX() const;
    void setOffsetX(float offset);

    float offsetY() const;
    void setOffsetY(float offset);

    QRT_DEPRECATED RotationType rotationType() const;
    QRT_DEPRECATED void setRotationType(RotationType rotationType);

    /*! \internal */
    MarkerSymbol(std::shared_ptr<QRTImpl::SymbolImpl> impl, QObject* parent);

  protected:
    explicit MarkerSymbol(QObject* parent = nullptr);

  private:
    Q_DISABLE_COPY(MarkerSymbol)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_MarkerSymbol_H
