// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file QueryParameters.h

#ifndef QRT_QueryParameters_H
#define QRT_QueryParameters_H

// C++ API headers
#include "CoreTypes.h"
#include "Deprecated.h"
#include "Geometry.h"
#include "OrderBy.h"
#include "SpatialReference.h"
#include "TimeExtent.h"

// Qt headers
#include <QList>

// STL headers
#include <memory>

namespace QRTImpl {
  class QueryParametersImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class QueryParameters
  {
  public:
    QueryParameters();
    QueryParameters(const QueryParameters& other);
    QueryParameters(QueryParameters&& other) noexcept;
    ~QueryParameters();

    QueryParameters& operator=(const QueryParameters& other);
    QueryParameters& operator=(QueryParameters&& other) noexcept;

    bool isEmpty() const;
    void clear();

    Geometry geometry() const;
    void setGeometry(const Geometry& geometry);

    QRT_DEPRECATED SpatialReference inSpatialReference() const;

    double maxAllowableOffset() const;
    void setMaxAllowableOffset(double maxAllowableOffset);

    int maxFeatures() const;
    void setMaxFeatures(int maxFeatures);

    QList<qint64> objectIds() const;
    void setObjectIds(const QList<qint64>& objectIds);

    QList<OrderBy> orderByFields() const;
    void setOrderByFields(const QList<OrderBy>& orderByFields);

    SpatialReference outSpatialReference() const;
    void setOutSpatialReference(const SpatialReference& spatialReference);

    bool isReturnGeometry() const;
    void setReturnGeometry(bool returnGeometry);

    SpatialRelationship spatialRelationship() const;
    void setSpatialRelationship(SpatialRelationship relationship);

    QString whereClause() const;
    void setWhereClause(const QString& whereClause);

    int resultOffset() const;
    void setResultOffset(int resultOffset);

    TimeExtent timeExtent() const;
    void setTimeExtent(const TimeExtent& timeExtent);

    /*! \internal */
    explicit QueryParameters(const std::shared_ptr<QRTImpl::QueryParametersImpl>& impl);
    std::shared_ptr<QRTImpl::QueryParametersImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::QueryParametersImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_QueryParameters_H
