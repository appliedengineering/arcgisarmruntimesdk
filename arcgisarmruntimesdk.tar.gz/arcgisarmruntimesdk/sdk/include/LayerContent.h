// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LayerContent.h

#ifndef QRT_LayerContent_H
#define QRT_LayerContent_H

// C++ API headers
#include "LegendInfo.h"
#include "LegendInfoListModel.h"
#include "Object.h"
#include "TaskWatcher.h"

// Qt headers
#include <QPointer>
#include <QString>

namespace QRTImpl { class LayerContentImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class LayerContent : public Object
  {
    Q_OBJECT

  public:
    ~LayerContent() override;

    virtual QString name() const = 0;

    virtual bool isVisible() const = 0;

    virtual void setVisible(bool visible) = 0;

    virtual bool canChangeVisibility() const = 0;

    virtual bool isVisibleAtScale(double scale) const = 0;

    virtual bool isShowInLegend() const = 0;

    virtual void setShowInLegend(bool showInLegend) = 0;

    virtual QList<LayerContent*> subLayerContents() const = 0;

    virtual bool isAutoFetchLegendInfos() const = 0;

    virtual void setAutoFetchLegendInfos(bool autoFetchLegendInfos) = 0;

    virtual LegendInfoListModel* legendInfos() const = 0;

    virtual std::shared_ptr<QRTImpl::LayerContentImpl> iGetImpl() const = 0;

  signals:
    void subLayerContentChanged();

  protected:
    LayerContent(QObject* parent);

  private:
    Q_DISABLE_COPY(LayerContent)

    LayerContent() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LayerContent_H
