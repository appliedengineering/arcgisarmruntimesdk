// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file SyncCapabilities.h

#ifndef QRT_SyncCapabilities_H
#define QRT_SyncCapabilities_H

// STL headers
#include <memory>

namespace QRTImpl { class SyncCapabilitiesImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class SyncCapabilities
  {
  public:
    SyncCapabilities();
    SyncCapabilities(const SyncCapabilities& other);
    SyncCapabilities(SyncCapabilities&& other) noexcept;
    ~SyncCapabilities();

    SyncCapabilities& operator=(const SyncCapabilities& other);
    SyncCapabilities& operator=(SyncCapabilities&& other) noexcept;

    bool isEmpty() const;

    bool isSupportsAsync() const;
    bool isSupportsRegisteringExistingData() const;
    bool isSupportsRollbackOnFailure() const;
    bool isSupportsSyncDirectionControl() const;
    bool isSupportsSyncModelGeodatabase() const;
    bool isSupportsSyncModelLayer() const;
    bool isSupportsSyncModelNone() const;
    bool isSupportsAttachmentsSyncDirection() const;
    bool isSupportsUtilityNetworkSystem() const;
    bool isSupportsContingentValues() const;

    explicit SyncCapabilities(std::shared_ptr<QRTImpl::SyncCapabilitiesImpl> impl);

  private:
    std::shared_ptr<QRTImpl::SyncCapabilitiesImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_SyncCapabilities_H
