// COPYRIGHT 1995-2021 ESRI
// TRADE SECRETS: ESRI PROPRIETARY AND CONFIDENTIAL
// Unpublished material - all rights reserved under the
// Copyright Laws of the United States and applicable international
// laws, treaties, and conventions.
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file SketchEditConfiguration.h

#ifndef QRT_SketchEditConfiguration_H
#define QRT_SketchEditConfiguration_H

// C++ API headers
#include "Object.h"
#include "MapViewTypes.h"

namespace QRTImpl { class SketchEditConfigurationImpl; }

namespace Esri {
namespace ArcGISRuntime {

class SketchEditConfiguration : public Object
{
  Q_OBJECT

public:
  explicit SketchEditConfiguration(QObject* parent = nullptr);

  ~SketchEditConfiguration() override;

  bool isAllowMove() const;
  void setAllowMove(bool allowMove);

  bool isAllowPartSelection() const;
  void setAllowPartSelection(bool allowPartSelection);

  bool isAllowVertexEditing() const;
  void setAllowVertexEditing(bool allowVertexEditing);

  bool isShowMidVertices() const;
  void setShowMidVertices(bool showMidVertices);

  bool isRequireSelectionBeforeDrag() const;
  void setRequireSelectionBeforeDrag(bool requireSelectionBeforeDrag);

  SketchVertexEditMode vertexEditMode() const;
  void setVertexEditMode(SketchVertexEditMode vertexEditMode);

  /*! \internal */
  SketchEditConfiguration(std::shared_ptr<QRTImpl::SketchEditConfigurationImpl> impl, QObject* parent);

  /*! \internal */
  std::shared_ptr<QRTImpl::SketchEditConfigurationImpl> getImpl() const;

private:
  Q_DISABLE_COPY(SketchEditConfiguration)
  std::shared_ptr<QRTImpl::SketchEditConfigurationImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_SketchEditConfiguration_H
