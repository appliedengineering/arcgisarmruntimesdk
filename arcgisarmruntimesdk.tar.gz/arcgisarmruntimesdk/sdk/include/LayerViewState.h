// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LayerViewState.h

#ifndef QRT_LayerViewState_H
#define QRT_LayerViewState_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "Deprecated.h"
#include "Error.h"
#include "MapViewTypes.h"

// STL headers
#include <memory>

namespace QRTImpl { class LayerViewStateImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class LayerViewState
  {
  public:
    LayerViewState();
    ~LayerViewState();
    LayerViewState(const LayerViewState& other);
    LayerViewState(LayerViewState&& other) noexcept;
    LayerViewState& operator=(const LayerViewState& other);
    LayerViewState& operator=(LayerViewState&& other) noexcept;

    Error error() const;

    QRT_DEPRECATED LayerViewStatus status() const;

    LayerViewStatusFlags statusFlags() const;

    explicit LayerViewState(std::shared_ptr<QRTImpl::LayerViewStateImpl> impl);

  private:
    std::shared_ptr<QRTImpl::LayerViewStateImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::LayerViewState)

#endif // QRT_LayerViewState_H
