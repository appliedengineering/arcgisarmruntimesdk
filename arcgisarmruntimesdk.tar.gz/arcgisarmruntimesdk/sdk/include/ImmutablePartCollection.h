// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ImmutablePartCollection.h

#ifndef QRT_ImmutablePartCollection_H
#define QRT_ImmutablePartCollection_H

// C++ API headers
#include "ImmutablePart.h"
#include "Iterable.h"
#include "SpatialReference.h"

// STL headers
#include <memory>

namespace QRTImpl { class ImmutablePartCollectionImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class ImmutablePartCollection : public Iterable<ImmutablePart>
  {
  public:
    ImmutablePartCollection();

    ImmutablePartCollection(const ImmutablePartCollection& other);

    ImmutablePartCollection(ImmutablePartCollection&& other) noexcept;

    ~ImmutablePartCollection() override;

    ImmutablePartCollection& operator=(const ImmutablePartCollection& other);

    ImmutablePartCollection& operator=(ImmutablePartCollection&& other) noexcept;

    bool isEmpty() const;

    int size() const override;

    SpatialReference spatialReference() const;

    ImmutablePart part(int index) const;

    int indexOf(const ImmutablePart& part) const;

    /*! \internal */
    explicit ImmutablePartCollection(std::shared_ptr<QRTImpl::ImmutablePartCollectionImpl> impl);

  private:
    ImmutablePart at(int index) const override;

    std::shared_ptr<QRTImpl::ImmutablePartCollectionImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ImmutablePartCollection_H
