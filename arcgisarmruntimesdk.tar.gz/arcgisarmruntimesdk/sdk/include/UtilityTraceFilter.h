// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityTraceFilter.h

#ifndef QRT_UtilityTraceFilter_H
#define QRT_UtilityTraceFilter_H

// C++ API headers
#include "Object.h"

namespace QRTImpl { class UtilityTraceFilterImpl; }

namespace Esri {
namespace ArcGISRuntime {

enum class UtilityTraversabilityScope;

class UtilityNearestNeighbor;
class UtilityNetworkAttribute;
class UtilityTraceFunctionBarrierListModel;
class UtilityTraceCondition;

class UtilityTraceFilter : public Object
{
  Q_OBJECT

public:
  explicit UtilityTraceFilter(QObject* parent = nullptr);

  ~UtilityTraceFilter() override;

  UtilityTraceCondition* barriers() const;
  void setBarriers(UtilityTraceCondition* barriers);

  UtilityNetworkAttribute* bitsetNetworkAttribute() const;
  void setBitsetNetworkAttribute(UtilityNetworkAttribute* bitsetNetworkAttribute);

  UtilityTraceFunctionBarrierListModel* functionBarriers() const;

  UtilityNearestNeighbor* nearestNeighbor() const;
  void setNearestNeighbor(UtilityNearestNeighbor* nearestNeighbor);

  UtilityTraversabilityScope scope() const;
  void setScope(UtilityTraversabilityScope scope);

  std::shared_ptr<QRTImpl::UtilityTraceFilterImpl> getImpl() const;

  UtilityTraceFilter(std::shared_ptr<QRTImpl::UtilityTraceFilterImpl> impl, QObject* parent);

private:
  Q_DISABLE_COPY(UtilityTraceFilter)
  std::shared_ptr<QRTImpl::UtilityTraceFilterImpl> m_impl;

};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityTraceFilter_H
