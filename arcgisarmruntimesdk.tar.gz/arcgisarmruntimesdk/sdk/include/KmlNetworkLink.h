// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlNetworkLink.h

#ifndef QRT_KmlNetworkLink_H
#define QRT_KmlNetworkLink_H

// C++ API headers
#include "KmlNode.h"
#include "MapTypes.h"

namespace Esri {
namespace ArcGISRuntime {

  class KmlNetworkLink : public KmlNode
  {
    Q_OBJECT

  public:
    explicit KmlNetworkLink(const QUrl& url, QObject* parent = nullptr);
    ~KmlNetworkLink() override;

    QUrl url() const;
    void setUrl(const QUrl& url);

    bool canFlyToNode() const;
    void setCanFlyToNode(bool canFlyToNode);

    QList<KmlNode*> childNodes() const;

    bool hasRefreshVisibility() const;
    void setHasRefreshVisibility(bool hasRefreshVisibility);

    quint64 refreshInterval() const;
    void setRefreshInterval(quint64 refreshInterval);

    KmlRefreshMode refreshMode() const;
    void setRefreshMode(KmlRefreshMode refreshMode);

    quint64 viewRefreshTime() const;
    void setViewRefreshTime(quint64 viewRefreshTime);

    KmlViewRefreshMode viewRefreshMode() const;
    void setViewRefreshMode(KmlViewRefreshMode viewRefreshMode);

    void refresh();

    bool isOpen() const;
    void setOpen(bool open);

    KmlListItemType listItemType() const;
    void setListItemType(KmlListItemType listItemType);

    bool isPartiallyVisible() const;

    /*! \internal */
    KmlNetworkLink(std::shared_ptr<QRTImpl::KmlNodeImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(KmlNetworkLink)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlNetworkLink_H
