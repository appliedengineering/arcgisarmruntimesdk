// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file MultilayerPolylineSymbol.h

#ifndef QRT_MultilayerPolylineSymbol_H
#define QRT_MultilayerPolylineSymbol_H

// C++ API headers
#include "MultilayerSymbol.h"
#include "SymbolLayer.h"

// Qt headers
#include <QList>

namespace QRTImpl { class MultilayerPolylineSymbolImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class MultilayerPolylineSymbol : public MultilayerSymbol
  {
    Q_OBJECT

  public:
    explicit MultilayerPolylineSymbol(const QList<SymbolLayer*>& symbolLayers, QObject* parent = nullptr);
    MultilayerPolylineSymbol(const QList<SymbolLayer*>& symbolLayers,
                             SymbolReferenceProperties* referenceProperties,
                             QObject* parent = nullptr);
    ~MultilayerPolylineSymbol() override;

    float width() const;
    void setWidth(float width);

    /*! \internal */
    MultilayerPolylineSymbol(std::shared_ptr<QRTImpl::SymbolImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::MultilayerPolylineSymbolImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(MultilayerPolylineSymbol)
    MultilayerPolylineSymbol() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_MultilayerPolylineSymbol_H
