// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityTraceConfiguration.h

#ifndef QRT_UtilityTraceConfiguration_H
#define QRT_UtilityTraceConfiguration_H

// C++ API headers
#include "Object.h"

namespace QRTImpl { class UtilityTraceConfigurationImpl; }

namespace Esri {
namespace ArcGISRuntime {

class UtilityAssetTypeListModel;
class UtilityDomainNetwork;
class UtilityNetworkAttribute;
class UtilityPropagatorListModel;
class UtilityTier;
class UtilityTraceCondition;
class UtilityTraceFilter;
class UtilityTraceFunctionListModel;
class UtilityTraversability;

class UtilityTraceConfiguration : public Object
{
  Q_OBJECT
public:
  explicit UtilityTraceConfiguration(QObject* parent = nullptr);

  ~UtilityTraceConfiguration() override;

  UtilityDomainNetwork* domainNetwork() const;
  void setDomainNetwork(UtilityDomainNetwork* domainNetwork);

  UtilityTraceFilter* filter() const;
  void setFilter(UtilityTraceFilter* filter);

  UtilityTraceFunctionListModel* functions() const;

  bool isIgnoreBarriersAtStartingPoints() const;
  void setIgnoreBarriersAtStartingPoints(bool ignoreBarriersAtStartingPoints);

  bool isIncludeBarriers() const;
  void setIncludeBarriers(bool includeBarriers);

  bool isIncludeContainers() const;
  void setIncludeContainers(bool includeContainers);

  bool isIncludeContent() const;
  void setIncludeContent(bool includeContent);

  bool isIncludeIsolatedFeatures() const;
  void setIncludeIsolatedFeatures(bool includeIsolatedFeatures);

  bool isIncludeStructures() const;
  void setIncludeStructures(bool includeStructures);

  UtilityPropagatorListModel* propagators() const;

  UtilityTier* sourceTier() const;
  void setSourceTier(UtilityTier* sourceTier);

  UtilityTier* targetTier() const;
  void setTargetTier(UtilityTier* targetTier);

  UtilityTraversability* traversability() const;
  void setTraversability(UtilityTraversability* traversability);

  bool isValidateConsistency() const;
  void setValidateConsistency(bool validateConsistency);

  UtilityAssetTypeListModel* outputAssetTypes() const;

  UtilityTraceCondition* outputCondition() const;
  void setOutputCondition(UtilityTraceCondition* outputCondition);

  UtilityNetworkAttribute* shortestPathNetworkAttribute() const;
  void setShortestPathNetworkAttribute(UtilityNetworkAttribute* shortestPathNetworkAttribute);

  /*! \internal */
  UtilityTraceConfiguration(std::shared_ptr<QRTImpl::UtilityTraceConfigurationImpl> impl, QObject* parent);
  std::shared_ptr<QRTImpl::UtilityTraceConfigurationImpl> getImpl() const;

private:
  std::shared_ptr<QRTImpl::UtilityTraceConfigurationImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityTraceConfiguration_H
