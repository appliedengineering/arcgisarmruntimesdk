// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeotriggerMonitor.h

#ifndef QRT_GeotriggerMonitor_H
#define QRT_GeotriggerMonitor_H

// C++ API headers
#include "Object.h"
#include "TaskWatcher.h"

namespace QRTImpl { class GeotriggerMonitorImpl; }

namespace Esri {
namespace ArcGISRuntime {

class Error;
class Geotrigger;
class GeotriggerNotificationInfo;
enum class GeotriggerMonitorStatus;

class GeotriggerMonitor : public Object
{
  Q_OBJECT
public:
  explicit GeotriggerMonitor(Geotrigger* geotrigger, QObject* parent = nullptr);
  ~GeotriggerMonitor() override;

  Geotrigger* geotrigger() const;
  GeotriggerMonitorStatus status() const;
  Error warning() const;
  TaskWatcher start();
  void stop();

  /*!
     \internal
   */
  GeotriggerMonitor(std::shared_ptr<QRTImpl::GeotriggerMonitorImpl> impl, QObject* parent);
  std::shared_ptr<QRTImpl::GeotriggerMonitorImpl> getImpl() const;

signals:
  void startCompleted(QUuid taskId);
  void geotriggerNotification(Esri::ArcGISRuntime::GeotriggerNotificationInfo* geotriggerNotificationInfo);
  void statusChanged(Esri::ArcGISRuntime::GeotriggerMonitorStatus status);
  void warningChanged(Esri::ArcGISRuntime::Error warning);

private:
  Q_DISABLE_COPY(GeotriggerMonitor)
  std::shared_ptr<QRTImpl::GeotriggerMonitorImpl> m_impl;

  void connectSignals_();
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeotriggerMonitor_H
