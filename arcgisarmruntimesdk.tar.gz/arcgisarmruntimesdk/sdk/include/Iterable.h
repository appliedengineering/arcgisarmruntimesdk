// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file Iterable.h

#ifndef QRT_Iterable_H
#define QRT_Iterable_H

// STL headers
#include <cstddef>
#include <iterator>

namespace Esri {
namespace ArcGISRuntime {

  template <typename T>
  class Iterable
  {
  public:
    Iterable() = default;
    virtual ~Iterable() = default;

    /*! \internal */
    virtual T at(int index) const = 0;

    /*! \internal */
    virtual int size() const = 0;

#define define_iterator_traits \
  typedef std::forward_iterator_tag iterator_category; \
  typedef T value_type; \
  typedef std::ptrdiff_t difference_type; \
  typedef T* pointer; \
  typedef T& reference;

    class iterator {
    public:
      define_iterator_traits

      ~iterator() = default;
      iterator(Iterable* owner, int index) noexcept : m_owner(owner), m_currentIndex(index) { }
      iterator(const iterator& it) noexcept : m_owner(it.m_owner), m_currentIndex(it.m_currentIndex) { }
      iterator& operator=(const iterator& other) noexcept
      {
        if (this != &other)
        {
          m_owner = other.m_owner;
          m_currentIndex = other.m_currentIndex;
        }
        return *this;
      }
      T operator*() const { return m_owner->at(m_currentIndex); }
      bool operator!=(const iterator& other) const noexcept { return m_currentIndex != other.m_currentIndex; }
      bool operator==(const iterator& other) const noexcept { return m_currentIndex == other.m_currentIndex; }
      bool operator<(const iterator& other) const noexcept { return m_currentIndex < other.m_currentIndex; }
      bool operator>(const iterator& other) const noexcept { return m_currentIndex > other.m_currentIndex; }
      bool operator<=(const iterator& other) const noexcept { return m_currentIndex <= other.m_currentIndex; }
      bool operator>=(const iterator& other) const noexcept { return m_currentIndex >= other.m_currentIndex; }
      iterator& operator++() { m_currentIndex++; return *this; }
      iterator operator++(int) { iterator temp(*this); m_currentIndex++; return temp; }
    private:
      Iterable* m_owner = nullptr;
      int m_currentIndex = 0;
    };

    class const_iterator {
    public:
      define_iterator_traits

      ~const_iterator() = default;
      const_iterator(const Iterable* owner, int index) noexcept : m_owner(owner), m_currentIndex(index) { }
      const_iterator(const const_iterator& it) noexcept : m_owner(it.m_owner), m_currentIndex(it.m_currentIndex) { }
      const_iterator& operator=(const const_iterator& other) noexcept
      {
        if (this != &other)
        {
          m_owner = other.m_owner;
          m_currentIndex = other.m_currentIndex;
        }
        return *this;
      }
      const T operator*() const { return m_owner->at(m_currentIndex); }
      bool operator!=(const const_iterator& other) const noexcept { return m_currentIndex != other.m_currentIndex; }
      bool operator==(const const_iterator& other) const noexcept { return m_currentIndex == other.m_currentIndex; }
      bool operator<(const const_iterator& other) const noexcept { return m_currentIndex < other.m_currentIndex; }
      bool operator>(const const_iterator& other) const noexcept { return m_currentIndex > other.m_currentIndex; }
      bool operator<=(const const_iterator& other) const noexcept { return m_currentIndex <= other.m_currentIndex; }
      bool operator>=(const const_iterator& other) const noexcept { return m_currentIndex >= other.m_currentIndex; }
      const_iterator& operator++() { m_currentIndex++; return *this; }
      const_iterator operator++(int) { const_iterator temp(*this); m_currentIndex++; return temp; }
    private:
      const Iterable* m_owner = nullptr;
      int m_currentIndex = 0;
    };

    // non-const
    iterator begin() noexcept { return iterator(this, 0); }
    iterator end() noexcept { return iterator(this, size()); }

    // const
    const_iterator cbegin() const noexcept { return const_iterator(this, 0); }
    const_iterator begin() const noexcept { return cbegin(); }
    const_iterator constBegin() const noexcept { return cbegin(); }
    const_iterator cend() const noexcept { return const_iterator(this, size()); }
    const_iterator end() const noexcept { return cend(); }
    const_iterator constEnd() const noexcept { return cend(); }
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_Iterable_H
