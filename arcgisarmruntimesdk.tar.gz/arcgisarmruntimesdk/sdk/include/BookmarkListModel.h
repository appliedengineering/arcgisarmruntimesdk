// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file BookmarkListModel.h

#ifndef QRT_BookmarkListModel_H
#define QRT_BookmarkListModel_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "Bookmark.h"
#include "Iterable.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl { class BookmarkListImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class BookmarkListModel : public QAbstractListModel, public Iterable<Bookmark*>
  {
    Q_OBJECT

  public:

    enum BookmarkRoles
    {
      BookmarkNameRole = Qt::UserRole + 1,
    };

    ~BookmarkListModel() override;

    bool isEmpty() const;

    void clear();

    int size() const override;

    void append(Bookmark* bookmark);

    void insert(int index, Bookmark* bookmark);

    void removeAt(int index);

    void removeOne(Bookmark* bookmark);

    void move(int from, int to);

    Bookmark* at(int index) const override;

    bool contains(Bookmark* bookmark) const;

    int indexOf(Bookmark* bookmark) const;

    Bookmark* first() const;

    Bookmark* last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool setData(const QModelIndex& index, const QVariant& value, int role = Qt::EditRole) override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*!
       \internal
     */
    BookmarkListModel(std::shared_ptr<QRTImpl::BookmarkListImpl> impl, QObject* parent);

  signals:
    void bookmarkAdded(int index);
    void bookmarkRemoved(int index);
    void errorOccurred(Esri::ArcGISRuntime::Error error);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(BookmarkListModel)

    BookmarkListModel() = delete;
    void setupRoles();
    void connectSignals();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::BookmarkListImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_BookmarkListModel_H
