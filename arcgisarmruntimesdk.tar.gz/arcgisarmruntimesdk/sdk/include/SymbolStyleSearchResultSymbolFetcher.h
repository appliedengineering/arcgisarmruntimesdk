// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file SymbolStyleSearchResultSymbolFetcher.h

#ifndef QRT_SymbolStyleSearchResultSymbolFetcher_H
#define QRT_SymbolStyleSearchResultSymbolFetcher_H

// C++ API headers
#include "Object.h"
#include "TaskWatcher.h"

namespace QRTImpl { class SymbolStyleSearchResultImpl; }

namespace Esri {
namespace ArcGISRuntime {

class Symbol;

class SymbolStyleSearchResultSymbolFetcher : public Object
{
  Q_OBJECT

public:
  SymbolStyleSearchResultSymbolFetcher(std::shared_ptr<QRTImpl::SymbolStyleSearchResultImpl> impl, QObject* parent);

  TaskWatcher fetchSymbol();

signals:
  void fetchSymbolCompleted(QUuid taskId, Esri::ArcGISRuntime::Symbol* symbol);

private:
  Q_DISABLE_COPY(SymbolStyleSearchResultSymbolFetcher)

  std::shared_ptr<QRTImpl::SymbolStyleSearchResultImpl> m_impl;

};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_SymbolStyleSearchResultSymbolFetcher_H
