// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ServiceGeodatabase.h

#ifndef QRT_ServiceGeodatabase_H
#define QRT_ServiceGeodatabase_H

// C++ API headers
#include "Loadable.h"
#include "Object.h"
#include "RemoteResource.h"
#include "ServiceVersionInfo.h"
#include "TaskWatcher.h"

class QUrl;

namespace QRTImpl { class ServiceGeodatabaseImpl; }

namespace Esri {
namespace ArcGISRuntime {

class ArcGISFeatureServiceInfo;
class FeatureTableEditResult;
class ServiceFeatureTable;
class ServiceVersionParameters;
enum class FeatureServiceSessionType;
class PortalItem;

class ServiceGeodatabase : public Object, public Loadable, public RemoteResource
{
  Q_OBJECT
public:

  explicit ServiceGeodatabase(const QUrl& url, QObject* parent = nullptr);
  ServiceGeodatabase(const QUrl& url, Credential* credential, QObject* parent = nullptr);
  ServiceGeodatabase(const QUrl& url, FeatureServiceSessionType sessionType, QObject* parent = nullptr);
  ServiceGeodatabase(const QUrl& url, FeatureServiceSessionType sessionType, Credential* credential, QObject* parent = nullptr);
  ServiceGeodatabase(const QUrl& url, const QString& versionName, QObject* parent = nullptr);
  ServiceGeodatabase(const QUrl& url, const QString& versionName, Credential* credential, QObject* parent = nullptr);
  ServiceGeodatabase(const QUrl& url, const QString& versionName, FeatureServiceSessionType sessionType, QObject* parent = nullptr);
  ServiceGeodatabase(const QUrl& url, const QString& versionName, FeatureServiceSessionType sessionType, Credential* credential, QObject* parent = nullptr);
  explicit ServiceGeodatabase(PortalItem* portalItem, QObject* parent = nullptr);
  ServiceGeodatabase(PortalItem* portalItem, FeatureServiceSessionType sessionType, QObject* parent = nullptr);
  ServiceGeodatabase(PortalItem* portalItem, const QString& versionName, QObject* parent = nullptr);
  ServiceGeodatabase(PortalItem* portalItem, const QString& versionName, FeatureServiceSessionType sessionType, QObject* parent = nullptr);

  ~ServiceGeodatabase() override;

  QList<ServiceFeatureTable*> connectedTables() const;

  QString defaultVersionName() const;

  ArcGISFeatureServiceInfo serviceInfo() const;

  FeatureServiceSessionType sessionType() const;
  void setSessionType(FeatureServiceSessionType sessionType);

  bool isSupportsBranchVersioning() const;

  QString versionName() const;

  TaskWatcher close();

  TaskWatcher createVersion(ServiceVersionParameters* parameters);

  TaskWatcher fetchVersions();

  TaskWatcher switchVersion(const QString& versionName);

  ServiceFeatureTable* table(qint64 layerId);

  bool hasLocalEdits() const;

  TaskWatcher applyEdits();

  TaskWatcher undoLocalEdits();

  PortalItem* portalItem() const;

  ServiceGeodatabase(std::shared_ptr<QRTImpl::ServiceGeodatabaseImpl> impl, QObject* parent);

  // RemoteResource interface methods
  QUrl url() const override;
  Credential* credential() const override;
  RequestConfiguration requestConfiguration() const override;
  void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

  // Loadable Interface methods
  Error loadError() const override;
  LoadStatus loadStatus() const override;
  void cancelLoad() override;
  void load() override;
  void retryLoad() override;

  std::shared_ptr<QRTImpl::ServiceGeodatabaseImpl> getImpl() const;

signals:
  void closeCompleted(QUuid taskId);
  void createVersionCompleted(QUuid taskId, Esri::ArcGISRuntime::ServiceVersionInfo* ServiceVersionInfo);
  void fetchVersionsCompleted(QUuid taskId, const QList<Esri::ArcGISRuntime::ServiceVersionInfo*>& serviceVersionInfos);
  void switchVersionCompleted(QUuid taskId);
  void doneLoading(Esri::ArcGISRuntime::Error loadError);
  void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);
  void applyEditsCompleted(QUuid taskId, const QList<Esri::ArcGISRuntime::FeatureTableEditResult*>& editResults);
  void undoLocalEditsCompleted(QUuid taskId);

private:
  Q_DISABLE_COPY(ServiceGeodatabase)
  std::shared_ptr<QRTImpl::ServiceGeodatabaseImpl> m_impl;

  void connectSignals_();
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ServiceGeodatabase_H
