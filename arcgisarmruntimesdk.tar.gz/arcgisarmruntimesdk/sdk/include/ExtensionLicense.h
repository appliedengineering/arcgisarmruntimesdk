// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ExtensionLicense.h

#ifndef QRT_ExtensionLicense_H
#define QRT_ExtensionLicense_H

// C++ API headers
#include "CoreTypes.h"

// Qt headers
#include <QDateTime>

// STL headers
#include <memory>

namespace QRTImpl { class ExtensionLicenseImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class ExtensionLicense
  {
  public:
    ExtensionLicense();
    ExtensionLicense(const ExtensionLicense& other);
    ExtensionLicense(ExtensionLicense&& other) noexcept;
    ~ExtensionLicense();

    ExtensionLicense& operator=(const ExtensionLicense& other);
    ExtensionLicense& operator=(ExtensionLicense&& other) noexcept;

    QDateTime expiry() const;

    bool isPermanent() const;

    LicenseStatus licenseStatus() const;

    QString name() const;

    /*! \internal */
    explicit ExtensionLicense(std::shared_ptr<QRTImpl::ExtensionLicenseImpl> impl);

  private:
    std::shared_ptr<QRTImpl::ExtensionLicenseImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ExtensionLicense_H
