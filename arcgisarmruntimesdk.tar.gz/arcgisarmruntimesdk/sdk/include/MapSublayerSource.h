// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file MapSublayerSource.h

#ifndef QRT_MapSublayerSource_H
#define QRT_MapSublayerSource_H

// C++ API headers
#include "SublayerSource.h"

namespace QRTImpl { class MapSublayerSourceImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class MapSublayerSource : public SublayerSource
  {
    Q_OBJECT

  public:
    explicit MapSublayerSource(qint64 id, QObject* parent = nullptr);
    ~MapSublayerSource() override;

    QString geodatabaseVersion() const;
    void setGeodatabaseVersion(const QString& geodatabaseVersion);

    qint64 mapSublayerId() const;

    /*! \internal */
    MapSublayerSource(std::shared_ptr<QRTImpl::MapSublayerSourceImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(MapSublayerSource)
    /*! \internal */
    MapSublayerSource() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_MapSublayerSource_H
