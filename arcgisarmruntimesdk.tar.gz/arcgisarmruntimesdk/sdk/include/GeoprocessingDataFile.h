// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeoprocessingDataFile.h

#ifndef QRT_GeoprocessingDataFile_H
#define QRT_GeoprocessingDataFile_H

// C++ API headers
#include "GeoprocessingParameter.h"
#include "RemoteResource.h"
#include "TaskWatcher.h"

// Qt headers
#include <QUrl>

namespace QRTImpl { class GeoprocessingDataFileImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class GeoprocessingDataFile : public GeoprocessingParameter, public RemoteResource
  {
    Q_OBJECT

  public:
    explicit GeoprocessingDataFile(QObject* parent = nullptr);
    explicit GeoprocessingDataFile(const QUrl& url, QObject* parent = nullptr);
    QRT_DEPRECATED explicit GeoprocessingDataFile(const QUrl& url, Credential* credential, QObject* parent = nullptr);
    ~GeoprocessingDataFile() override;

    void setUrl(const QUrl& url);
    QUrl url() const override;

    QString inputFilePath() const;
    void setInputFilePath(const QString& path);

    QString uploadId() const;
    void setUploadId(const QString& uploadId);

    TaskWatcher fetchFile(const QString& filePath);

    // RemoteResource interface methods
    QRT_DEPRECATED Credential* credential() const override;
    QRT_DEPRECATED RequestConfiguration requestConfiguration() const override;
    QRT_DEPRECATED void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

    /*!
       \internal
     */
    GeoprocessingDataFile(std::shared_ptr<QRTImpl::GeoprocessingDataFileImpl> impl, QObject* parent);

  signals:
    void fetchFileCompleted(QUuid taskId, const QString& filePath);

  private:
    Q_DISABLE_COPY(GeoprocessingDataFile)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeoprocessingDataFile_H
