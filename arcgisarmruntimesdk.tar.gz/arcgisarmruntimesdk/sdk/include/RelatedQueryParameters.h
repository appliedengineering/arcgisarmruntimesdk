// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file RelatedQueryParameters.h

#ifndef QRT_RelatedQueryParameters_H
#define QRT_RelatedQueryParameters_H

// C++ API headers
#include "CoreTypes.h"
#include "QueryParameters.h"
#include "RelationshipInfo.h"

// Qt headers
#include <QStringList>

// STL headers
#include <memory>

namespace QRTImpl {
  class RelatedQueryParametersImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class RelatedQueryParameters
  {
  public:
    RelatedQueryParameters();
    explicit RelatedQueryParameters(const RelationshipInfo& relationshipInfo);
    RelatedQueryParameters(const RelatedQueryParameters& other);
    RelatedQueryParameters(RelatedQueryParameters&& other) noexcept;
    ~RelatedQueryParameters();

    RelatedQueryParameters& operator=(const RelatedQueryParameters& other);
    RelatedQueryParameters& operator=(RelatedQueryParameters&& other) noexcept;

    bool isEmpty() const;
    void clear();

    QList<OrderBy> orderByFields() const;
    void setOrderByFields(const QList<OrderBy>& orderByFields);

    RelationshipInfo relationshipInfo() const;
    void setRelationshipInfo(const RelationshipInfo& relationshipInfo);

    bool isReturnGeometry() const;
    void setReturnGeometry(bool returnGeometry);

    QString whereClause() const;
    void setWhereClause(const QString& whereClause);

    int maxFeatures() const;
    void setMaxFeatures(int maxFeatures);

    int resultOffset() const;
    void setResultOffset(int resultOffset);

    explicit RelatedQueryParameters(const std::shared_ptr<QRTImpl::RelatedQueryParametersImpl>& impl);
    std::shared_ptr<QRTImpl::RelatedQueryParametersImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::RelatedQueryParametersImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_RelatedQueryParameters_H
