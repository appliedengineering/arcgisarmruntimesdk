// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file DownloadPreplannedOfflineMapParameters.h

#ifndef QRT_DownloadPreplannedOfflineMapParameters_H
#define QRT_DownloadPreplannedOfflineMapParameters_H

// C++ API headers
#include "PreplannedMapArea.h"

namespace QRTImpl {
  class DownloadPreplannedOfflineMapParametersImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  enum class PreplannedUpdateMode;

  class DownloadPreplannedOfflineMapParameters
  {
  public:
    DownloadPreplannedOfflineMapParameters();
    explicit DownloadPreplannedOfflineMapParameters(PreplannedMapArea* preplannedMapArea);
    DownloadPreplannedOfflineMapParameters(const DownloadPreplannedOfflineMapParameters& other);
    DownloadPreplannedOfflineMapParameters(DownloadPreplannedOfflineMapParameters&& other) noexcept;
    ~DownloadPreplannedOfflineMapParameters();

    DownloadPreplannedOfflineMapParameters& operator=(const DownloadPreplannedOfflineMapParameters& other);
    DownloadPreplannedOfflineMapParameters& operator=(DownloadPreplannedOfflineMapParameters&& other) noexcept;

    bool isContinueOnErrors() const;
    void setContinueOnErrors(bool continueOnErrors);

    bool isIncludeBasemap() const;
    void setIncludeBasemap(bool includeBasemap);

    PreplannedMapArea* preplannedMapArea(QObject* parent = nullptr) const;
    void setPreplannedMapArea(PreplannedMapArea* preplannedMapArea);

    QString referenceBasemapDirectory() const;
    void setReferenceBasemapDirectory(const QString& referenceBasemapDirectory);

    QString referenceBasemapFilename() const;
    void setReferenceBasemapFilename(const QString& referenceBasemapFilename);

    PreplannedUpdateMode updateMode() const;
    void setUpdateMode(PreplannedUpdateMode updateMode);

    /*!
       \internal
     */
    std::shared_ptr<QRTImpl::DownloadPreplannedOfflineMapParametersImpl> getImpl() const;

    /*!
       \internal
     */
    explicit DownloadPreplannedOfflineMapParameters(std::shared_ptr<QRTImpl::DownloadPreplannedOfflineMapParametersImpl> impl);

  private:
    std::shared_ptr<QRTImpl::DownloadPreplannedOfflineMapParametersImpl> m_impl;
  };
} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::DownloadPreplannedOfflineMapParameters)

#endif // QRT_DownloadPreplannedOfflineMapParameters_H
