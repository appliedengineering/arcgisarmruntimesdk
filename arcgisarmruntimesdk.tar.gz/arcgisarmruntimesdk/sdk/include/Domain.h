// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file Domain.h

#ifndef QRT_Domain_H
#define QRT_Domain_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "JsonSerializable.h"
#include "ServiceTypes.h"

// STL headers
#include <memory>

namespace QRTImpl { class DomainImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class Domain : public JsonSerializable
  {
  public:
    Domain();

    Domain(const Domain& other);
    Domain(Domain&& other) noexcept;

    Domain& operator=(const Domain& other);
    Domain& operator=(Domain&& other) noexcept;

    ~Domain();

    DomainType domainType() const;

    bool isEmpty() const;

    QString name() const;

    bool operator==(const Domain& other) const;

    QString toJson() const override;
    QJsonObject unknownJson() const override;
    QJsonObject unsupportedJson() const override;
    static Domain fromJson(const QString& json);

    /*! \internal */
    explicit Domain(std::shared_ptr<QRTImpl::DomainImpl> impl);
    std::shared_ptr<QRTImpl::DomainImpl> getImpl() const;

  protected:
    std::shared_ptr<QRTImpl::DomainImpl> m_impl;
  };

  /*! \internal */
  template<typename T>
  T domain_cast(const Domain&)
  {
    return Domain();
  }

  template<>
  inline Domain domain_cast<Domain>(const Domain& domain)
  {
    return domain;
  }

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::Domain)

#endif // QRT_Domain_H
