// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlGroundOverlay.h

#ifndef QRT_KmlGroundOverlay_H
#define QRT_KmlGroundOverlay_H

// C++ API headers
#include "Geometry.h"
#include "KmlIcon.h"
#include "KmlNode.h"
#include "MapTypes.h"

// Qt headers
#include <QColor>

namespace Esri {
namespace ArcGISRuntime {

  class KmlGroundOverlay : public KmlNode
  {
    Q_OBJECT

  public:
    ~KmlGroundOverlay() override;
    KmlGroundOverlay(const Geometry& geometry, KmlIcon* icon, QObject* parent = nullptr);

    double altitude() const;
    void setAltitude(double altitude);

    KmlAltitudeMode altitudeMode() const;
    void setAltitudeMode(KmlAltitudeMode altitudeMode);

    QColor color() const;
    void setColor(const QColor& color);

    int drawOrder() const;
    void setDrawOrder(int drawOrder);

    Geometry geometry() const;
    void setGeometry(const Geometry& geometry);

    double rotation() const;
    void setRotation(double rotation);

    KmlIcon* icon() const;
    void setIcon(KmlIcon* icon);

    /*! \internal */
    KmlGroundOverlay(std::shared_ptr<QRTImpl::KmlNodeImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(KmlGroundOverlay)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlGroundOverlay_H
