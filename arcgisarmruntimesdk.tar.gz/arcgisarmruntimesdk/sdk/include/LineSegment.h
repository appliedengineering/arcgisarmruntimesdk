// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LineSegment.h

#ifndef QRT_LineSegment_H
#define QRT_LineSegment_H

// C++ API headers
#include "Segment.h"

namespace QRTImpl { class LineSegmentImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class LineSegment : public Segment
  {
  public:
    LineSegment();

    ~LineSegment();

    LineSegment(const Point& startPoint,
                const Point& endPoint);

    LineSegment(const Point& startPoint,
                const Point& endPoint,
                const SpatialReference& spatialReference);

    LineSegment(double xStart,
                double yStart,
                double xEnd,
                double yEnd);

    LineSegment(double xStart,
                double yStart,
                double xEnd,
                double yEnd,
                const SpatialReference& spatialReference);

    LineSegment(double xStart,
                double yStart,
                double zStart,
                double xEnd,
                double yEnd,
                double zEnd);

    LineSegment(double xStart,
                double yStart,
                double zStart,
                double xEnd,
                double yEnd,
                double zEnd,
                const SpatialReference& spatialReference);

    LineSegment(const LineSegment& other);

    LineSegment(const Segment& other);

    LineSegment(LineSegment&& other) noexcept;

    LineSegment& operator=(const LineSegment& other);

    LineSegment& operator=(LineSegment&& other) noexcept;

    static LineSegment createLineAtAngleFromStartPoint(const Point& startPoint, double angleRadians, double length);

    explicit LineSegment(std::shared_ptr<QRTImpl::LineSegmentImpl> impl);
  };

  template<>
  inline LineSegment segment_cast<LineSegment>(const Segment& segment)
  {
    return segment.segmentType() == SegmentType::LineSegment ? static_cast<LineSegment>(segment) : LineSegment();
  }

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LineSegment_H
