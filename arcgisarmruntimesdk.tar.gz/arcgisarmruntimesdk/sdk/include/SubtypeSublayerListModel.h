// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file SubtypeSublayerListModel.h

#ifndef QRT_SubtypeSublayerListModel_H
#define QRT_SubtypeSublayerListModel_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "Iterable.h"
#include "SubtypeSublayer.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl { class SubtypeSublayerListImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class SubtypeSublayer;

  class SubtypeSublayerListModel : public QAbstractListModel, public Iterable<SubtypeSublayer*>
  {
    Q_OBJECT

  public:
    enum SubtypeSublayerRoles
    {
      SubtypeSublayerNameRole = Qt::UserRole + 1,
      SubtypeSublayerIdRole = Qt::UserRole + 2,
      SubtypeSublayerMinScaleRole = Qt::UserRole + 3,
      SubtypeSublayerMaxScaleRole = Qt::UserRole + 4,
      SubtypeSublayerTypeRole = Qt::UserRole + 5,
      SubtypeSublayerCanChangeVisibilityRole = Qt::UserRole + 6,
      SubtypeSublayerVisibleRole = Qt::UserRole + 7,
      SubtypeSublayerShowInLegendRole = Qt::UserRole + 8,
      SubtypeSublayerDefinitionExpressionRole = Qt::UserRole + 9,
      SubtypeSublayerOpacityRole = Qt::UserRole + 10,
      SubtypeSublayerScaleSymbolsRole = Qt::UserRole + 11,
      SubtypeSublayerLabelsEnabledRole = Qt::UserRole + 12
    };

    ~SubtypeSublayerListModel() override;

    bool isEmpty() const;

    void clear();

    int size() const override;

    void append(SubtypeSublayer* sublayer);

    void insert(int index, SubtypeSublayer* sublayer);

    void removeAt(int index);

    void removeOne(SubtypeSublayer* sublayer);

    void move(int from, int to);

    SubtypeSublayer* at(int index) const override;

    bool contains(SubtypeSublayer* sublayer) const;

    int indexOf(SubtypeSublayer* sublayer) const;

    SubtypeSublayer* first() const;

    SubtypeSublayer* last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*!
       \internal
     */
    SubtypeSublayerListModel(std::shared_ptr<QRTImpl::SubtypeSublayerListImpl> impl, QObject* parent);

  signals:
    void subtypeSublayerAdded(int index);
    void subtypeSublayerRemoved(int index);
    void errorOccurred(Esri::ArcGISRuntime::Error error);

/*!
   \internal
 */
  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(SubtypeSublayerListModel)

    SubtypeSublayerListModel() = delete;
    void setupRoles();
    void connectSignals();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::SubtypeSublayerListImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_SubtypeSublayerListModel_H
