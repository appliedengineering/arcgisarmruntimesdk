// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file FloorLevel.h

#ifndef QRT_FloorLevel_H
#define QRT_FloorLevel_H

// C++ API headers
#include "Object.h"

namespace QRTImpl { class FloorLevelImpl; }

namespace Esri {
namespace ArcGISRuntime {

class FloorFacility;
class Geometry;

class FloorLevel : public Object
{
  Q_OBJECT
public:
  ~FloorLevel() override;

  FloorFacility* facility() const;

  Geometry geometry() const;

  QString levelId() const;

  bool isVisible() const;
  void setVisible(bool visible);

  int levelNumber() const;

  QString longName() const;

  QString shortName() const;

  int verticalOrder() const;

  FloorLevel(std::shared_ptr<QRTImpl::FloorLevelImpl> impl, QObject* parent);

  std::shared_ptr<QRTImpl::FloorLevelImpl> getImpl() const;

private:
  Q_DISABLE_COPY(FloorLevel)
  std::shared_ptr<QRTImpl::FloorLevelImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_FloorLevel_H
