// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityNetworkAttributeComparison.h

#ifndef QRT_UtilityNetworkAttributeComparison_H
#define QRT_UtilityNetworkAttributeComparison_H

// C++ API headers
#include "UtilityTraceConditionalExpression.h"

namespace QRTImpl { class UtilityNetworkAttributeComparisonImpl; }

namespace Esri {
namespace ArcGISRuntime {

enum class UtilityAttributeComparisonOperator;

class UtilityNetworkAttribute;

class UtilityNetworkAttributeComparison : public UtilityTraceConditionalExpression
{
  Q_OBJECT
public:
  UtilityNetworkAttributeComparison(UtilityNetworkAttribute* networkAttribute,
                                    UtilityAttributeComparisonOperator comparisonOperator,
                                    const QVariant& value,
                                    QObject* parent = nullptr);

  UtilityNetworkAttributeComparison(UtilityNetworkAttribute* networkAttribute,
                                    UtilityAttributeComparisonOperator comparisonOperator,
                                    UtilityNetworkAttribute* otherNetworkAttribute,
                                    QObject* parent = nullptr);

  ~UtilityNetworkAttributeComparison() override;

  UtilityAttributeComparisonOperator comparisonOperator() const;

  UtilityNetworkAttribute* networkAttribute() const;

  UtilityNetworkAttribute* otherNetworkAttribute() const;

  QVariant value() const;

  /*! \internal */
  UtilityNetworkAttributeComparison(std::shared_ptr<QRTImpl::UtilityNetworkAttributeComparisonImpl> impl, QObject* parent);
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityNetworkAttributeComparison_H
