// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file Segment.h

#ifndef QRT_Segment_H
#define QRT_Segment_H

// C++ API headers
#include "GeometryTypes.h"
#include "Point.h"
#include "SpatialReference.h"

namespace QRTImpl { class SegmentImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class Segment
  {
  public:
    Segment();
    ~Segment();

    Segment(const Segment& other);

    Segment(Segment&& other) noexcept;

    Segment& operator=(const Segment& other);

    Segment& operator=(Segment&& other) noexcept;

    Point startPoint() const;

    Point endPoint() const;

    bool isClosed() const;

    bool isCurve() const;

    bool isEmpty() const;

    SegmentType segmentType() const;

    SpatialReference spatialReference() const;

    bool operator==(const Segment& other) const;

    /*! \internal */
    explicit Segment(std::shared_ptr<QRTImpl::SegmentImpl> impl);

    std::shared_ptr<QRTImpl::SegmentImpl> getImpl() const;

  protected:
    std::shared_ptr<QRTImpl::SegmentImpl> m_impl;
  };

  /*!
    \brief Type-safe cast helper for segment types.

    Casting a Segment-derived class to the base Segment type is always valid.

    \code
    LineSegment lineSegment(startPoint, endPoint);
    Segment s = segment_cast<Segment>(lineSegment);
    \endcode

    However, casting from Segment to a Segment-derived class is valid only if \l Segment::segmentType
    is the same type as target type.

    \code
    Segment s = LineSegment(startPoint, endPoint);
    LineSegment lineSegment = segment_cast<LineSegment>(s);
    QASSERT(lineSegment.isEmpty());

    Segment s2 = CubicBezierSegment(startPoint, controlPoint1, controlPoint2, endPoint, spatialReference);
    LineSegment invalidSegment = segment_cast<LineSegment>(s2);
    QASSERT(!invalidSegment.isEmpty());
    \endcode

    \since Esri::ArcGISRuntime 100.12
  */
  template<typename T>
  T segment_cast(const Segment&)
  {
    return Segment();
  }

  template<>
  inline Segment segment_cast<Segment>(const Segment& segment)
  {
    return segment;
  }

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_Segment_H
