// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file OfflineMapTypes.h

#ifndef QRT_OfflineMapTypes_H
#define QRT_OfflineMapTypes_H

namespace Esri {
namespace ArcGISRuntime {

  enum class DestinationTableRowFilter
  {
    All = 0,
    RelatedOnly = 1
  };

  enum class GenerateOfflineMapUpdateMode
  {
    SyncWithFeatureServices = 0,
    NoUpdates = 1
  };

  enum class OfflineMapParametersType
  {
    GenerateGeodatabase = 0,
    ExportVectorTiles = 1,
    ExportTileCache = 2,
    Unknown = -1
  };

  enum class OfflineUpdateAvailability
  {
    Available = 0,
    None = 1,
    Indeterminate = -1
  };

  enum class OnlineOnlyServicesOption
  {
    Exclude = 0,
    Include = 1,
    UseAuthoredSettings = 2
  };

  enum class PreplannedPackagingStatus
  {
    Unknown = 0,
    Processing = 1,
    Failed = 2,
    Complete = 3
  };

  enum class PreplannedScheduledUpdatesOption
  {
    NoUpdates = 0,
    DownloadAllUpdates = 1
  };

  enum class PreplannedUpdateMode
  {
    NoUpdates = 0,
    SyncWithFeatureServices = 1,
    DownloadScheduledUpdates = 2
  };

  enum class ReturnLayerAttachmentOption
  {
    None = 0,
    AllLayers = 1,
    ReadOnlyLayers = 2,
    EditableLayers = 3
  };
} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_OfflineMapTypes_H
