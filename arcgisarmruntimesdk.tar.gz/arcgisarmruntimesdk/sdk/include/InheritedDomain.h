// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file InheritedDomain.h

#ifndef QRT_InheritedDomain_H
#define QRT_InheritedDomain_H

// C++ API headers
#include "Domain.h"

namespace QRTImpl {
  class InheritedDomainImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class InheritedDomain : public Domain
  {
  public:
    InheritedDomain();

    InheritedDomain(const InheritedDomain& other);
    InheritedDomain(InheritedDomain&& other) noexcept;
    InheritedDomain(const Domain& other);

    InheritedDomain& operator=(const InheritedDomain& other);
    InheritedDomain& operator=(InheritedDomain&& other) noexcept;

    ~InheritedDomain();

    bool isValid() const;

    /*!
       \internal
     */
    explicit InheritedDomain(std::shared_ptr<QRTImpl::InheritedDomainImpl> impl);
  };

  /*! \internal */
  template<>
  inline InheritedDomain domain_cast<InheritedDomain>(const Domain& domain)
  {
    return domain.domainType() == DomainType::InheritedDomain ? static_cast<InheritedDomain>(domain) : InheritedDomain();
  }

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_InheritedDomain_H
