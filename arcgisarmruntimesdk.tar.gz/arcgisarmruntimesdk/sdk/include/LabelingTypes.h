// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LabelingTypes.h

#ifndef QRT_LabelingTypes_H
#define QRT_LabelingTypes_H

// Other headers
#include "qmetatype.h"

namespace Esri {
namespace ArcGISRuntime {

  enum class LabelAngleRotationType
  {
    Automatic = 0,
    Arithmetic = 1,
    Geographic = 2
  };

  enum class LabelDeconflictionStrategy
  {
    Automatic = 0,
    Dynamic = 1,
    None = 2,
    Static = 3,
    DynamicNeverRemove = 4
  };

  enum class LabelExpressionType
  {
    ArcadeLabelExpression = 1,
    SimpleLabelExpression = 2,
    WebmapLabelExpression = 3
  };

  enum class LabelLineConnection
  {
    Automatic = 0,
    MinimizeLabels = 1,
    None = 2,
    UnambiguousLabels = 3
  };

  enum class LabelMultipartStrategy
  {
    Automatic = 0,
    LabelLargest = 1,
    LabelPerFeature = 2,
    LabelPerPart = 3,
    LabelPerSegment = 4
  };

  enum class LabelOverlapStrategy
  {
    Automatic = 0,
    Allow = 1,
    Avoid = 2,
    Exclude = 3
  };

  enum class LabelOverrunStrategy
  {
    Automatic = 0,
    None = 1,
    Allow = 2
  };

  enum class LabelRemoveDuplicatesStrategy
  {
    Automatic = 0,
    All = 1,
    FeatureType = 2,
    LabelClass = 3,
    None = 4
  };

  enum class LabelRepeatStrategy
  {
    Automatic = 0,
    None = 1,
    Repeat = 2
  };

  enum class LabelStackAlignment
  {
    Automatic = 0,
    Dynamic = 1,
    TextSymbol = 2
  };

  enum class LabelStackBreakPosition
  {
    Automatic = 0,
    After = 1,
    Before = 2
  };

  enum class LabelStackSeparatorBreakPosition
  {
    Automatic = 0,
    After = 1,
    Before = 2
  };

  enum class LabelStackStrategy
  {
    Automatic = 0,
    None = 1,
    Allow = 2
  };

  enum class LabelTextLayout
  {
    Automatic = 0,
    Horizontal = 1,
    Perpendicular = 2,
    Straight = 3,
    FollowFeature = 4
  };

  enum class LabelTextOrientation
  {
    Automatic = 0,
    Direction = 1,
    Screen = 2
  };
} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::LabelStackSeparatorBreakPosition)

#endif // QRT_LabelingTypes_H
