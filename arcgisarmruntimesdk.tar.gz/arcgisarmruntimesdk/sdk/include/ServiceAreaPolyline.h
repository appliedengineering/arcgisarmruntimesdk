// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ServiceAreaPolyline.h

#ifndef QRT_ServiceAreaPolyline_H
#define QRT_ServiceAreaPolyline_H

// C++ API headers
#include "NetworkAnalystTypes.h"
#include "NetworkLocation.h"
#include "Polyline.h"

// STL headers
#include <memory>

namespace QRTImpl { class ServiceAreaPolylineImpl; }

namespace Esri {
namespace ArcGISRuntime {

class ServiceAreaPolyline
{
public:
  ServiceAreaPolyline();
  ServiceAreaPolyline(const ServiceAreaPolyline& other);
  ServiceAreaPolyline(ServiceAreaPolyline&& other) noexcept;
  ~ServiceAreaPolyline();

  ServiceAreaPolyline& operator=(const ServiceAreaPolyline& other);
  ServiceAreaPolyline& operator=(ServiceAreaPolyline&& other) noexcept;

  bool isEmpty() const;

  Polyline geometry() const;

  NetworkLocation fromNetworkLocation() const;
  NetworkLocation toNetworkLocation() const;

  double fromCumulativeCost(const QString& attributeName) const;
  double toCumulativeCost(const QString& attributeName) const;

  /*!
     \internal
   */
  explicit ServiceAreaPolyline(std::shared_ptr<QRTImpl::ServiceAreaPolylineImpl> impl);

private:
  std::shared_ptr<QRTImpl::ServiceAreaPolylineImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ServiceAreaPolyline_H
