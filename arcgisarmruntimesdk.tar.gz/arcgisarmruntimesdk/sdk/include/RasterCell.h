// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file RasterCell.h

#ifndef QRT_RasterCell_H
#define QRT_RasterCell_H

// C++ API headers
#include "GeoElement.h"
#include "Object.h"

namespace QRTImpl { class RasterCellImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class RasterCell : public Object, public GeoElement
  {
    Q_OBJECT

  public:
    ~RasterCell() override;

    AttributeListModel* attributes() const override;

    Geometry geometry() const override;
    void setGeometry(const Geometry& geometry) override;

    /*! \internal */
    RasterCell(std::shared_ptr<QRTImpl::RasterCellImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::RasterCellImpl> getImpl() const;
    std::shared_ptr<QRTImpl::GeoElementImpl> iGetImpl() const override;

  signals:
    void geometryChanged();

  private:
    Q_DISABLE_COPY(RasterCell)

    std::shared_ptr<QRTImpl::RasterCellImpl> m_impl;

    RasterCell() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_RasterCell_H
