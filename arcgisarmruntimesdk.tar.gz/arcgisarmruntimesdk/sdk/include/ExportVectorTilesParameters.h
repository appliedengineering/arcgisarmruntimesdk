// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ExportVectorTilesParameters.h

#ifndef QRT_ExportVectorTilesParameters_H
#define QRT_ExportVectorTilesParameters_H

// C++ API headers
#include "Geometry.h"
#include "Object.h"

namespace QRTImpl { class ExportVectorTilesParametersImpl; }

namespace Esri {
namespace ArcGISRuntime {

enum class EsriVectorTilesDownloadOption;

class ExportVectorTilesParameters
{
public:
  ExportVectorTilesParameters();
  ExportVectorTilesParameters(const Geometry& areaOfInterest);
  ExportVectorTilesParameters(const ExportVectorTilesParameters& other);
  ExportVectorTilesParameters(ExportVectorTilesParameters&& other) noexcept;
  ~ExportVectorTilesParameters();

  ExportVectorTilesParameters& operator=(const ExportVectorTilesParameters& other);
  ExportVectorTilesParameters& operator=(ExportVectorTilesParameters&& other) noexcept;

  Geometry areaOfInterest() const;
  void setAreaOfInterest(const Geometry& areaOfInterest);

  EsriVectorTilesDownloadOption esriVectorTilesDownloadOption() const;
  void setEsriVectorTilesDownloadOption(EsriVectorTilesDownloadOption esriVectorTilesDownloadOption);

  int maxLevel() const;
  void setMaxLevel(int maxLevel);

  /*!
     \internal
   */
  explicit ExportVectorTilesParameters(const std::shared_ptr<QRTImpl::ExportVectorTilesParametersImpl>& impl);
  std::shared_ptr<QRTImpl::ExportVectorTilesParametersImpl> getImpl() const;

private:
  std::shared_ptr<QRTImpl::ExportVectorTilesParametersImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::ExportVectorTilesParameters)

#endif // QRT_ExportVectorTilesParameters_H
