// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ImageTiledLayer.h

#ifndef QRT_ImageTiledLayer_H
#define QRT_ImageTiledLayer_H

// C++ API headers
#include "ImageAdjustmentLayer.h"
#include "MapTypes.h"
#include "TileInfo.h"
#include "TileKey.h"

namespace Esri {
namespace ArcGISRuntime {

  class ImageTiledLayer : public ImageAdjustmentLayer
  {
    Q_OBJECT

  public:
    ImageTiledLayer(const TileInfo& tileInfo, const Envelope& fullExtent, QObject* parent = nullptr);
    ~ImageTiledLayer() override;

    NoDataTileBehavior noDataTileBehavior() const;
    void setNoDataTileBehavior(NoDataTileBehavior noDataTileBehavior);

    TileInfo tileInfo() const;

    virtual void setAttribution(const QString& attribution);

  signals:
    // custom tiled layer api
    void tileRequest(const Esri::ArcGISRuntime::TileKey& tileKey);
    void cancelTileRequest(const Esri::ArcGISRuntime::TileKey& tileKey);

  protected:
    // custom tiled layer api
    void setTileData(const TileKey& tileKey, const QByteArray& data);
    void setTileError(const TileKey& tileKey, const QString& error);
    void setNoDataTile(const TileKey& tileKey);

    /*! \internal */
    ImageTiledLayer(std::shared_ptr<QRTImpl::LayerImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(ImageTiledLayer)
    void connectSignals();
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ImageTiledLayer_H
