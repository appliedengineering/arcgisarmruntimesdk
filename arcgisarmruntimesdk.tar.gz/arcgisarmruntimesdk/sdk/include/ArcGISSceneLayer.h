// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ArcGISSceneLayer.h

#ifndef QRT_ArcGISSceneLayer_H
#define QRT_ArcGISSceneLayer_H

// C++ API headers
#include "ApiKeyResource.h"
#include "Credential.h"
#include "Feature.h"
#include "FeatureQueryResult.h"
#include "FeatureTable.h"
#include "FloorAware.h"
#include "Layer.h"
#include "RemoteResource.h"
#include "SceneViewTypes.h"
#include "TaskWatcher.h"

// Qt headers
#include <QList>
#include <QUrl>
#include <QUuid>

namespace QRTImpl { class ArcGISSceneLayerImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class ArcGISSceneLayer : public Layer,
                           public ApiKeyResource,
                           public RemoteResource,
                           public FloorAware
  {
    Q_OBJECT

  public:
    explicit ArcGISSceneLayer(const QUrl& url, QObject* parent = nullptr);
    ArcGISSceneLayer(const QUrl& url, Credential* credential, QObject* parent = nullptr);
    explicit ArcGISSceneLayer(Item* item, QObject* parent = nullptr);
    ~ArcGISSceneLayer() override;

    SceneLayerDataType dataType() const;

    FeatureTable* featureTable() const;

    void clearSelection();

    TaskWatcher selectedFeatures();

    void selectFeature(Feature* feature);
    void selectFeatures(const QList<Feature*>& features);

    void unselectFeature(Feature* feature);
    void unselectFeatures(const QList<Feature*>& features);

    double altitudeOffset() const;
    void setAltitudeOffset(double altitudeOffset);

    SurfacePlacement surfacePlacement() const;
    void setSurfacePlacement(SurfacePlacement surfacePlacement);

    // FloorAware interface methods
    LayerFloorDefinition* floorDefinition() const override;
    void setFloorDefinition(LayerFloorDefinition* floorDefinition) override;

    // RemoteResource interface methods
    QUrl url() const override;
    Credential* credential() const override;
    RequestConfiguration requestConfiguration() const override;
    void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

    // APIKeyResource interface methods
    QString apiKey() const override;
    void setApiKey(const QString& apiKey) override;

    /*! \internal */
    ArcGISSceneLayer(std::shared_ptr<QRTImpl::ArcGISSceneLayerImpl> impl, QObject* parent);

  signals:
    void selectedFeaturesCompleted(QUuid taskId, Esri::ArcGISRuntime::FeatureQueryResult* featureQueryResult);

  private:
    Q_DISABLE_COPY(ArcGISSceneLayer)

    ArcGISSceneLayer() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ArcGISSceneLayer_H
