// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ServiceTimeInfo.h

#ifndef QRT_ServiceTimeInfo_H
#define QRT_ServiceTimeInfo_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "Deprecated.h"
#include "ServiceTypes.h"
#include "TimeExtent.h"
#include "TimeReference.h"
#include "TimeValue.h"

// STL headers
#include <memory>

namespace QRTImpl {
  class ServiceTimeInfoImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class ServiceTimeInfo
  {
  public:
    ServiceTimeInfo();
    ~ServiceTimeInfo();
    ServiceTimeInfo(const ServiceTimeInfo& other);
    ServiceTimeInfo(ServiceTimeInfo&& other) noexcept;
    ServiceTimeInfo& operator=(const ServiceTimeInfo& other);
    ServiceTimeInfo& operator=(ServiceTimeInfo&& other) noexcept;

    QRT_DEPRECATED int defaultTimeInterval() const;

    QRT_DEPRECATED TimeUnit defaultTimeIntervalUnit() const;

    QRT_DEPRECATED int defaultTimeWindow() const;

    bool hasLiveData() const;

    TimeReference timeReference() const;

    TimeRelation timeRelation() const;

    TimeExtent timeExtent() const;

    TimeValue defaultInterval() const;

    explicit ServiceTimeInfo(std::shared_ptr<QRTImpl::ServiceTimeInfoImpl> impl);

  private:
    std::shared_ptr<QRTImpl::ServiceTimeInfoImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ServiceTimeInfo_H
