// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ContingentNullValue.h

#ifndef QRT_ContingentNullValue_H
#define QRT_ContingentNullValue_H

// C++ API headers
#include "ContingentValue.h"

namespace QRTImpl { class ContingentNullValueImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class ContingentNullValue : public ContingentValue
  {
    Q_OBJECT

  public:
    ~ContingentNullValue() override;

    ContingentNullValue(std::shared_ptr<QRTImpl::ContingentValueImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::ContingentNullValueImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(ContingentNullValue)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ContingentNullValue_H
