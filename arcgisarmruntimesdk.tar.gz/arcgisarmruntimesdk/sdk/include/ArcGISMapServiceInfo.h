// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ArcGISMapServiceInfo.h

#ifndef QRT_ArcGISMapServiceInfo_H
#define QRT_ArcGISMapServiceInfo_H

// C++ API headers
#include "Envelope.h"
#include "IdInfo.h"
#include "JsonSerializable.h"
#include "MapServiceCapabilities.h"
#include "Object.h"
#include "ServiceDocumentInfo.h"
#include "ServiceTimeInfo.h"
#include "TileInfo.h"
#include "Unit.h"

// Qt headers
#include <QStringList>

// STL headers
#include <memory>

namespace QRTImpl {
  class ArcGISMapServiceInfoImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class ArcGISMapServiceInfo : public JsonSerializable
  {
  public:
    ArcGISMapServiceInfo();

    ArcGISMapServiceInfo(const ArcGISMapServiceInfo& other);
    ArcGISMapServiceInfo(ArcGISMapServiceInfo&& other) noexcept;

    ~ArcGISMapServiceInfo() override;

    ArcGISMapServiceInfo& operator=(const ArcGISMapServiceInfo& other);
    ArcGISMapServiceInfo& operator=(ArcGISMapServiceInfo&& other) noexcept;

    bool isEmpty() const;

    QUrl url() const;

    QString attribution() const;

    MapServiceCapabilities capabilities() const;

    QString currentVersion() const;

    QString description() const;

    ServiceDocumentInfo documentInfo() const;

    bool isExportTileCacheCompactV2Allowed() const;

    bool isExportTilesAllowed() const;

    Envelope fullExtent() const;

    Envelope initialExtent() const;

    QList<IdInfo> layerInfos() const;

    QString mapName() const;

    int maxExportTilesCount() const;

    int maxImageHeight() const;

    int maxImageWidth() const;

    int maxRecordCount() const;

    double maxScale() const;

    double minScale() const;

    QString serviceDescription() const;

    ServiceType serviceSourceType() const;

    bool isSingleFusedMapCache() const;

    SpatialReference spatialReference() const;

    QStringList supportedImageFormatTypes() const;

    bool isSupportsDynamicLayers() const;

    QList<IdInfo> tableInfos() const;

    TileInfo tileInfo() const;

    QStringList tileServers() const;

    ServiceTimeInfo timeInfo() const;

    Unit unit() const;

    // JsonSerializable Interface methods
    static ArcGISMapServiceInfo fromJson(const QString& json);
    QString toJson() const override;
    QJsonObject unknownJson() const override;
    QJsonObject unsupportedJson() const override;

    /*!
       \internal
     */
    explicit ArcGISMapServiceInfo(std::shared_ptr<QRTImpl::ArcGISMapServiceInfoImpl> impl);

  private:
    std::shared_ptr<QRTImpl::ArcGISMapServiceInfoImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ArcGISMapServiceInfo_H
