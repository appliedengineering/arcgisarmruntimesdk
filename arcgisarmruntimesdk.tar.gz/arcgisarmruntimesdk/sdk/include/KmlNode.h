// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlNode.h

#ifndef QRT_KmlNode_H
#define QRT_KmlNode_H

// C++ API headers
#include "Envelope.h"
#include "Error.h"
#include "KmlViewpoint.h"
#include "Object.h"

// Qt headers
#include <QColor>
#include <QImage>
#include <QUuid>

namespace QRTImpl { class KmlNodeImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class TaskWatcher;
  class KmlStyle;
  class TimeExtent;

  class KmlNode : public Object
  {
    Q_OBJECT

  public:
    ~KmlNode() override;

    QString description() const;
    void setDescription(const QString& description);

    Envelope extent() const;

    QColor balloonBackgroundColor() const;

    QString balloonContent() const;

    KmlStyle* highlightStyle();
    void setHighlightStyle(KmlStyle* highlightStyle);

    KmlStyle* style();
    void setStyle(KmlStyle* style);

    TimeExtent timeExtent() const;
    void setTimeExtent(const TimeExtent& timeExtent);

    bool isHighlighted() const;
    void setHighlighted(bool highlighted);

    bool isVisible() const;
    void setVisible(bool visible);

    QString kmlNodeId() const;
    void setKmlNodeId(const QString& kmlNodeId);

    QString name() const;
    void setName(const QString& name);

    KmlNode* parentNode() const;

    QString snippet() const;
    void setSnippet(const QString& snippet);

    int snippetMaxLines() const;
    void setSnippetMaxLines(int maxLines);

    QImage uxIcon() const;

    int uxIconId() const;

    QColor uxIconColor() const;

    KmlViewpoint viewpoint() const;
    void setViewpoint(const KmlViewpoint& viewpoint);

    KmlNodeType kmlNodeType() const;

    Error refreshError() const;

    KmlRefreshStatus refreshStatus() const;

    QString address() const;
    void setAddress(const QString& address);

    TaskWatcher saveAs(const QString& kmzFile) const;

    /*! \internal */
    KmlNode(std::shared_ptr<QRTImpl::KmlNodeImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::KmlNodeImpl> getImpl() const;

  signals:
    void iconUpdated();
    void refreshStatusChanged();
    void saveAsCompleted(QUuid taskId);

  protected:
    std::shared_ptr<QRTImpl::KmlNodeImpl> m_impl;

  private:
    Q_DISABLE_COPY(KmlNode)

    void connectNotify(const QMetaMethod& signal) override;
    void disconnectNotify(const QMetaMethod& signal) override;

    QMetaObject::Connection m_nodeRefreshStatusChangedConn;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlNode_H
