// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityTierGroup.h

#ifndef QRT_UtilityTierGroup_H
#define QRT_UtilityTierGroup_H

// C++ API headers
#include "Object.h"

namespace QRTImpl { class UtilityTierGroupImpl; }

namespace Esri {
namespace ArcGISRuntime {

class UtilityTier;

class UtilityTierGroup : public Object
{
  Q_OBJECT
public:
  ~UtilityTierGroup() override;

  QString name() const;

  QList<UtilityTier*> tiers() const;

  UtilityTier* tier(const QString& tierName) const;

  /*! \internal */
  UtilityTierGroup(std::shared_ptr<QRTImpl::UtilityTierGroupImpl> impl, QObject* parent);

private:
  std::shared_ptr<QRTImpl::UtilityTierGroupImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityTierGroup_H
