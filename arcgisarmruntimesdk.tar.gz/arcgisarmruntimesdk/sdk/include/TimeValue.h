// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file TimeValue.h

#ifndef QRT_TimeValue_H
#define QRT_TimeValue_H

// C++ API headers
#include "ServiceTypes.h"

// STL headers
#include <memory>

namespace QRTImpl { class TimeValueImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class TimeValue
  {
  public:
    TimeValue();
    TimeValue(double duration, TimeUnit unit);
    TimeValue(const TimeValue& other);
    TimeValue(TimeValue&& other) noexcept;

    TimeValue& operator=(const TimeValue& other);
    TimeValue& operator=(TimeValue&& other) noexcept;

    bool isEmpty() const;

    double duration() const;
    TimeUnit unit() const;

    /*! \internal */
    explicit TimeValue(std::shared_ptr<QRTImpl::TimeValueImpl> impl);
    std::shared_ptr<QRTImpl::TimeValueImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::TimeValueImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_TimeValue_H
