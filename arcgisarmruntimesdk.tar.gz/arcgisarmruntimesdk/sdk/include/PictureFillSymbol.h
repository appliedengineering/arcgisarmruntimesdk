// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PictureFillSymbol.h

#ifndef QRT_PictureFillSymbol_H
#define QRT_PictureFillSymbol_H

// C++ API headers
#include "Credential.h"
#include "FillSymbol.h"
#include "Loadable.h"
#include "RemoteResource.h"

// Qt headers
#include <QImage>
#include <QUrl>

namespace QRTImpl { class PictureFillSymbolImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class MultilayerPolygonSymbol;

  class PictureFillSymbol : public FillSymbol, public Loadable, public RemoteResource
  {
    Q_OBJECT

  public:
    explicit PictureFillSymbol(const QImage& image, QObject* parent = nullptr);
    explicit PictureFillSymbol(const QUrl& url, QObject* parent = nullptr);
    PictureFillSymbol(const QUrl& url, Credential* credential, QObject* parent = nullptr);
    ~PictureFillSymbol() override;

    QImage image() const;

    float height() const;
    void setHeight(float height);

    float width() const;
    void setWidth(float width);

    float opacity() const;
    void setOpacity(float opacity);

    double angle() const;
    void setAngle(double angle);

    double scaleX() const;
    void setScaleX(double scaleX);

    double scaleY() const;
    void setScaleY(double scaleY);

    MultilayerPolygonSymbol* toMultilayerSymbol() const;

    // Loadable Interface methods
    Error loadError() const override;
    LoadStatus loadStatus() const override;
    void cancelLoad() override;
    void load() override;
    void retryLoad() override;

    // RemoteResource interface methods
    QUrl url() const override;
    Credential* credential() const override;
    RequestConfiguration requestConfiguration() const override;
    void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

    /*! \internal */
    PictureFillSymbol(std::shared_ptr<QRTImpl::SymbolImpl> impl, QObject* parent);

  signals:
    void doneLoading(Esri::ArcGISRuntime::Error loadError);
    void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

  private:
    Q_DISABLE_COPY(PictureFillSymbol)

    void connectSignals();
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PictureFillSymbol_H
