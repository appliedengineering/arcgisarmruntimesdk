// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file SimpleLineSymbol.h

#ifndef QRT_SimpleLineSymbol_H
#define QRT_SimpleLineSymbol_H

// C++ API headers
#include "LineSymbol.h"
#include "MultilayerPolylineSymbol.h"

namespace QRTImpl { class SimpleLineSymbolImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class SimpleLineSymbol : public LineSymbol
  {
    Q_OBJECT

  public:
    explicit SimpleLineSymbol(QObject* parent = nullptr);
    SimpleLineSymbol(SimpleLineSymbolStyle style, const QColor& color, float width, QObject* parent = nullptr);
    SimpleLineSymbol(SimpleLineSymbolStyle style,
                     const QColor& color,
                     float width,
                     SimpleLineSymbolMarkerStyle markerStyle,
                     SimpleLineSymbolMarkerPlacement markerPlacement,
                     QObject* parent = nullptr);

    ~SimpleLineSymbol() override;

    SimpleLineSymbolStyle style() const;
    void setStyle(SimpleLineSymbolStyle style);

    SimpleLineSymbolMarkerStyle markerStyle() const;
    void setMarkerStyle(SimpleLineSymbolMarkerStyle markerStyle);

    SimpleLineSymbolMarkerPlacement markerPlacement() const;
    void setMarkerPlacement(SimpleLineSymbolMarkerPlacement markerPlacement);

    MultilayerPolylineSymbol* toMultilayerSymbol(QObject* parent = nullptr) const;

    /*! \internal */
    SimpleLineSymbol(std::shared_ptr<QRTImpl::SymbolImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::SimpleLineSymbolImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(SimpleLineSymbol)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_SimpleLineSymbol_H
