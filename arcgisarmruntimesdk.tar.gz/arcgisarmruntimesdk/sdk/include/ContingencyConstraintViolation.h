// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ContingencyConstraintViolation.h

#ifndef QRT_ContingencyConstraintViolation_H
#define QRT_ContingencyConstraintViolation_H

// C++ API headers
#include "GeodatabaseTypes.h"
#include "Object.h"

namespace QRTImpl { class ContingencyConstraintViolationImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class FieldGroup;

  class ContingencyConstraintViolation : public Object
  {
    Q_OBJECT

  public:
    ~ContingencyConstraintViolation() override;

    FieldGroup* fieldGroup() const;

    ContingencyConstraintViolationType type() const;

    ContingencyConstraintViolation(std::shared_ptr<QRTImpl::ContingencyConstraintViolationImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::ContingencyConstraintViolationImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(ContingencyConstraintViolation)
    std::shared_ptr<QRTImpl::ContingencyConstraintViolationImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ContingencyConstraintViolation_H
