// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file FrameCameraAddRastersParameters.h

#ifndef QRT_FrameCameraAddRastersParameters_H
#define QRT_FrameCameraAddRastersParameters_H

// C++ API headers
#include "AddRastersParameters.h"

// Qt headers
#include <QString>

namespace QRTImpl { class FrameCameraAddRastersParametersImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class FrameCameraAddRastersParameters : public AddRastersParameters
  {

  public:
    FrameCameraAddRastersParameters();
    FrameCameraAddRastersParameters(const FrameCameraAddRastersParameters& other);
    FrameCameraAddRastersParameters(const AddRastersParameters& other);
    FrameCameraAddRastersParameters(FrameCameraAddRastersParameters&& other) noexcept;

    ~FrameCameraAddRastersParameters() override;

    FrameCameraAddRastersParameters& operator=(const FrameCameraAddRastersParameters& other);
    FrameCameraAddRastersParameters& operator=(FrameCameraAddRastersParameters&& other) noexcept;

    QString camerasFile() const;
    void setCamerasFile(const QString& cameras);

    QString framesFile() const;
    void setFramesFile(const QString& frames);

    bool isShareRasterInfo() const;
    void setShareRasterInfo(bool status);

    /*!
       \internal
     */
    explicit FrameCameraAddRastersParameters(const std::shared_ptr<QRTImpl::FrameCameraAddRastersParametersImpl>& impl);
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_FrameCameraAddRastersParameters_H
