// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ImageFrame.h

#ifndef QRT_ImageFrame_H
#define QRT_ImageFrame_H

// C++ API headers
#include "Loadable.h"
#include "Object.h"
#include "RemoteResource.h"

// Qt headers
#include <QImage>
#include <QUrl>

namespace QRTImpl { class ImageFrameImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class ImageOverlay;
  class Envelope;
  class Polygon;

  class ImageFrame : public Object, public Loadable, public RemoteResource
  {
    Q_OBJECT

  public:
    explicit ImageFrame(const QUrl& url, QObject* parent = nullptr);
    ImageFrame(const QUrl& url, Credential* credential, QObject* parent = nullptr);

    ImageFrame(const QUrl& url, const Envelope& extent, QObject* parent = nullptr);
    ImageFrame(const QUrl& url, const Envelope& extent, Credential* credential, QObject* parent = nullptr);

    ImageFrame(const QUrl& url, const Polygon& quadrilateral, QObject* parent = nullptr);
    ImageFrame(const QUrl& url, const Polygon& quadrilateral, Credential* credential, QObject* parent = nullptr);

    ImageFrame(const QImage& image, const Envelope& extent, QObject* parent = nullptr);
    ImageFrame(const QImage& image, const Polygon& quadrilateral, QObject* parent = nullptr);
    
    ~ImageFrame() override;

    Envelope extent() const;
    Polygon quadrilateral() const;
    QImage image() const;

    // Loadable Interface methods
    Error loadError() const override;

    LoadStatus loadStatus() const override;

    void cancelLoad() override;

    void load() override;

    void retryLoad() override;

    // RemoteResource interface methods
    QUrl url() const override;
    Credential* credential() const override;
    RequestConfiguration requestConfiguration() const override;
    void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

    ImageFrame(std::shared_ptr<QRTImpl::ImageFrameImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::ImageFrameImpl> getImpl() const;
    
  signals:
    void doneLoading(Esri::ArcGISRuntime::Error loadError);
    void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

  private:
    Q_DISABLE_COPY(ImageFrame)

    std::shared_ptr<QRTImpl::ImageFrameImpl> m_impl;

    void connectSignals();
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ImageFrame_H
