// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file SceneView.h

#ifndef QRT_SceneView_H
#define QRT_SceneView_H

// C++ API headers
#include "AnalysisOverlayListModel.h"
#include "Camera.h"
#include "CameraController.h"
#include "Deprecated.h"
#include "GeoView.h"
#include "LocationToScreenResult.h"
#include "SceneViewTypes.h"

// Qt headers
#include <QtGlobal>

namespace QRTImpl {
  class SceneViewImpl;
  class DeviceImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class Scene;
  class ImageOverlayListModel;

  class SceneView : public GeoView
  {
  public:
    ~SceneView() override;

    QRT_DEPRECATED int sceneHeight() const;
    QRT_DEPRECATED int sceneWidth() const;

    void setArcGISScene(Scene* scene);
    Scene* arcGISScene() const;

    QColor ambientLightColor() const;
    void setAmbientLightColor(const QColor& color);

    AtmosphereEffect atmosphereEffect() const;
    void setAtmosphereEffect(AtmosphereEffect atmosphereEffect);

    LightingMode sunLighting() const;
    void setSunLighting(LightingMode lightingMode);

    QDateTime sunTime() const;
    void setSunTime(const QDateTime& sunTime);

    LocationToScreenResult locationToScreen(const Point& scenePoint) const;
    Point screenToBaseSurface(double screenX, double screenY) const;
    TaskWatcher screenToLocation(double screenX, double screenY);

    Camera currentViewpointCamera() const;
    void setViewpointCameraAndWait(const Camera& camera);

    SpaceEffect spaceEffect() const;
    void setSpaceEffect(SpaceEffect spaceEffect);

    double fieldOfView() const;
    void setFieldOfView(double angle);

    ImageOverlayListModel* imageOverlays() const;

    double fieldOfViewDistortionRatio() const;
    void setFieldOfViewAndDistortionRatio(double angle, double distortionRatio);
    void setFieldOfViewFromLensIntrinsics(double xFocalLength, double yFocalLength,
                                          double xPrincipal, double yPrincipal,
                                          double xImageSize, double yImageSize,
                                          DeviceOrientation deviceOrientation);

    CameraController* cameraController() const;
    void setCameraController(CameraController* cameraController);

    AnalysisOverlayListModel* analysisOverlays() const;

    void renderFrame();

    bool isManualRendering() const;
    virtual void setManualRendering(bool manualRendering);

#if defined(Q_OS_ANDROID) || defined(Q_QDOC)
    static quint64 memoryLimit();
    static void setMemoryLimit(quint64 memoryLimitBytes);
#endif

    // async methods
    TaskWatcher setViewpointCamera(const Camera& camera);
    TaskWatcher setViewpointCamera(const Camera& camera, float durationSeconds);

    /*!
      \internal
     */
    explicit SceneView(std::shared_ptr<QRTImpl::SceneViewImpl> impl);

  protected:
    SceneView(int width, int height);

    virtual void screenToLocationCompletedEvent(QUuid taskId, const Point& location);
    virtual void setViewpointCameraCompletedEvent(bool success);

  private:
    Q_DISABLE_COPY(SceneView)

    void connectSignals();

    QObject m_sceneViewConnectionContext;
  };

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_INTERFACE(Esri::ArcGISRuntime::SceneView, "Esri::ArcGISRuntime::SceneView")

#endif // QRT_SceneView_H
