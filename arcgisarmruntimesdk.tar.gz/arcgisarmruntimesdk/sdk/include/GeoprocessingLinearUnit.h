// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeoprocessingLinearUnit.h

#ifndef QRT_GeoprocessingLinearUnit_H
#define QRT_GeoprocessingLinearUnit_H

// C++ API headers
#include "GeoprocessingParameter.h"
#include "GeoprocessingTypes.h"
#include "LinearUnit.h"

namespace QRTImpl { class GeoprocessingLinearUnitImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class GeoprocessingLinearUnit : public GeoprocessingParameter
  {
    Q_OBJECT

  public:
    explicit GeoprocessingLinearUnit(QObject* parent = nullptr);
    explicit GeoprocessingLinearUnit(double distance, QObject* parent = nullptr);
    GeoprocessingLinearUnit(double distance, GeoprocessingLinearUnits geoprocessingUnit, QObject* parent = nullptr);
    GeoprocessingLinearUnit(double distance, const LinearUnit& unit, QObject* parent = nullptr);
    GeoprocessingLinearUnit(double distance, LinearUnitId unitId, QObject* parent = nullptr);
    ~GeoprocessingLinearUnit() override;

    double distance() const;
    void setDistance(double distance);

    GeoprocessingLinearUnits unit() const;
    void setUnit(GeoprocessingLinearUnits unit);

    LinearUnit linearUnit() const;

    /*!
       \internal
     */
    GeoprocessingLinearUnit(std::shared_ptr<QRTImpl::GeoprocessingLinearUnitImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(GeoprocessingLinearUnit)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeoprocessingLinearUnit_H
