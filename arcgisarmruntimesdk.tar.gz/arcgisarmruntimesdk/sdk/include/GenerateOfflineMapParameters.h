// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GenerateOfflineMapParameters.h

#ifndef QRT_GenerateOfflineMapParameters_H
#define QRT_GenerateOfflineMapParameters_H

// C++ API headers
#include "Geometry.h"
#include "OfflineMapItemInfo.h"
#include "OfflineMapTypes.h"
#include "TaskTypes.h"

namespace QRTImpl {
  class GenerateOfflineMapParametersImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  enum class EsriVectorTilesDownloadOption;

  class GenerateOfflineMapParameters
  {
  public:
    GenerateOfflineMapParameters();
    GenerateOfflineMapParameters(const Geometry& areaOfInterest, double minScale, double maxScale);
    GenerateOfflineMapParameters(const GenerateOfflineMapParameters& other);
    GenerateOfflineMapParameters(GenerateOfflineMapParameters&& other) noexcept;
    ~GenerateOfflineMapParameters();

    GenerateOfflineMapParameters& operator=(const GenerateOfflineMapParameters& other);
    GenerateOfflineMapParameters& operator=(GenerateOfflineMapParameters&& other) noexcept;

    Geometry areaOfInterest() const;
    void setAreaOfInterest(const Geometry& areaOfInterest);

    AttachmentSyncDirection attachmentSyncDirection() const;
    void setAttachmentSyncDirection(AttachmentSyncDirection attachmentSyncDirection);

    bool isContinueOnErrors() const;
    void setContinueOnErrors(bool continueOnErrors);

    DestinationTableRowFilter destinationTableRowFilter() const;
    void setDestinationTableRowFilter(DestinationTableRowFilter destinationTableRowFilter);

    EsriVectorTilesDownloadOption esriVectorTilesDownloadOption() const;
    void setEsriVectorTilesDownloadOption(EsriVectorTilesDownloadOption esriVectorTilesDownloadOption);

    bool isIncludeBasemap() const;
    void setIncludeBasemap(bool includeBasemap);

    bool isDefinitionExpressionFilterEnabled() const;
    void setDefinitionExpressionFilterEnabled(bool definitionExpressionFilterEnabled);

    OfflineMapItemInfo itemInfo() const;
    void setItemInfo(const OfflineMapItemInfo& itemInfo);

    double maxScale() const;
    void setMaxScale(double maxScale);

    double minScale() const;
    void setMinScale(double minScale);

    OnlineOnlyServicesOption onlineOnlyServicesOption() const;
    void setOnlineOnlyServicesOption(OnlineOnlyServicesOption onlineOnlyServicesOption);

    QString referenceBasemapDirectory() const;
    void setReferenceBasemapDirectory(const QString& referenceBasemapDirectory);

    QString referenceBasemapFilename() const;
    void setReferenceBasemapFilename(const QString& referenceBasemapFilename);

    ReturnLayerAttachmentOption returnLayerAttachmentOption() const;
    void setReturnLayerAttachmentOption(ReturnLayerAttachmentOption returnLayerAttachmentOption);

    bool isReturnSchemaOnlyForEditableLayers() const;
    void setReturnSchemaOnlyForEditableLayers(bool returnSchemaOnlyForEditableLayers);

    GenerateOfflineMapUpdateMode updateMode() const;
    void setUpdateMode(GenerateOfflineMapUpdateMode updateMode);

    std::shared_ptr<QRTImpl::GenerateOfflineMapParametersImpl> getImpl() const;
    /*!
       \internal
     */
    explicit GenerateOfflineMapParameters(std::shared_ptr<QRTImpl::GenerateOfflineMapParametersImpl> impl);

  private:
    std::shared_ptr<QRTImpl::GenerateOfflineMapParametersImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::GenerateOfflineMapParameters)

#endif // QRT_GenerateOfflineMapParameters_H
