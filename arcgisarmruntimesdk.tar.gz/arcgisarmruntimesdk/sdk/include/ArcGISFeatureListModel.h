// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ArcGISFeatureListModel.h

#ifndef QRT_ArcGISFeatureListModel_H
#define QRT_ArcGISFeatureListModel_H

// C++ API headers
#include "Iterable.h"

// Qt headers
#include <QAbstractListModel>
#include <QList>
#include <QUuid>

// STL headers
#include <memory>

namespace QRTImpl {
  class UtilityNetworkImpl;
  class ArcGISFeatureImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class ArcGISFeature;
  class Feature;

  class ArcGISFeatureListModel : public QAbstractListModel, public Iterable<ArcGISFeature*>
  {
    Q_OBJECT

  public:
    ~ArcGISFeatureListModel() override;

    bool isEmpty() const;

    ArcGISFeature* at(int index) const override;

    bool contains(ArcGISFeature* area) const;

    int indexOf(ArcGISFeature* area) const;

    ArcGISFeature* first() const;

    ArcGISFeature* last() const;

    QList<Feature*> features(QObject* parent = nullptr) const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    /*!
       \internal
     */
    ArcGISFeatureListModel(const std::shared_ptr<QRTImpl::UtilityNetworkImpl>& impl,
                           QObject* parent);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(ArcGISFeatureListModel)

    ArcGISFeatureListModel() = delete;
    void setupRoles();
    int size() const override;

    QHash<int, QByteArray> m_roles;
    QList<std::shared_ptr<QRTImpl::ArcGISFeatureImpl>> m_data;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ArcGISFeatureListModel_H
