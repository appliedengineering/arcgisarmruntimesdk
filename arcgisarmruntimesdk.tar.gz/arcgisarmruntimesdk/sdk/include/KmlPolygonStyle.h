// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlPolygonStyle.h

#ifndef QRT_KmlPolygonStyle_H
#define QRT_KmlPolygonStyle_H

// C++ API headers
#include "KmlColorStyle.h"

namespace QRTImpl { class KmlPolygonStyleImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class KmlPolygonStyle : public KmlColorStyle
  {
    Q_OBJECT
  public:
    explicit KmlPolygonStyle(const QColor& fillColor, QObject* parent = nullptr);
    ~KmlPolygonStyle() override;

    void setFilled(bool filled);
    bool isFilled()const ;

    void setOutlined(bool outlined);
    bool isOutlined() const;

    /*! \internal */
    KmlPolygonStyle(std::shared_ptr<QRTImpl::KmlPolygonStyleImpl> impl,
                    QObject* parent);
    std::shared_ptr<QRTImpl::KmlPolygonStyleImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(KmlPolygonStyle)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlPolygonStyle_H
