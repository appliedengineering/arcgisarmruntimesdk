// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityNetworkDefinition.h

#ifndef QRT_UtilityNetworkDefinition_H
#define QRT_UtilityNetworkDefinition_H

// C++ API headers
#include "Object.h"

// Qt headers
#include <QList>
#include <QString>

namespace QRTImpl { class UtilityNetworkDefinitionImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class Envelope;
  class UtilityCategory;
  class UtilityDomainNetwork;
  class UtilityNetworkAttribute;
  class UtilityNetworkSource;
  class UtilityTerminalConfiguration;

  class UtilityNetworkDefinition : public Object
  {
    Q_OBJECT

  public:
    ~UtilityNetworkDefinition() override;

    QList<UtilityCategory*> categories() const;

    QList<UtilityDomainNetwork*> domainNetworks() const;
    UtilityDomainNetwork* domainNetwork(const QString& name) const;

    Envelope extent() const;

    QList<UtilityNetworkAttribute*> networkAttributes() const;
    UtilityNetworkAttribute* networkAttribute(const QString& name) const;

    QList<UtilityNetworkSource*> networkSources() const;
    UtilityNetworkSource* networkSource(const QString& name) const;

    int schemaVersion() const;

    QList<UtilityTerminalConfiguration*> terminalConfigurations() const;

    /*! \internal */
    UtilityNetworkDefinition(std::shared_ptr<QRTImpl::UtilityNetworkDefinitionImpl> impl, QObject* parent);

  private:
    std::shared_ptr<QRTImpl::UtilityNetworkDefinitionImpl> m_impl;

    Q_DISABLE_COPY(UtilityNetworkDefinition)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityNetworkDefinition_H
