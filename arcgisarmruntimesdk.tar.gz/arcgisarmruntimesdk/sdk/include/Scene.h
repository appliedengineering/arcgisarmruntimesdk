// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file Scene.h

#ifndef QRT_Scene_H
#define QRT_Scene_H

// C++ API headers
#include "GeoModel.h"
#include "SceneViewTypes.h"
#include "Surface.h"

namespace QRTImpl { class SceneImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class Scene : public GeoModel
  {
    Q_OBJECT

  public:
    explicit Scene(QObject* parent = nullptr);
    explicit Scene(Surface* baseSurface, QObject* parent = nullptr);
    explicit Scene(Basemap* basemap, QObject* parent = nullptr);
    explicit Scene(BasemapType basemapType, QObject* parent = nullptr);
    explicit Scene(SceneViewTilingScheme sceneViewTilingScheme, QObject* parent = nullptr);
    explicit Scene(const QUrl& url, QObject* parent = nullptr);
    explicit Scene(Item* item, QObject* parent = nullptr);
    explicit Scene(BasemapStyle basemapStyle, QObject* parent = nullptr);
    ~Scene() override;

    Surface* baseSurface() const;
    void setBaseSurface(Surface* surface);

    SceneViewTilingScheme sceneViewTilingScheme() const;
    void setSceneViewTilingScheme(SceneViewTilingScheme sceneViewTilingScheme);

    static Scene* fromJson(const QString& json, QObject* parent = nullptr);
    QJsonObject unknownJson() const;
    QJsonObject unsupportedJson() const;

    /*!
       \internal
     */
    Scene(std::shared_ptr<QRTImpl::SceneImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::SceneImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(Scene)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_Scene_H
