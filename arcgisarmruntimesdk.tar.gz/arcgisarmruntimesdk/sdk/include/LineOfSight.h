// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LineOfSight.h

#ifndef QRT_LineOfSight_H
#define QRT_LineOfSight_H

// C++ API headers
#include "Analysis.h"

// Qt headers
#include <QColor>

namespace QRTImpl { class LineOfSightImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class LineOfSight : public Analysis
  {
    Q_OBJECT

  public:
    ~LineOfSight() override;

    LineOfSightTargetVisibility targetVisibility() const;

    static float lineWidth();
    static void setLineWidth(float lineWidth);

    static QColor visibleColor();
    static void setVisibleColor(const QColor& visibleColor);

    static QColor obstructedColor();
    static void setObstructedColor(const QColor& obstructedColor);

    /*! \internal */
    LineOfSight(std::shared_ptr<QRTImpl::LineOfSightImpl> impl, QObject* parent);

  signals:
    void targetVisibilityChanged(Esri::ArcGISRuntime::LineOfSightTargetVisibility targetVisibility);

  private:
    Q_DISABLE_COPY(LineOfSight)
    LineOfSight() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LineOfSight_H
