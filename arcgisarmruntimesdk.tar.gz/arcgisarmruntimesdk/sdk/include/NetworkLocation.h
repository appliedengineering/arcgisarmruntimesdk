// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file NetworkLocation.h

#ifndef QRT_NetworkLocation_H
#define QRT_NetworkLocation_H

// C++ API headers
#include "SourceObjectPosition.h"

// STL headers
#include <memory>

namespace QRTImpl { class NetworkLocationImpl; }

namespace Esri {
namespace ArcGISRuntime {

class NetworkLocation
{
public:
  NetworkLocation();
  NetworkLocation(const NetworkLocation& other);
  NetworkLocation(NetworkLocation&& other) noexcept;
  ~NetworkLocation();

  NetworkLocation& operator=(const NetworkLocation& other);
  NetworkLocation& operator=(NetworkLocation&& other) noexcept;

  bool isEmpty() const;

  bool isOnRightSideOfSource() const;
  void setOnRightSideOfSource(bool onRightSideOfSource);

  QString sourceName() const;
  void setSourceName(const QString& sourceName);

  SourceObjectPosition sourceObjectPosition() const;
  void setSourceObjectPosition(const SourceObjectPosition& sourceObjectPosition);

  /*!
     \internal
   */
  explicit NetworkLocation(const std::shared_ptr<QRTImpl::NetworkLocationImpl>& impl);
  std::shared_ptr<QRTImpl::NetworkLocationImpl> getImpl() const;

private:
  std::shared_ptr<QRTImpl::NetworkLocationImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_NetworkLocation_H
