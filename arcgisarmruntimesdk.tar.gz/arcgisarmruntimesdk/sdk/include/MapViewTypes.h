// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file MapViewTypes.h

#ifndef QRT_MapViewTypes_H
#define QRT_MapViewTypes_H

// Qt headers
#include <QFlags>

namespace Esri {
namespace ArcGISRuntime {

  enum class AnimationCurve
  {
    Linear = 0,
    EaseInQuad = 1,
    EaseOutQuad = 2,
    EaseInOutQuad = 3,
    EaseInCubic = 4,
    EaseOutCubic = 5,
    EaseInOutCubic = 6,
    EaseInQuart = 7,
    EaseOutQuart = 8,
    EaseInOutQuart = 9,
    EaseInQuint = 10,
    EaseOutQuint = 11,
    EaseInOutQuint = 12,
    EaseInSine = 13,
    EaseOutSine = 14,
    EaseInOutSine = 15,
    EaseInExpo = 16,
    EaseOutExpo = 17,
    EaseInOutExpo = 18,
    EaseInCirc = 19,
    EaseOutCirc = 20,
    EaseInOutCirc = 21
  };

  enum class DrawStatus
  {
    InProgress = 0,
    Completed = 1
  };

  enum class GeoViewType
  {
    MapView = 0,
    SceneView = 1,
    Unknown = -1
  };

  enum class LayerViewStatus
  {
    Active = 1,
    NotVisible = 2,
    OutOfScale = 4,
    Loading = 8,
    Error = 16,
    Warning = 32
  };

  Q_DECLARE_FLAGS(LayerViewStatusFlags, LayerViewStatus)

  enum class LocationDisplayAutoPanMode
  {
    Off = 0,
    Recenter = 1,
    Navigation = 2,
    CompassNavigation = 3
  };

  enum class WrapAroundMode
  {
    EnabledWhenSupported = 0,
    Disabled = 1
  };

  enum class GridLabelPosition
  {
    Geographic = 0,
    BottomLeft = 1,
    BottomRight = 2,
    TopLeft = 3,
    TopRight = 4,
    Center = 5,
    AllSides = 6
  };

  enum class GridType
  {
    Unknown = -1,
    LatitudeLongitudeGrid = 0,
    UTMGrid = 1,
    MGRSGrid = 2,
    USNGGrid = 3
  };

  enum class LatitudeLongitudeGridLabelFormat
  {
    DecimalDegrees = 0,
    DegreesMinutesSeconds = 1
  };

  enum class LocationType
  {
    Location = 0,
    NmeaLocation = 1,
    Unknown = -1
  };

  enum class MGRSGridLabelUnit
  {
    KilometersMeters = 0,
    Meters = 1
  };

  enum class NmeaAccuracyType
  {
    Gst = 0,
    Gsa = 1,
    Gga = 2
  };

  enum class NmeaFixType
  {
    Invalid = 0,
    Standard = 1,
    Dgps = 2,
    Pps = 3,
    Rtk = 4,
    Frtk = 5,
    Estimated = 6,
    Manual = 7,
    Simulation = 8
  };

  enum class NmeaGnssSystem
  {
    Unknown = 0,
    Gps = 1,
    Glonass = 2,
    Galileo = 3,
    Bds = 4,
    Qzss = 5,
    Navic = 6
  };

  enum class USNGGridLabelUnit
  {
    KilometersMeters = 0,
    Meters = 1
  };

  enum class SketchCreationMode
  {
    Unknown = -1,
    Point = 0,
    Polyline = 1,
    Polygon = 2,
    Multipoint = 10
  };

  enum class SketchResizeMode
  {
    None = 0,
    Stretch = 1,
    Uniform = 2
  };

  enum class SketchVertexEditMode
  {
    InteractionEdit = 0,
    SelectOnly = 1
  };

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_OPERATORS_FOR_FLAGS(Esri::ArcGISRuntime::LayerViewStatusFlags)

#endif // QRT_MapViewTypes_H
