// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LocalItem.h

#ifndef QRT_LocalItem_H
#define QRT_LocalItem_H

// C++ API headers
#include "Item.h"

namespace QRTImpl { class LocalItemImpl; }

namespace Esri {
namespace ArcGISRuntime {

  enum class LocalItemType;

  class LocalItem : public Item
  {
    Q_OBJECT

  public:
    ~LocalItem() override;

    LocalItemType localItemType() const;

    QString originalPortalItemId() const;

    QString path() const;

    QUrl portalUrl() const;

    /*! \internal */
    LocalItem(std::shared_ptr<QRTImpl::LocalItemImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::LocalItemImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(LocalItem)
    LocalItem() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LocalItem_H
