// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file CredentialCache.h

#ifndef QRT_CredentialCache_H
#define QRT_CredentialCache_H

// C++ API headers
#include "Credential.h"
#include "Object.h"

namespace QRTImpl { class CredentialCacheImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class CredentialCache : public Object
  {
    Q_OBJECT

  public:
    ~CredentialCache() override;

    void removeAllCredentials();

    bool setCredential(Credential* credential, const QUrl& url);

    Credential* credential(const QUrl& url) const;

    bool removeCredential(const QUrl& url);

    bool removeCredential(const Credential* credential);

    void removeAndRevokeAllCredentials();

    void removeAndRevokeCredential(Credential* credential);

    /*!
       \internal
     */
    CredentialCache(std::shared_ptr<QRTImpl::CredentialCacheImpl> impl, QObject* parent);

  signals:
    void removeAndRevokeAllCredentialsCompleted(const QMap<Esri::ArcGISRuntime::Credential*, Esri::ArcGISRuntime::Error>& errors);
    void removeAndRevokeCredentialCompleted(Esri::ArcGISRuntime::Error error);

  private:
    Q_DISABLE_COPY(CredentialCache)

    explicit CredentialCache(QObject* parent = nullptr);
    void connectSignals();

    std::shared_ptr<QRTImpl::CredentialCacheImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_CredentialCache_H
