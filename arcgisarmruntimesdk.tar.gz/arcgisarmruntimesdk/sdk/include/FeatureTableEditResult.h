// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file FeatureTableEditResult.h

#ifndef QRT_FeatureTableEditResult_H
#define QRT_FeatureTableEditResult_H

// C++ API headers
#include "Object.h"

namespace QRTImpl { class FeatureTableEditResultImpl; }

namespace Esri {
namespace ArcGISRuntime {

class FeatureEditResult;
class FeatureTable;

class FeatureTableEditResult : public Object
{
  Q_OBJECT
public:
  FeatureTableEditResult() = delete;
  FeatureTableEditResult(std::shared_ptr<QRTImpl::FeatureTableEditResultImpl> impl, QObject* parent);
  ~FeatureTableEditResult() override;

  QList<FeatureEditResult*> editResults() const;

  FeatureTable* featureTable() const;

  std::shared_ptr<QRTImpl::FeatureTableEditResultImpl> getImpl() const;

private:
  Q_DISABLE_COPY(FeatureTableEditResult)
  std::shared_ptr<QRTImpl::FeatureTableEditResultImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::FeatureTableEditResult*)

#endif // QRT_FeatureTableEditResult_H
