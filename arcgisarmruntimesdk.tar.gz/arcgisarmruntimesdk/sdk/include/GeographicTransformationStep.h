// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeographicTransformationStep.h

#ifndef QRT_GeographicTransformationStep_H
#define QRT_GeographicTransformationStep_H

// Qt headers
#include <QStringList>

// STL headers
#include <memory>

namespace QRTImpl { class GeographicTransformationStepImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class GeographicTransformationStep
  {
  public:
    GeographicTransformationStep();
    explicit GeographicTransformationStep(int wkid);
    explicit GeographicTransformationStep(const QString& wkText);
    GeographicTransformationStep(const GeographicTransformationStep& other);
    GeographicTransformationStep(GeographicTransformationStep&& other) noexcept;
    ~GeographicTransformationStep();

    GeographicTransformationStep& operator=(const GeographicTransformationStep& other);
    GeographicTransformationStep& operator=(GeographicTransformationStep&& other) noexcept;

    bool operator==(const GeographicTransformationStep& other) const;
    bool operator!=(const GeographicTransformationStep& other) const;

    bool isEmpty() const;

    int wkid() const;
    QString wkText() const;

    bool isInverse() const;
    GeographicTransformationStep inverseTransformation() const;

    QStringList projectionEngineFilenames() const;
    bool isMissingProjectionEngineFiles() const;

    /*! \internal */
    explicit GeographicTransformationStep(std::shared_ptr<QRTImpl::GeographicTransformationStepImpl> impl);
    std::shared_ptr<QRTImpl::GeographicTransformationStepImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::GeographicTransformationStepImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeographicTransformationStep_H
