// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityPropagatorListModel.h

#ifndef QRT_UtilityPropagatorsListModel_H
#define QRT_UtilityPropagatorsListModel_H

// C++ API headers
#include "Iterable.h"
#include "UtilityPropagator.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl {
  class UtilityPropagatorListImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class UtilityPropagatorListModel : public QAbstractListModel, public Iterable<UtilityPropagator*>
  {
    Q_OBJECT

  public:

    enum UtilityPropagatorRoles
    {
      UtilityPropagatorComparisonOperator = Qt::UserRole + 1,
      UtilityPropagatorNetworkAttribute = Qt::UserRole + 2,
      UtilityPropagatorPropagatorFunctionType = Qt::UserRole + 3,
      UtilityPropagatorSubstitutionNetworkAttribute = Qt::UserRole + 4,
      UtilityPropagatorValue = Qt::UserRole + 5
    };

    ~UtilityPropagatorListModel() override;

    bool isEmpty() const;

    void clear();

    int size() const override;

    void append(UtilityPropagator* UtilityPropagator);

    void insert(int index, UtilityPropagator* UtilityPropagator);

    void removeAt(int index);

    void removeOne(UtilityPropagator* UtilityPropagator);

    void move(int from, int to);

    UtilityPropagator* at(int index) const override;

    bool contains(UtilityPropagator* UtilityPropagator) const;

    int indexOf(UtilityPropagator* UtilityPropagator) const;

    UtilityPropagator* first() const;

    UtilityPropagator* last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*!
     \internal
     */
    UtilityPropagatorListModel(std::shared_ptr<QRTImpl::UtilityPropagatorListImpl> impl, QObject* parent);

  signals:
    void utilityPropagatorAdded(int index);
    void utilityPropagatorRemoved(int index);
    void errorOccurred(Esri::ArcGISRuntime::Error error);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(UtilityPropagatorListModel)

    UtilityPropagatorListModel() = delete;
    void setupRoles();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::UtilityPropagatorListImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityPropagatorsListModel_H
