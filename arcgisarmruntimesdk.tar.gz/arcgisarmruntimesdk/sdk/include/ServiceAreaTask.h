// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ServiceAreaTask.h

#ifndef QRT_ServiceAreaTask_H
#define QRT_ServiceAreaTask_H

// C++ API headers
#include "ApiKeyResource.h"
#include "Credential.h"
#include "Loadable.h"
#include "Object.h"
#include "RemoteResource.h"
#include "ServiceAreaParameters.h"
#include "ServiceAreaResult.h"
#include "ServiceAreaTaskInfo.h"
#include "TaskWatcher.h"
#include "TransportationNetworkDataset.h"

// Qt headers
#include <QUrl>
#include <QUuid>

namespace QRTImpl { class ServiceAreaTaskImpl; }

namespace Esri {
namespace ArcGISRuntime {

class ServiceAreaTask : public Object, public ApiKeyResource, public Loadable, public RemoteResource
{
  Q_OBJECT

public:
  ServiceAreaTask(const QString& databasePath, const QString& networkName, QObject* parent = nullptr);
  ServiceAreaTask(const QUrl& url, Credential* credential, QObject* parent = nullptr);
  explicit ServiceAreaTask(const QUrl& url, QObject* parent = nullptr);
  explicit ServiceAreaTask(TransportationNetworkDataset* transportationNetworkDataset, QObject* parent = nullptr);
  ~ServiceAreaTask() override;

  ServiceAreaTaskInfo serviceAreaTaskInfo() const;

  TransportationNetworkDataset* transportationNetworkDataset() const;

  TaskWatcher createDefaultParameters();

  TaskWatcher solveServiceArea(const ServiceAreaParameters& serviceAreaParameters);

  Error loadError() const override;
  LoadStatus loadStatus() const override;
  void cancelLoad() override;
  void load() override;
  void retryLoad() override;

  // RemoteResource interface methods
  QUrl url() const override;
  Credential* credential() const override;
  RequestConfiguration requestConfiguration() const override;
  void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

  // ApiKeyResource interface methods
  void setApiKey(const QString& apiKey) override;
  QString apiKey() const override;

  /*!
     \internal
   */
  ServiceAreaTask(std::shared_ptr<QRTImpl::ServiceAreaTaskImpl> impl, QObject* parent);

signals:
  void createDefaultParametersCompleted(QUuid taskId, Esri::ArcGISRuntime::ServiceAreaParameters defaultParameters);
  void solveServiceAreaCompleted(QUuid taskId, Esri::ArcGISRuntime::ServiceAreaResult serviceAreaResult);
  void doneLoading(Esri::ArcGISRuntime::Error loadError);
  void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

private:
  Q_DISABLE_COPY(ServiceAreaTask)

  void connectSignals();

  std::shared_ptr<QRTImpl::ServiceAreaTaskImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ServiceAreaTask_H
