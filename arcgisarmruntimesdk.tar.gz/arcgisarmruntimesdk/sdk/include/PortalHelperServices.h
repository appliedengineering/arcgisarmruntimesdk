// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PortalHelperServices.h

#ifndef QRT_PortalHelperServices_H
#define QRT_PortalHelperServices_H

// C++ API headers
#include "Deprecated.h"
#include "JsonSerializable.h"
#include "Object.h"

namespace QRTImpl { class PortalHelperServicesImpl; }

namespace Esri {
namespace ArcGISRuntime {
  class ElevationServiceInfo;

  class PortalHelperServices : public Object, public JsonSerializable
  {
    Q_OBJECT

  public:
    ~PortalHelperServices() override;

    QUrl analysisServiceUrl() const;
    QUrl asyncClosestFacilityServiceUrl() const;
    QUrl asyncLocationAllocationServiceUrl() const;
    QUrl asyncODCostMatrixServiceUrl() const;
    QUrl asyncServiceAreaServiceUrl() const;
    QUrl asyncVRPServiceUrl() const;
    QUrl closestFacilityServiceUrl() const;
    QList<ElevationServiceInfo> defaultElevationServices() const;
    QUrl elevationServiceUrl() const;
    QRT_DEPRECATED QUrl elevation3DServiceUrl() const;
    QUrl elevationSyncServiceUrl() const;
    QList<QUrl> geocodeServiceUrls() const;
    QUrl geoenrichmentServiceUrl() const;
    QUrl geometryServiceUrl() const;
    QUrl hydrologyServiceUrl() const;
    QUrl locationTrackingServiceUrl() const;
    QUrl printTaskUrl() const;
    QUrl routeServiceUrl() const;
    QUrl serviceAreaServiceUrl() const;
    QUrl syncVRPServiceUrl() const;
    QUrl trafficServiceUrl() const;

    // JsonSerializable Interface methods
    static PortalHelperServices* fromJson(const QString& json, QObject* parent = nullptr);
    QString toJson() const override;
    QJsonObject unknownJson() const override;
    QJsonObject unsupportedJson() const override;

  private:
    friend class PortalInfo;

    /*! \internal */
    PortalHelperServices(std::shared_ptr<QRTImpl::PortalHelperServicesImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::PortalHelperServicesImpl> m_rtPortalHelperServicesImpl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PortalHelperServices_H
