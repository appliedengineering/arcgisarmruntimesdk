// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PortalGroup.h

#ifndef QRT_PortalGroup_H
#define QRT_PortalGroup_H

// C++ API headers
#include "Deprecated.h"
#include "JsonSerializable.h"
#include "Loadable.h"
#include "Object.h"
#include "PortalTypes.h"

// Qt headers
#include <QDateTime>
#include <QString>
#include <QStringList>
#include <QUrl>

// STL headers
#include <memory>

namespace QRTImpl { class PortalGroupImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class Portal;

  class PortalGroup : public Object,
                      public Loadable,
                      public JsonSerializable
  {
    Q_OBJECT

  public:
    PortalGroup(Portal* portal, const QString& groupId, QObject* parent = nullptr);
    ~PortalGroup() override;

    PortalAccess access() const;
    QStringList admins() const;
    QDateTime created() const;
    QString groupDescription() const;
    QString groupId() const;
    bool isInvitationOnly() const;
    QDateTime modified() const;
    QString owner() const;
    QString phone() const;
    Portal* portal() const;
    QString snippet() const;
    PortalGroupSortField sortField() const;
    PortalQuerySortOrder sortOrder() const;
    QStringList tags() const;
    QUrl thumbnailUrl() const;
    QString title() const;
    QStringList users() const;
    bool isViewOnly() const;

    void fetchGroupUsers();

    // JsonSerializable Interface methods
    QRT_DEPRECATED static PortalGroup* fromJson(const QString& json, QObject* parent = nullptr); // obsolete
    static PortalGroup* fromJson(const QString& json, Portal* portal = nullptr, QObject* parent = nullptr);
    QString toJson() const override;
    QJsonObject unknownJson() const override;
    QJsonObject unsupportedJson() const override;

    // Loadable Interface methods
    void cancelLoad() override;
    void load() override;
    void retryLoad() override;
    Error loadError() const override;
    LoadStatus loadStatus() const override;

    PortalGroup(std::shared_ptr<QRTImpl::PortalGroupImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::PortalGroupImpl> getImpl() const;

  signals:
    void fetchGroupUsersCompleted(bool success);
    void doneLoading(Esri::ArcGISRuntime::Error loadError);
    void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

  private:
    Q_DISABLE_COPY(PortalGroup)
    void connectSignals_();

    std::shared_ptr<QRTImpl::PortalGroupImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PortalGroup_H
