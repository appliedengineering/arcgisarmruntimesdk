// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PortalQueryParameters.h

#ifndef QRT_PortalQueryParameters_H
#define QRT_PortalQueryParameters_H

// C++ API headers
#include "Envelope.h"
#include "PortalTypes.h"

namespace QRTImpl { class PortalQueryParametersImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class Envelope;

  class PortalQueryParameters
  {
  public:
    PortalQueryParameters();
    PortalQueryParameters(const PortalQueryParameters& other);
    PortalQueryParameters(PortalQueryParameters&& other) noexcept;

    PortalQueryParameters& operator=(const PortalQueryParameters& other);
    PortalQueryParameters& operator=(PortalQueryParameters&& other) noexcept;

    virtual ~PortalQueryParameters();

    bool isEmpty() const;

    Envelope boundingBox() const;
    void setBoundingBox(const Envelope& boundingBox);

    QStringList categories() const;
    void setCategories(const QStringList& categories);

    int limit() const;
    void setLimit(int limit);

    QString query() const;

    bool isSearchPublic() const;
    void setSearchPublic(bool searchPublic);

    QString sortField() const;
    void setSortField(const QString& sortField);

    PortalQuerySortOrder sortOrder() const;
    void setSortOrder(PortalQuerySortOrder sortOrder);

    int startIndex() const;
    void setStartIndex(int startIndex);

  protected:
    /*! \internal */
    explicit PortalQueryParameters(std::shared_ptr<QRTImpl::PortalQueryParametersImpl> impl);
    std::shared_ptr<QRTImpl::PortalQueryParametersImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PortalQueryParameters_H
