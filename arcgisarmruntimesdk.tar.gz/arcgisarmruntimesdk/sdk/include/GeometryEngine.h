// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeometryEngine.h

#ifndef QRT_GeometryEngine_H
#define QRT_GeometryEngine_H

// C++ API headers
#include "AngularUnit.h"
#include "AreaUnit.h"
#include "Envelope.h"
#include "GeodesicEllipseParameters.h"
#include "GeodesicSectorParameters.h"
#include "GeodeticDistanceResult.h"
#include "GeometryTypes.h"
#include "LinearUnit.h"
#include "Object.h"
#include "Point.h"
#include "Polygon.h"
#include "Polyline.h"
#include "ProximityResult.h"
#include "SpatialReference.h"

namespace QRTImpl {
  class GeometryEngineImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class DatumTransformation;

  class GeometryEngine : public Object
  {
    Q_OBJECT

  public:
    static GeometryEngine* instance();

    ~GeometryEngine() override;

    static bool equals(const Geometry& geometry1,
                       const Geometry& geometry2);

    static Geometry project(const Geometry& geometry,
                            const SpatialReference& spatialReference);

    static Geometry project(const Geometry& geometry,
                            const SpatialReference& spatialReference,
                            DatumTransformation* datumTransformation);

    static Geometry normalizeCentralMeridian(const Geometry& geometry);

    static double area(const Geometry& geometry);

    static Polygon buffer(const Geometry& geometry,
                          double distance);

    static QList<Polygon> buffer(const QList<Geometry>& geometries,
                                 const QList<double>& distances,
                                 bool unionResult);

    static bool contains(const Geometry& geometry1,
                         const Geometry& geometry2);

    static Geometry densify(const Geometry& geometry,
                            double maxSegmentLength);

    static Geometry difference(const Geometry& geometry1,
                               const Geometry& geometry2);

    static bool disjoint(const Geometry& geometry1,
                         const Geometry& geometry2);

    static double distance(const Geometry& geometry1,
                           const Geometry& geometry2);

    static double areaGeodetic(const Geometry& geometry,
                               const AreaUnit& unit,
                               GeodeticCurveType curveType);

    static Polygon bufferGeodetic(const Geometry& geometry,
                                  double distance,
                                  const LinearUnit& unit,
                                  double maxDeviation,
                                  GeodeticCurveType curveType);

    static QList<Polygon> bufferGeodetic(const QList<Geometry>& geometries,
                                         const QList<double>& distances,
                                         const LinearUnit& unit,
                                         double maxDeviation,
                                         GeodeticCurveType curveType,
                                         bool unionResult);

    static Geometry densifyGeodetic(const Geometry& geometry,
                                    double maxSegmentLength,
                                    const LinearUnit& lengthUnit,
                                    GeodeticCurveType curveType);

    static GeodeticDistanceResult distanceGeodetic(const Point& point1,
                                                   const Point& point2,
                                                   const LinearUnit& distanceUnit,
                                                   const AngularUnit& azimuthUnit,
                                                   GeodeticCurveType curveType);

    static Geometry ellipseGeodesic(const GeodesicEllipseParameters& parameters);

    static double lengthGeodetic(const Geometry& geometry,
                                 const LinearUnit& lengthUnit,
                                 GeodeticCurveType curveType);

    static QList<Point> moveGeodetic(const QList<Point>& pointCollection,
                                     double distance,
                                     const LinearUnit& distanceUnit,
                                     double azimuth,
                                     const AngularUnit& azimuthUnit,
                                     GeodeticCurveType curveType);

    static Geometry sectorGeodesic(const GeodesicSectorParameters& parameters);

    static Geometry intersection(const Geometry& geometry1,
                                 const Geometry& geometry2);

    static QList<Geometry> intersections(const Geometry& geometry1,
                                         const Geometry& geometry2);

    static bool intersects(const Geometry& geometry1,
                           const Geometry& geometry2);

    static double length(const Geometry& geometry);

    static Geometry simplify(const Geometry& geometry);

    static bool touches(const Geometry& geometry1,
                        const Geometry& geometry2);

    static Geometry unionOf(const Geometry& geometry1,
                            const Geometry& geometry2);

    static Geometry unionOf(const QList<Geometry>& geometries);

    static bool within(const Geometry& geometry1,
                       const Geometry& geometry2);

    static Geometry boundary(const Geometry& geometry);

    static Geometry clip(const Geometry& geometry,
                         const Envelope& envelope);

    static Geometry convexHull(const Geometry& geometry);

    static QList<Geometry> convexHull(const QList<Geometry>& geometries,
                                      bool unionResult);

    static Point createPointAlong(const Polyline& polyline, double distance);

    static bool crosses(const Geometry& geometry1,
                        const Geometry& geometry2);

    static Geometry generalize(const Geometry& geometry,
                               double maxDeviation,
                               bool removeDegenerateParts);

    static bool isSimple(const Geometry& geometry);

    static Point labelPoint(const Polygon& polygon);

    static ProximityResult nearestCoordinate(const Geometry& geometry,
                                             const Point& point);

    static ProximityResult nearestVertex(const Geometry& geometry,
                                         const Point& point);

    static Geometry offset(const Geometry& geometry,
                           double distance,
                           GeometryOffsetType offsetType,
                           double bevelRatio,
                           double flattenError);

    static bool overlaps(const Geometry& geometry1,
                         const Geometry& geometry2);

    static bool relate(const Geometry& geometry1,
                       const Geometry& geometry2,
                       const QString& relation);

    static Geometry symmetricDifference(const Geometry& geometry1,
                                        const Geometry& geometry2);

    static Envelope combineExtents(const Geometry& geometry1,
                                   const Geometry& geometry2);

    static Envelope combineExtents(const QList<Geometry>& geometries);

    static QList<Polygon> autoComplete(const QList<Geometry>& existingBoundaries,
                                       const QList<Geometry>& newBoundaries);

    static Polyline extend(const Polyline& polyline,
                           const Polyline& extender,
                           GeometryExtendOptions extendOptions);

    static Multipart reshape(const Multipart& geometry,
                             const Polyline& reshaper);

    static QList<Geometry> cut(const Geometry& geometry,
                               const Polyline& cutter);

    static Geometry setM(const Geometry& geometry, double m);
    static Geometry setZ(const Geometry& geometry, double z);
    static Geometry setZAndM(const Geometry& geometry, double z, double m);

    static Geometry removeM(const Geometry& geometry);
    static Geometry removeZ(const Geometry& geometry);
    static Geometry removeZAndM(const Geometry& geometry);

    static double fractionAlong(const Polyline& line,
                                const Point& point,
                                double tolerance);

  private:
    GeometryEngine();
    Q_DISABLE_COPY(GeometryEngine)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeometryEngine_H
