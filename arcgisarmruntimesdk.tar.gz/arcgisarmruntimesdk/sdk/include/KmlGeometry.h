// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlGeometry.h

#ifndef QRT_KmlGeometry_H
#define QRT_KmlGeometry_H

// C++ API headers
#include "Geometry.h"
#include "MapTypes.h"

// STL headers
#include <memory>

namespace QRTImpl { class KmlGeometryImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class KmlGeometry
  {
  public:
    KmlGeometry();

    KmlGeometry(const KmlGeometry& other);

    KmlGeometry(KmlGeometry&& other) noexcept;

    KmlGeometry(const Geometry& geometry, KmlAltitudeMode altitude);

    KmlGeometry(const Geometry& geometry, KmlAltitudeMode altitude,
                bool isExtruded);

    KmlGeometry(const Geometry& geometry, KmlAltitudeMode altitude,
                bool isExtruded, bool isTessellated);

    ~KmlGeometry();

    KmlGeometry& operator=(const KmlGeometry& other);
    KmlGeometry& operator=(KmlGeometry&& other) noexcept;

    bool isEmpty() const;

    KmlAltitudeMode altitudeMode() const;

    Geometry geometry() const;

    bool isExtruded() const;

    bool isTessellated() const;

    KmlGeometryType type() const;

    /*! \internal */
    explicit KmlGeometry(std::shared_ptr<QRTImpl::KmlGeometryImpl> impl);
    std::shared_ptr<QRTImpl::KmlGeometryImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::KmlGeometryImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlGeometry_H
