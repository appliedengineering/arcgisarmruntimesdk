// COPYRIGHT 2021 ESRI
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file FloorManager.h

#ifndef QRT_FloorManager_H
#define QRT_FloorManager_H

// C++ API headers
#include "Loadable.h"
#include "Object.h"

namespace QRTImpl { class FloorManagerImpl; }

namespace Esri {
namespace ArcGISRuntime {

class FloorFacility;
class FloorLevel;
class FloorSite;
class Layer;

class FloorManager : public Object, public Loadable
{
  Q_OBJECT
public:
  ~FloorManager() override;

  QList<FloorFacility*> facilities() const;

  Layer* facilityLayer() const;

  Layer* levelLayer() const;

  QList<FloorLevel*> levels() const;

  Layer* siteLayer() const;

  QList<FloorSite*> sites() const;

  // Loadable interface methods
  void cancelLoad() override;
  void load() override;
  void retryLoad() override;
  Error loadError() const override;
  LoadStatus loadStatus() const override;

  FloorManager(std::shared_ptr<QRTImpl::FloorManagerImpl> impl, QObject* parent);

  std::shared_ptr<QRTImpl::FloorManagerImpl> getImpl() const;

signals:
  void doneLoading(Esri::ArcGISRuntime::Error loadError);
  void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

private:
  Q_DISABLE_COPY(FloorManager)
  std::shared_ptr<QRTImpl::FloorManagerImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_FloorManager_H
