// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file MultipointBuilder.h

#ifndef QRT_MultipointBuilder_H
#define QRT_MultipointBuilder_H

// C++ API headers
#include "GeometryBuilder.h"
#include "Multipoint.h"
#include "PointCollection.h"
#include "SpatialReference.h"

// STL headers
#include <memory>

namespace QRTImpl { class MultipointBuilderImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class MultipointBuilder : public GeometryBuilder
  {
    Q_OBJECT

  public:
    explicit MultipointBuilder(const SpatialReference& spatialReference, QObject* parent = nullptr);

    explicit MultipointBuilder(const Multipoint& multipoint, QObject* parent = nullptr);

    ~MultipointBuilder() override;

    PointCollection* points() const;

    void setPoints(PointCollection* points);

    Geometry toGeometry() const override;

    Multipoint toMultipoint() const;

    GeometryBuilderType geometryBuilderType() const override;

    MultipointBuilder(std::shared_ptr<QRTImpl::MultipointBuilderImpl> impl, QObject* parent);

    std::shared_ptr<QRTImpl::GeometryBuilderImpl> getImpl() const override;

  private:
    Q_DISABLE_COPY(MultipointBuilder)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_MultipointBuilder_H
