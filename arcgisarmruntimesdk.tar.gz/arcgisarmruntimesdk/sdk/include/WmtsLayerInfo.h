// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file WmtsLayerInfo.h

#ifndef QRT_WmtsLayerInfo_H
#define QRT_WmtsLayerInfo_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "Envelope.h"
#include "ServiceTypes.h"
#include "WmtsTileMatrixSet.h"

// Qt headers
#include <QList>

// STL headers
#include <memory>

namespace QRTImpl {
  class WmtsLayerInfoImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class WmtsLayerInfo
  {
  public:
    WmtsLayerInfo();
    WmtsLayerInfo(const WmtsLayerInfo& other);
    WmtsLayerInfo(WmtsLayerInfo&& other) noexcept;
    ~WmtsLayerInfo();

    WmtsLayerInfo& operator=(const WmtsLayerInfo& other);
    WmtsLayerInfo& operator=(WmtsLayerInfo&& other) noexcept;

    bool isEmpty() const;

    QString description() const;

    QList<TileImageFormat> imageFormats() const;

    QString wmtsLayerId() const;

    QStringList keywords() const;

    QStringList styles() const;

    QList<WmtsTileMatrixSet> tileMatrixSets() const;

    QString title() const;

    /*! \internal */
    explicit WmtsLayerInfo(std::shared_ptr<QRTImpl::WmtsLayerInfoImpl> impl);
    std::shared_ptr<QRTImpl::WmtsLayerInfoImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::WmtsLayerInfoImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_WmtsLayerInfo_H
