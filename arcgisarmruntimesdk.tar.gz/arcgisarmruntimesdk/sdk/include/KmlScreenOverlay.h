// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlScreenOverlay.h

#ifndef QRT_KmlScreenOverlay_H
#define QRT_KmlScreenOverlay_H

// C++ API headers
#include "KmlNode.h"

namespace Esri {
namespace ArcGISRuntime {

class KmlIcon;
class KmlImageCoordinate;

  class KmlScreenOverlay : public KmlNode
  {
    Q_OBJECT

  public:
    explicit KmlScreenOverlay(KmlIcon* icon, QObject* parent = nullptr);
    ~KmlScreenOverlay() override;

    QColor color() const;
    void setColor(const QColor& color);

    int drawOrder() const;
    void setDrawOrder(int drawOrder);

    KmlIcon* icon() const;
    void setIcon(KmlIcon* icon);

    KmlImageCoordinate* overlayCoordinate() const;
    void setOverlayCoordinate(KmlImageCoordinate* overlayCoordinate);

    double rotation() const;
    void setRotation(double rotation);

    KmlImageCoordinate* rotationCoordinate() const;
    void setRotationCoordinate(KmlImageCoordinate* rotationCoordinate);

    KmlImageCoordinate* screenCoordinate() const;
    void setScreenCoordinate(KmlImageCoordinate* screenCoordinate);

    KmlImageCoordinate* size() const;
    void setSize(KmlImageCoordinate* size);

    /*! \internal */
    KmlScreenOverlay(std::shared_ptr<QRTImpl::KmlNodeImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(KmlScreenOverlay)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlScreenOverlay_H
