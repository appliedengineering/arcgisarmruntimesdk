// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ArcadeLabelExpression.h

#ifndef QRT_ArcadeLabelExpression_H
#define QRT_ArcadeLabelExpression_H

// C++ API headers
#include "LabelExpression.h"

namespace QRTImpl {
  class ArcadeLabelExpressionImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class ArcadeExpression;

  class ArcadeLabelExpression : public LabelExpression
  {
    Q_OBJECT
  public:
    explicit ArcadeLabelExpression(QObject* parent = nullptr);
    explicit ArcadeLabelExpression(ArcadeExpression* arcadeExpression, QObject* parent = nullptr);
    explicit ArcadeLabelExpression(const QString& arcadeString, QObject* parent = nullptr);
    ArcadeLabelExpression(std::shared_ptr<QRTImpl::LabelExpressionImpl> impl, QObject* parent);
    ~ArcadeLabelExpression() override;

    ArcadeExpression* arcadeExpression() const;
    void setArcadeExpression(ArcadeExpression* arcadeExpression);

    std::shared_ptr<QRTImpl::ArcadeLabelExpressionImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(ArcadeLabelExpression)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ArcadeLabelExpression_H
