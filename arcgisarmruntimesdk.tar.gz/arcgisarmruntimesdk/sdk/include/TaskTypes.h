// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file TaskTypes.h

#ifndef QRT_TaskTypes_H
#define QRT_TaskTypes_H

namespace Esri {
namespace ArcGISRuntime {

  enum class JobType
  {
    Unknown = -1,
    GenerateGeodatabaseJob = 0,
    SyncGeodatabaseJob = 1,
    ExportTileCacheJob = 2,
    EstimateTileCacheSizeJob = 3,
    GeoprocessingJob = 4,
    GenerateOfflineMapJob = 5,
    ExportVectorTilesJob = 6,
    OfflineMapSyncJob = 7,
    DownloadPreplannedOfflineMapJob = 8
  };

  enum class JobMessageSeverity
  {
    Info = 0,
    Warning = 1,
    Error = 2,
    Unknown = -1
  };

  enum class JobMessageSource
  {
    Client = 0,
    Service = 1
  };

  enum class JobStatus
  {
    NotStarted = 0,
    Started = 1,
    Paused = 2,
    Succeeded = 3,
    Failed = 4
  };

  enum class AttachmentSyncDirection
  {
    None = 0,
    Upload = 1,
    Bidirectional = 2
  };

  enum class SyncDirection
  {
    None = 0,
    Download = 1,
    Upload = 2,
    Bidirectional = 3
  };

  enum class SyncModel
  {
    None = 0,
    Geodatabase = 1,
    Layer = 2
  };

  enum class UtilityNetworkSyncMode
  {
    None = 0,
    SyncSystemTables = 1
  };

  enum class GenerateLayerQueryOption
  {
    Unknown = -1,
    All = 0,
    None = 1,
    UseFilter = 2
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_TaskTypes_H
