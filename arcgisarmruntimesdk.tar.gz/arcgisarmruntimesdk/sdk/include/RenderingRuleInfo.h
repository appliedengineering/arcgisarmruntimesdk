// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file RenderingRuleInfo.h

#ifndef QRT_RenderingRuleInfo_H
#define QRT_RenderingRuleInfo_H

// C++ API headers
#include "ArcGISQt_global.h"

// STL headers
#include <memory>

namespace QRTImpl {
  class RenderingRuleInfoImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class RenderingRuleInfo
  {
  public:
    RenderingRuleInfo();
    explicit RenderingRuleInfo(const QString& name);
    RenderingRuleInfo(const RenderingRuleInfo& other);
    RenderingRuleInfo(RenderingRuleInfo&& other) noexcept;
    ~RenderingRuleInfo();

    RenderingRuleInfo& operator=(const RenderingRuleInfo& other);
    RenderingRuleInfo& operator=(RenderingRuleInfo&& other) noexcept;

    bool isEmpty() const;

    QString description() const;

    QString help() const;

    QString name() const;

    explicit RenderingRuleInfo(std::shared_ptr<QRTImpl::RenderingRuleInfoImpl> impl);
    std::shared_ptr<QRTImpl::RenderingRuleInfoImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::RenderingRuleInfoImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_RenderingRuleInfo_H
