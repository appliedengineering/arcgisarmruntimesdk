// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeoprocessingParameterInfo.h

#ifndef QRT_GeoprocessingParameterInfo_H
#define QRT_GeoprocessingParameterInfo_H

// C++ API headers
#include "GeoprocessingParameter.h"
#include "GeoprocessingTypes.h"

// Qt headers
#include <QString>

// STL headers
#include <memory>

namespace QRTImpl { class GeoprocessingParameterInfoImpl; }

namespace Esri {
namespace ArcGISRuntime {

class GeoprocessingParameterInfo
{
public:
  GeoprocessingParameterInfo();
  GeoprocessingParameterInfo(const GeoprocessingParameterInfo& other);
  GeoprocessingParameterInfo(GeoprocessingParameterInfo&& other) noexcept;
  ~GeoprocessingParameterInfo();

  GeoprocessingParameterInfo& operator=(const GeoprocessingParameterInfo& other);
  GeoprocessingParameterInfo& operator=(GeoprocessingParameterInfo&& other) noexcept;

  bool isEmpty() const;

  QString category() const;

  QString description() const;

  QStringList choiceList() const;

  GeoprocessingParameterType dataType() const;

  GeoprocessingParameterDirection direction() const;

  QString displayName() const;

  bool isRequired() const;

  QString name() const;

  bool isFeaturesRequireGeometry() const;

  GeoprocessingParameterType multiValueDataType() const;

  GeoprocessingParameter* defaultParameter(QObject* parent = nullptr) const;

  /*!
     \internal
   */
  explicit GeoprocessingParameterInfo(std::shared_ptr<QRTImpl::GeoprocessingParameterInfoImpl> impl);

private:
  std::shared_ptr<QRTImpl::GeoprocessingParameterInfoImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeoprocessingParameterInfo_H
