// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file MosaicRule.h

#ifndef QRT_MosaicRule_H
#define QRT_MosaicRule_H

// C++ API headers
#include "Object.h"
#include "RasterTypes.h"

namespace QRTImpl { class MosaicRuleImpl; }

namespace Esri {
namespace ArcGISRuntime {

class RenderingRule;
class Viewpoint;

class MosaicRule : public Object
{
  Q_OBJECT
public:
  explicit MosaicRule(QObject* parent = nullptr);

  ~MosaicRule() override;

  bool isAscending() const;
  void setAscending(bool ascending);

  RenderingRule* itemRenderingRule() const;
  void setItemRenderingRule(RenderingRule* itemRenderingRule);

  QList<qint64> lockRasterIds() const;
  void setLockRasterIds(const QList<qint64>& lockRasterIds);

  MosaicMethod mosaicMethod() const;
  void setMosaicMethod(MosaicMethod mosaicMethod);

  MosaicOperation mosaicOperation() const;
  void setMosaicOperation(MosaicOperation mosaicOperation);

  QList<qint64> rasterIds() const;
  void setRasterIds(const QList<qint64>& rasterIds);

  QString sortField() const;
  void setSortField(const QString& sortField);

  QString sortValue() const;
  void setSortValue(const QString& sortValue);

  Viewpoint viewpoint() const;
  void setViewpoint(const Viewpoint& viewpoint);

  QString whereClause() const;
  void setWhereClause(const QString& whereClause);

  MosaicRule(std::shared_ptr<QRTImpl::MosaicRuleImpl> impl, QObject* parent);

  std::shared_ptr<QRTImpl::MosaicRuleImpl> getImpl() const;

private:
  Q_DISABLE_COPY(MosaicRule)
  std::shared_ptr<QRTImpl::MosaicRuleImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_MosaicRule_H
