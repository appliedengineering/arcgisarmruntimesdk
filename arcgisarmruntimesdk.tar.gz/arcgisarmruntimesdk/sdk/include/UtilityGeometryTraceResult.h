// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityGeometryTraceResult.h

#ifndef QRT_UtilityGeometryTraceResult_H
#define QRT_UtilityGeometryTraceResult_H

// C++ API headers
#include "Multipoint.h"
#include "Polygon.h"
#include "Polyline.h"
#include "UtilityTraceResult.h"

namespace QRTImpl { class UtilityGeometryTraceResultImpl; }

namespace Esri {
namespace ArcGISRuntime {

class Multipoint;
class Polygon;
class Polyline;

class UtilityGeometryTraceResult : public UtilityTraceResult
{
  Q_OBJECT
public:
~UtilityGeometryTraceResult() override;

Multipoint multipoint() const;

Polygon polygon() const;

Polyline polyline() const;

UtilityGeometryTraceResult(std::shared_ptr<QRTImpl::UtilityTraceResultImpl> impl, QObject* parent);

std::shared_ptr<QRTImpl::UtilityGeometryTraceResultImpl> getImpl() const;

private:
Q_DISABLE_COPY(UtilityGeometryTraceResult)
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityGeometryTraceResult_H
