// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ExportTileCacheTask.h

#ifndef QRT_ExportTileCacheTask_H
#define QRT_ExportTileCacheTask_H

// C++ API headers
#include "ApiKeyResource.h"
#include "ArcGISMapServiceInfo.h"
#include "Credential.h"
#include "EstimateTileCacheSizeJob.h"
#include "ExportTileCacheJob.h"
#include "ExportTileCacheParameters.h"
#include "Geometry.h"
#include "Loadable.h"
#include "Object.h"
#include "RemoteResource.h"
#include "TaskWatcher.h"

namespace QRTImpl
{
  class ExportTileCacheTaskImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class ExportTileCacheTask : public Object,
                              public ApiKeyResource,
                              public Loadable,
                              public RemoteResource
  {
    Q_OBJECT

  public:
    explicit ExportTileCacheTask(const QUrl& url, QObject* parent = nullptr);
    ExportTileCacheTask(const QUrl& url, Credential* credential, QObject* parent = nullptr);
    ~ExportTileCacheTask() override;

    ArcGISMapServiceInfo mapServiceInfo() const;

    TaskWatcher createDefaultExportTileCacheParameters(const Geometry& areaOfInterest, double minScale, double maxScale);
    EstimateTileCacheSizeJob* estimateTileCacheSize(const ExportTileCacheParameters& parameters);
    ExportTileCacheJob* exportTileCache(const ExportTileCacheParameters& parameters, const QString& downloadFilePath);

    // Loadable Interface methods
    Error loadError() const override;
    LoadStatus loadStatus() const override;
    void cancelLoad() override;
    void load() override;
    void retryLoad() override;

    // RemoteResource interface methods
    QUrl url() const override;
    Credential* credential() const override;
    RequestConfiguration requestConfiguration() const override;
    void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

    // ApiKeyResource interface methods
    void setApiKey(const QString& apiKey) override;
    QString apiKey() const override;

  signals:
    void doneLoading(Esri::ArcGISRuntime::Error loadError);
    void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);
    void defaultExportTileCacheParametersCompleted(QUuid taskId, Esri::ArcGISRuntime::ExportTileCacheParameters defaultExportTileCacheParameters);

  private:
    ExportTileCacheTask() = delete;
    Q_DISABLE_COPY(ExportTileCacheTask)
    std::shared_ptr<QRTImpl::ExportTileCacheTaskImpl> m_impl;

    void connectSignals();
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ExportTileCacheTask_H
