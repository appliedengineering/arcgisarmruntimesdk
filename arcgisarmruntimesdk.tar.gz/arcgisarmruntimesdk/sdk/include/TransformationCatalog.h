// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file TransformationCatalog.h

#ifndef QRT_TransformationCatalog_H
#define QRT_TransformationCatalog_H

// C++ API headers
#include "Object.h"

namespace QRTImpl { class TransformationCatalogImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class DatumTransformation;
  class SpatialReference;
  class Envelope;

  class TransformationCatalog : public Object
  {
    Q_OBJECT

  public:
    ~TransformationCatalog() override;

    static TransformationCatalog* instance();

    static QString projectionEngineDirectory();

    static void setProjectionEngineDirectory(const QString& projectionEngineDirectory);

    static QList<DatumTransformation*> transformationsBySuitability(const SpatialReference& inputSpatialReference,
                                                                    const SpatialReference& outputSpatialReference);

    static QList<DatumTransformation*> transformationsBySuitability(const SpatialReference& inputSpatialReference,
                                                                    const SpatialReference& outputSpatialReference,
                                                                    const Envelope& areaOfInterest);

    static QList<DatumTransformation*> transformationsBySuitability(const SpatialReference& inputSpatialReference,
                                                                    const SpatialReference& outputSpatialReference,
                                                                    const Envelope& areaOfInterest,
                                                                    bool ignoreVertical);

    static DatumTransformation* transformation(const SpatialReference& inputSpatialReference,
                                               const SpatialReference& outputSpatialReference);

    static DatumTransformation* transformation(const SpatialReference& inputSpatialReference,
                                               const SpatialReference& outputSpatialReference,
                                               const Envelope& areaOfInterest);

    static DatumTransformation* transformation(const SpatialReference& inputSpatialReference,
                                               const SpatialReference& outputSpatialReference,
                                               const Envelope& areaOfInterest,
                                               bool ignoreVertical);

  private:
    Q_DISABLE_COPY(TransformationCatalog)

    explicit TransformationCatalog(QObject* parent = nullptr);
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_TransformationCatalog_H
