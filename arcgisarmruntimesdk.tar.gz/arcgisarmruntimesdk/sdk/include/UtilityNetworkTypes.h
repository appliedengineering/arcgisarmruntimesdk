// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityNetworkTypes.h

#ifndef QRT_UtilityNetworkTypes_H
#define QRT_UtilityNetworkTypes_H

// Qt headers
#include <QMetaType>

namespace Esri {
namespace ArcGISRuntime {

  enum class UtilityAssociationDeletionSemantics
  {
    None = 0,
    Cascade = 1,
    Restricted = 2
  };

  enum class UtilityAssociationRole
  {
    None = 0,
    Container = 1,
    Structure = 2
  };

  enum class UtilityAssociationType
  {
    Connectivity = 1,
    Containment = 2,
    Attachment = 3,
    JunctionEdgeObjectConnectivityFromSide = 4,
    JunctionEdgeObjectConnectivityMidspan = 5,
    JunctionEdgeObjectConnectivityToSide = 6
  };

  enum class UtilityAttributeComparisonOperator
  {
    Equal = 0,
    NotEqual = 1,
    GreaterThan = 2,
    GreaterThanEqual = 3,
    LessThan = 4,
    LessThanEqual = 5,
    IncludesTheValues = 6,
    DoesNotIncludeTheValues = 7,
    IncludesAny = 8,
    DoesNotIncludeAny = 9
  };

  enum class UtilityCategoryComparisonOperator
  {
    Exists = 0,
    DoesNotExist = 1
  };

  enum class UtilityMinimumStartingLocations
  {
    One = 1,
    Many = 2
  };

  enum class UtilityNetworkAttributeDataType
  {
    Integer = 0,
    Float = 1,
    Double = 2,
    Boolean = 3
  };

  enum class UtilityNetworkSourceType
  {
    Junction = 0,
    Edge = 1
  };

  enum class UtilityNetworkSourceUsageType
  {
    Device = 0,
    Junction = 1,
    Line = 2,
    Assembly = 3,
    SubnetLine = 4,
    StructureJunction = 5,
    StructureLine = 6,
    StructureBoundary = 7,
    JunctionObject = 8,
    EdgeObject = 9,
    StructureJunctionObject = 10,
    StructureEdgeObject = 11
  };

  enum class UtilityPropagatorFunctionType
  {
    BitwiseAnd = 1,
    Max = 2,
    Min = 3
  };

  enum class UtilitySubnetworkControllerType
  {
    None = 0,
    Source = 1,
    Sink = 2
  };

  enum class UtilityTierTopologyType
  {
    Radial = 1,
    Mesh = 2
  };

  enum class UtilityTierType
  {
    Hierarchical = 1,
    Partitioned = 2
  };

  enum class UtilityTraceConditionType
  {
    UtilityNetworkAttributeComparison = 0,
    UtilityCategoryComparison = 1,
    UtilityTraceAndCondition = 2,
    UtilityTraceOrCondition = 3
  };

  enum class UtilityTraceFunctionType
  {
    Add = 1,
    Average = 2,
    Count = 3,
    Max = 4,
    Min = 5,
    Subtract = 6
  };

  enum class UtilityTraceResultObjectType
  {
    UtilityElementTraceResult = 0,
    UtilityFunctionTraceResult = 1,
    UtilityGeometryTraceResult = 2
  };

  enum class UtilityTraceResultType
  {
    Elements = 0,
    FunctionOutputs = 1,
    Geometry = 2
  };

  enum class UtilityTraceType
  {
    Connected = 0,
    Subnetwork = 1,
    Upstream = 2,
    Downstream = 3,
    Isolation = 4,
    Loops = 5,
    ShortestPath = 6
  };

  enum class UtilityTraversabilityScope
  {
    JunctionsAndEdges = 0,
    Junctions = 1,
    Edges = 2
  };

  enum class UtilityTerminalDirectionality
  {
    Unidirectional = 1,
    Bidirectional = 2
  };

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::UtilityAttributeComparisonOperator)
Q_DECLARE_METATYPE(Esri::ArcGISRuntime::UtilityPropagatorFunctionType)
Q_DECLARE_METATYPE(Esri::ArcGISRuntime::UtilityAssociationRole)
Q_DECLARE_METATYPE(Esri::ArcGISRuntime::UtilityTraceFunctionType)

#endif // QRT_UtilityNetworkTypes_H
