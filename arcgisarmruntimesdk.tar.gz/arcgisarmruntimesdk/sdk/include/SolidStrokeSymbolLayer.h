// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file SolidStrokeSymbolLayer.h

#ifndef QRT_SolidStrokeSymbolLayer_H
#define QRT_SolidStrokeSymbolLayer_H

// C++ API headers
#include "GeometricEffectListModel.h"
#include "StrokeSymbolLayer.h"

// Qt headers
#include <QColor>

namespace Esri {
namespace ArcGISRuntime {

  class SolidStrokeSymbolLayer : public StrokeSymbolLayer
  {
    Q_OBJECT

  public:
    explicit SolidStrokeSymbolLayer(QObject* parent = nullptr);

    SolidStrokeSymbolLayer(double width, const QColor& color,
                           QObject* parent = nullptr);

    SolidStrokeSymbolLayer(double width, const QColor& color,
                           const QList<GeometricEffect*>& geometricEffects,
                           QObject* parent = nullptr);

    SolidStrokeSymbolLayer(double width, const QColor& color,
                           const QList<GeometricEffect*>& geometricEffects,
                           StrokeSymbolLayerLineStyle3D lineStyle3D,
                           QObject* parent = nullptr);

    ~SolidStrokeSymbolLayer() override;

    QColor color() const;
    void setColor(const QColor& color);

    GeometricEffectListModel* geometricEffects() const;

    /*! \internal */
    SolidStrokeSymbolLayer(std::shared_ptr<QRTImpl::SymbolLayerImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(SolidStrokeSymbolLayer)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_SolidStrokeSymbolLayer_H
