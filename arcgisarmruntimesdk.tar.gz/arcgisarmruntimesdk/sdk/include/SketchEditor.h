// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file SketchEditor.h

#ifndef QRT_SketchEditor_H
#define QRT_SketchEditor_H

// C++ API headers
#include "Geometry.h"
#include "MapViewTypes.h"
#include "Object.h"

namespace QRTImpl {
  class SketchEditorImpl;
}

namespace Esri {
namespace ArcGISRuntime {

class Point;
class SketchEditConfiguration;
class SketchStyle;
class SketchVertex;

class SketchEditor : public Object
{
  Q_OBJECT

public:
  SketchEditor(QObject* parent = nullptr);
  ~SketchEditor() override;

  SketchCreationMode creationMode() const;

  bool isStarted() const;

  Geometry geometry() const;

  bool isSketchValid() const;

  SketchVertex* selectedVertex() const;
  void setSelectedVertex(SketchVertex* selectedVertex);

  SketchStyle* style() const;
  void setStyle(SketchStyle* style);

  bool insertVertexAfterSelectedVertex(const Point& point);
  bool moveSelectedVertex(const Point& point);
  bool replaceGeometry(const Geometry& geometry);
  bool removeSelectedVertex();

  void setVisible(bool visible);
  bool isVisible() const;

  void setOpacity(float opacity);
  float opacity() const;

  /*! \internal */
  SketchEditor(std::shared_ptr<QRTImpl::SketchEditorImpl> impl, QObject* parent);
  std::shared_ptr<QRTImpl::SketchEditorImpl> getImpl() const;

signals:
  void creationModeChanged();
  void geometryChanged();
  void startedChanged();
  void selectedVertexChanged();
  void styleChanged();
  void visibleChanged();
  void opacityChanged();

public slots:
  bool start(const Esri::ArcGISRuntime::Geometry& geometry);
  bool start(const Esri::ArcGISRuntime::Geometry& geometry, Esri::ArcGISRuntime::SketchCreationMode creationMode);
  bool start(const Esri::ArcGISRuntime::Geometry& geometry, Esri::ArcGISRuntime::SketchCreationMode creationMode,
             Esri::ArcGISRuntime::SketchEditConfiguration* editConfiguration);
  bool start(Esri::ArcGISRuntime::SketchCreationMode creationMode);
  bool start(Esri::ArcGISRuntime::SketchCreationMode creationMode, Esri::ArcGISRuntime::SketchEditConfiguration* editConfiguration);
  void stop();

  bool undo();
  bool redo();

private:
  Q_DISABLE_COPY(SketchEditor)

  void connectSignals_();

  std::shared_ptr<QRTImpl::SketchEditorImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_SketchEditor_H
