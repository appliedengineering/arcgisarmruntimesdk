// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file TransformationMatrix.h

#ifndef QRT_TransformationMatrix_H
#define QRT_TransformationMatrix_H

// C++ API headers
#include "Object.h"

// Qt headers
#include <QList>

// STL headers
#include <memory>

namespace QRTImpl { class TransformationMatrixImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class TransformationMatrix : public Object
  {
    Q_OBJECT

  public:
    ~TransformationMatrix();

    double quaternionX() const;
    double quaternionY() const;
    double quaternionZ() const;
    double quaternionW() const;
    double translationX() const;
    double translationY() const;
    double translationZ() const;

    static TransformationMatrix* createIdentityMatrix(QObject* parent = nullptr);

    static TransformationMatrix* createWithQuaternionAndTranslation(
        double quaternionX, double quaternionY, double quaternionZ, double quaternionW,
        double translationX, double translationY, double translationZ, QObject* parent = nullptr);

    TransformationMatrix* addTransformation(TransformationMatrix* other, QObject* parent = nullptr) const;
    TransformationMatrix* subtractTransformation(TransformationMatrix* other, QObject* parent = nullptr) const;

    /*! \internal */
    TransformationMatrix(std::shared_ptr<QRTImpl::TransformationMatrixImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::TransformationMatrixImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(TransformationMatrix)
    TransformationMatrix() = delete;

    std::shared_ptr<QRTImpl::TransformationMatrixImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_TransformationMatrix_H
