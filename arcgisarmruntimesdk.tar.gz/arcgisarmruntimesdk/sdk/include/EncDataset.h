// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file EncDataset.h

#ifndef QRT_EncDataset_H
#define QRT_EncDataset_H

// C++ API headers
#include "Envelope.h"
#include "Object.h"

// STL headers
#include <memory>

namespace QRTImpl { class EncDatasetImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class EncDataset : public Object
  {
    Q_OBJECT

  public:
    ~EncDataset() override;

    bool isAuthorized() const;
    QString description() const;
    Envelope extent() const;
    QString name() const;
    QString volumeName() const;

    /*! \internal */
    EncDataset(std::shared_ptr<QRTImpl::EncDatasetImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::EncDatasetImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(EncDataset)

    std::shared_ptr<QRTImpl::EncDatasetImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_EncDataset_H
