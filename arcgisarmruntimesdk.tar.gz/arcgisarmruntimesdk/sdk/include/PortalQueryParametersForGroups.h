// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PortalQueryParametersForGroups.h

#ifndef QRT_PortalQueryParametersForGroups_H
#define QRT_PortalQueryParametersForGroups_H

// C++ API headers
#include "PortalQueryParameters.h"

namespace QRTImpl { class PortalQueryParametersForGroupsImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class PortalQueryParametersForGroups : public PortalQueryParameters
  {
  public:
    explicit PortalQueryParametersForGroups();

    explicit PortalQueryParametersForGroups(const QString& query);
    explicit PortalQueryParametersForGroups(const QString& query, int limit);
    explicit PortalQueryParametersForGroups(const Envelope& boundingBox);
    explicit PortalQueryParametersForGroups(const QString& query, const Envelope& boundingBox);
    explicit PortalQueryParametersForGroups(const QString& owner, const QString& title);

    PortalQueryParametersForGroups(const PortalQueryParametersForGroups& other);
    PortalQueryParametersForGroups(PortalQueryParametersForGroups&& other) noexcept;
    explicit PortalQueryParametersForGroups(const PortalQueryParameters& other);

    PortalQueryParametersForGroups& operator=(const PortalQueryParametersForGroups& other);
    PortalQueryParametersForGroups& operator=(PortalQueryParametersForGroups&& other) noexcept;
    PortalQueryParametersForGroups& operator=(const PortalQueryParameters& other);

    ~PortalQueryParametersForGroups() override;

    QString owner() const;
    void setOwner(const QString& owner);

    QString title() const;
    void setTitle(const QString& title);

    /*!
       \internal
     */
    explicit PortalQueryParametersForGroups(const std::shared_ptr<QRTImpl::PortalQueryParametersForGroupsImpl>& impl);
    std::shared_ptr<QRTImpl::PortalQueryParametersForGroupsImpl> getImpl() const;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PortalQueryParametersForGroups_H
