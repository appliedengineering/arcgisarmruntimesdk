// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PortalFolderListModel.h

#ifndef QRT_PortalFolderListModel_H
#define QRT_PortalFolderListModel_H

// C++ API headers
#include "Deprecated.h"
#include "Error.h"
#include "Iterable.h"
#include "PortalFolder.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl { class PortalFolderListImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class PortalFolderListModel : public QAbstractListModel, public Iterable<PortalFolder>
  {
    Q_OBJECT

  public:

    enum PortalFolderRoles
    {
      PortalFolderCreatedRole = Qt::UserRole + 1, // read-only
      PortalFolderFolderIdRole = Qt::UserRole + 2, // read-only
      PortalFolderTitleRole = Qt::UserRole + 3 // read-only
    };

    ~PortalFolderListModel() override;

    bool isEmpty() const;

    QRT_DEPRECATED void clear();

    int size() const override;

    QRT_DEPRECATED void append(const PortalFolder& portalFolder);

    QRT_DEPRECATED void insert(int index, const PortalFolder& portalFolder);

    QRT_DEPRECATED void removeAt(int index);

    QRT_DEPRECATED void removeOne(const PortalFolder& portalFolder);

    QRT_DEPRECATED void move(int from, int to);

    PortalFolder at(int index) const override;

    bool contains(const PortalFolder& portalFolder) const;

    int indexOf(const PortalFolder& portalFolder) const;

    PortalFolder first() const;

    PortalFolder last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*!
       \internal
     */
    PortalFolderListModel(std::shared_ptr<QRTImpl::PortalFolderListImpl> impl, QObject* parent);

  signals:
    void errorOccurred(Esri::ArcGISRuntime::Error error);
    void portalFolderAdded(int index);
    void portalFolderRemoved(int index);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(PortalFolderListModel)

    PortalFolderListModel() = delete;
    void setupRoles();
    void connectSignals();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::PortalFolderListImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PortalFolderListModel_H
