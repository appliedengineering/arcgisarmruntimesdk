// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file SymbolLayerListModel.h

#ifndef QRT_SymbolLayerListModel_H
#define QRT_SymbolLayerListModel_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "Iterable.h"
#include "SymbolLayer.h"
#include "SymbolTypes.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl { class SymbolLayerListImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class SymbolLayerListModel : public QAbstractListModel, public Iterable<SymbolLayer*>
  {
    Q_OBJECT

  public:

    enum SymbolLayerRoles
    {
      SymbolLayerTypeRole = Qt::UserRole + 1,
      ColorLockedRole = Qt::UserRole + 2,
      EnabledRole = Qt::UserRole + 3
    };

    ~SymbolLayerListModel() override;

    bool isEmpty() const;

    void clear();

    int size() const override;

    void append(SymbolLayer* symbolLayer);

    void append(const QList<SymbolLayer*>& symbolLayers);

    void insert(int index, SymbolLayer* symbolLayer);

    void removeAt(int index);

    void removeOne(SymbolLayer* symbolLayer);

    void move(int from, int to);

    SymbolLayer* at(int index) const override;

    bool contains(SymbolLayer* symbolLayer) const;

    int indexOf(SymbolLayer* symbolLayer) const;

    SymbolLayer* first() const;

    SymbolLayer* last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool setData(const QModelIndex& index, const QVariant& value, int role = Qt::EditRole) override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*! \internal */
    SymbolLayerListModel(std::shared_ptr<QRTImpl::SymbolLayerListImpl> impl, QObject* parent);

  signals:
    void symbolLayerAdded(int index);
    void symbolLayerRemoved(int index);
    void errorOccurred(Esri::ArcGISRuntime::Error error);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(SymbolLayerListModel)

    SymbolLayerListModel() = delete;
    void setupRoles();
    void connectSignals();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::SymbolLayerListImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_SymbolLayerListModel_H
