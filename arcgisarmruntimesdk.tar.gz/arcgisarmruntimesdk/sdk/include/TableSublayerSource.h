// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file TableSublayerSource.h

#ifndef QRT_TableSublayerSource_H
#define QRT_TableSublayerSource_H

// C++ API headers
#include "Field.h"
#include "SublayerSource.h"

namespace QRTImpl { class TableSublayerSourceImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class TableSublayerSource : public SublayerSource
  {
    Q_OBJECT

  public:
    TableSublayerSource(const QString& workspaceId, const QString& dataSourceName, QObject* parent = nullptr);
    ~TableSublayerSource() override;

    QString dataSourceName() const;

    QString geodatabaseVersion() const;
    void setGeodatabaseVersion(const QString& geodatabaseVersion);

    QString workspaceId() const;

    /*! \internal */
    TableSublayerSource(std::shared_ptr<QRTImpl::TableSublayerSourceImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(TableSublayerSource)
    TableSublayerSource() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_TableSublayerSource_H
