// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file RasterLayer.h

#ifndef QRT_RasterLayer_H
#define QRT_RasterLayer_H

// C++ API headers
#include "ImageAdjustmentLayer.h"
#include "PopupDefinition.h"
#include "PopupSource.h"
#include "Raster.h"
#include "RasterRenderer.h"
#include "TimeAware.h"

namespace QRTImpl { class RasterLayerImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class RasterLayer : public ImageAdjustmentLayer, public PopupSource, public TimeAware
  {
    Q_OBJECT

  public:
    explicit RasterLayer(Raster* raster, QObject* parent = nullptr);
    explicit RasterLayer(Item* item, QObject* parent = nullptr);
    ~RasterLayer() override;

    Raster* raster() const;

    RasterRenderer* renderer() const;
    void setRenderer(RasterRenderer* renderer);

    // PopupSource interface methods
    bool isPopupEnabled() const override;
    void setPopupEnabled(bool popupEnabled) override;
    PopupDefinition* popupDefinition() const override;
    void setPopupDefinition(PopupDefinition* popupDefinition) override;

    // TimeAware interface methods
    TimeExtent fullTimeExtent() const override;
    bool isTimeFilteringEnabled() const override;
    void setTimeFilteringEnabled(bool timeFilteringEnabled) override;
    bool isSupportsTimeFiltering() const override;
    TimeValue timeInterval() const override;
    TimeValue timeOffset() const override;
    void setTimeOffset(const TimeValue& timeOffset) override;

    /*! \internal */
    RasterLayer(std::shared_ptr<QRTImpl::RasterLayerImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::RasterLayerImpl> getImpl() const;

  signals:
    void fullTimeExtentChanged();

  private:
    Q_DISABLE_COPY(RasterLayer)

    RasterLayer() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_RasterLayer_H
