// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file MultipartBuilder.h

#ifndef QRT_MultipartBuilder_H
#define QRT_MultipartBuilder_H

// C++ API headers
#include "GeometryBuilder.h"
#include "Multipoint.h"
#include "PartCollection.h"
#include "SpatialReference.h"

// STL headers
#include <memory>

namespace QRTImpl { class MultipartBuilderImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class MultipartBuilder : public GeometryBuilder
  {
    Q_OBJECT

  public:
    ~MultipartBuilder() override;

    PartCollection* parts() const;

    void setParts(PartCollection* parts);

    int addPoint(const Point& point);

    int addPoint(double x, double y);

    int addPoint(double x, double y, double z);

    void addPoints(const QList<Point>& points);

    std::shared_ptr<QRTImpl::GeometryBuilderImpl> getImpl() const override;

  protected:
    MultipartBuilder(std::shared_ptr<QRTImpl::MultipartBuilderImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(MultipartBuilder)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_MultipartBuilder_H
