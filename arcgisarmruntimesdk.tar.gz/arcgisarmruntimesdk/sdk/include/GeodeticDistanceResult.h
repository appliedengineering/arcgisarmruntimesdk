// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeodeticDistanceResult.h


#ifndef QRT_GeodeticDistanceResult_H
#define QRT_GeodeticDistanceResult_H

// C++ API headers
#include "AngularUnit.h"
#include "LinearUnit.h"

namespace QRTImpl {
  class GeodeticDistanceResultImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class GeodeticDistanceResult
  {
  public:
    GeodeticDistanceResult();
    GeodeticDistanceResult(const GeodeticDistanceResult& other);
    GeodeticDistanceResult(GeodeticDistanceResult&& other) noexcept;
    GeodeticDistanceResult& operator=(const GeodeticDistanceResult& other);
    GeodeticDistanceResult& operator=(GeodeticDistanceResult&& other) noexcept;
    ~GeodeticDistanceResult();

    AngularUnit azimuthUnit() const;
    double azimuth1() const;
    double azimuth2() const;
    double distance() const;
    LinearUnit distanceUnit() const;

    bool isEmpty() const;

    /*!
       \internal
    */
    explicit GeodeticDistanceResult(std::shared_ptr<QRTImpl::GeodeticDistanceResultImpl> impl);

  private:
    std::shared_ptr<QRTImpl::GeodeticDistanceResultImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeodeticDistanceResult_H
