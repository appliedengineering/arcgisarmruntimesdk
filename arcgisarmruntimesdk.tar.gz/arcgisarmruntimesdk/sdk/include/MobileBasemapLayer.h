// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file MobileBasemapLayer.h

#ifndef QRT_MobileBasemapLayer_H
#define QRT_MobileBasemapLayer_H

// C++ API headers
#include "Layer.h"

namespace QRTImpl {
  class MobileBasemapLayerImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class MobileBasemapLayer: public Layer
  {
    Q_OBJECT

  public:
    ~MobileBasemapLayer() override;

    QString path() const;

    QList<qint64> subLayerIds() const;

    /*! \internal */
    MobileBasemapLayer(std::shared_ptr<QRTImpl::MobileBasemapLayerImpl> impl, QObject* parent);

  private:
    MobileBasemapLayer() = delete;

    Q_DISABLE_COPY(MobileBasemapLayer)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_MobileBasemapLayer_H
