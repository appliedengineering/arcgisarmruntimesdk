// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityElement.h

#ifndef QRT_UtilityElement_H
#define QRT_UtilityElement_H

// C++ API headers
#include "Object.h"

class QUuid;

namespace QRTImpl { class UtilityElementImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class UtilityAssetGroup;
  class UtilityAssetType;
  class UtilityNetworkSource;
  class UtilityTerminal;

  class UtilityElement : public Object
  {
    Q_OBJECT

  public:
    ~UtilityElement() override;

    UtilityAssetGroup* assetGroup() const;

    UtilityAssetType* assetType() const;

    double fractionAlongEdge() const;
    void setFractionAlongEdge(double fractionAlongEdge);

    QUuid globalId() const;

    UtilityNetworkSource* networkSource() const;

    qint64 objectId() const;

    bool isValid() const;

    UtilityTerminal* terminal() const;
    void setTerminal(UtilityTerminal* terminal);

    /*! \internal */
    UtilityElement(std::shared_ptr<QRTImpl::UtilityElementImpl> impl, QObject* parent);
    std::shared_ptr<QRTImpl::UtilityElementImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::UtilityElementImpl> m_impl;

    Q_DISABLE_COPY(UtilityElement)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityElement_H
