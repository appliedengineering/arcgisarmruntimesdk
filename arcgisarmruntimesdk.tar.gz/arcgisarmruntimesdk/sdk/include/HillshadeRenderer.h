// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file HillshadeRenderer.h

#ifndef QRT_HillshadeRenderer_H
#define QRT_HillshadeRenderer_H

// C++ API headers
#include "RasterRenderer.h"

namespace QRTImpl { class HillshadeRendererImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class HillshadeRenderer : public RasterRenderer
  {
    Q_OBJECT

  public:
    explicit HillshadeRenderer(QObject* parent = nullptr);
    HillshadeRenderer(double altitude, double azimuth, double zFactor, QObject* parent = nullptr);
    HillshadeRenderer(double altitude, double azimuth, double zFactor, SlopeType slopeType, double pixelSizeFactor, double pixelSizePower, int outputBitDepth, QObject* parent = nullptr);
    ~HillshadeRenderer() override;

    HillshadeRenderer(std::shared_ptr<QRTImpl::HillshadeRendererImpl> impl, QObject* parent);

    double altitude() const;
    double azimuth() const;
    int outputBitDepth() const;
    double pixelSizeFactor() const;
    double pixelSizePower() const;
    SlopeType slopeType() const;
    double zFactor() const;

  private:
    Q_DISABLE_COPY(HillshadeRenderer)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_HillshadeRenderer_H
