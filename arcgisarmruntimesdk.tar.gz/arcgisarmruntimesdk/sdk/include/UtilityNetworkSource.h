// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file UtilityNetworkSource.h

#ifndef QRT_UtilityNetworkSource_H
#define QRT_UtilityNetworkSource_H

// C++ API headers
#include "Object.h"

// Qt headers
#include <QList>
#include <QString>

namespace QRTImpl { class UtilityNetworkSourceImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class ArcGISFeatureTable;
  class UtilityAssetGroup;
  enum class UtilityNetworkSourceType;
  enum class UtilityNetworkSourceUsageType;

  class UtilityNetworkSource : public Object
  {
    Q_OBJECT

  public:
    ~UtilityNetworkSource() override;

    QList<UtilityAssetGroup*> assetGroups() const;
    UtilityAssetGroup* assetGroup(const QString& assetGroupName) const;

    ArcGISFeatureTable* featureTable() const;

    QString name() const;

    int sourceId() const;

    UtilityNetworkSourceType sourceType() const;

    UtilityNetworkSourceUsageType sourceUsageType() const;

    /*! \internal */
    UtilityNetworkSource(std::shared_ptr<QRTImpl::UtilityNetworkSourceImpl> impl, QObject* parent);

  private:
    std::shared_ptr<QRTImpl::UtilityNetworkSourceImpl> m_impl;

    Q_DISABLE_COPY(UtilityNetworkSource)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_UtilityNetworkSource_H
