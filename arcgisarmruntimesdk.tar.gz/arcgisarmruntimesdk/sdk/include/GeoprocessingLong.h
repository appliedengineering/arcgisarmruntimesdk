// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeoprocessingLong.h

#ifndef QRT_GeoprocessingLong_H
#define QRT_GeoprocessingLong_H

// C++ API headers
#include "GeoprocessingParameter.h"

namespace QRTImpl { class GeoprocessingLongImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class GeoprocessingLong : public GeoprocessingParameter
  {
    Q_OBJECT

  public:
    explicit GeoprocessingLong(QObject* parent = nullptr);
    explicit GeoprocessingLong(int value, QObject* parent = nullptr);
    ~GeoprocessingLong() override;

    int value() const;
    void setValue(int value);

    /*!
       \internal
     */
    GeoprocessingLong(std::shared_ptr<QRTImpl::GeoprocessingLongImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(GeoprocessingLong)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeoprocessingLong_H
