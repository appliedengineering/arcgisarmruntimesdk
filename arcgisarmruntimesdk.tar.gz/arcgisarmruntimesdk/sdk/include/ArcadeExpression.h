// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ArcadeExpression.h

#ifndef QRT_ArcadeExpression_H
#define QRT_ArcadeExpression_H

// C++ API headers
#include "ExpressionTypes.h"
#include "JsonSerializable.h"
#include "Object.h"

namespace QRTImpl {
  class ArcadeExpressionImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class ArcadeExpression : public Object, public JsonSerializable
  {
    Q_OBJECT
  public:
    explicit ArcadeExpression(const QString& expression, QObject* parent = nullptr);

    ArcadeExpression(const QString& expression, const QString& title, const QString& name, QObject* parent = nullptr);

    ArcadeExpression(const QString& expression, const QString& title, const QString& name,
                     ArcadeExpressionReturnType returnType, QObject* parent = nullptr);

    ~ArcadeExpression() override;

    QString expression() const;

    QString name() const;

    ArcadeExpressionReturnType returnType() const;

    QString title() const;

    bool equals(ArcadeExpression* other) const;

    // JSONSerializable interface methods
    static ArcadeExpression* fromJson(const QString& json, QObject* parent = nullptr);
    QString toJson() const override;
    QJsonObject unknownJson() const override;
    QJsonObject unsupportedJson() const override;

    ArcadeExpression(std::shared_ptr<QRTImpl::ArcadeExpressionImpl> impl, QObject* parent);

    std::shared_ptr<QRTImpl::ArcadeExpressionImpl> getImpl() const;

  private:
    Q_DISABLE_COPY(ArcadeExpression)
    std::shared_ptr<QRTImpl::ArcadeExpressionImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ArcadeExpression_H
