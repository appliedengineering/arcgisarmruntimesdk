// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file USNGGrid.h

#ifndef QRT_USNGGrid_H
#define QRT_USNGGrid_H

// C++ API headers
#include "Grid.h"

namespace QRTImpl {
  class USNGGridImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class USNGGrid : public Grid
  {
    Q_OBJECT

  public:
    explicit USNGGrid(QObject* parent = nullptr);
    ~USNGGrid() override;

    USNGGridLabelUnit labelUnit() const;
    void setLabelUnit(USNGGridLabelUnit labelUnit);

    /*! \internal */
    USNGGrid(std::shared_ptr<QRTImpl::USNGGridImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(USNGGrid)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_USNGGrid_H
