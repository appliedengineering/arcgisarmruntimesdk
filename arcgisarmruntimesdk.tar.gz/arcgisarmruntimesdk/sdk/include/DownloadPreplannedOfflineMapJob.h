// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file DownloadPreplannedOfflineMapJob.h

#ifndef QRT_DownloadPreplannedOfflineMapJob_H
#define QRT_DownloadPreplannedOfflineMapJob_H

// C++ API headers
#include "Deprecated.h"
#include "DownloadPreplannedOfflineMapParameters.h"
#include "DownloadPreplannedOfflineMapResult.h"
#include "Job.h"
#include "Map.h"
#include "PreplannedMapArea.h"

namespace QRTImpl {
  class DownloadPreplannedOfflineMapJobImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class DownloadPreplannedOfflineMapJob : public Job
  {
    Q_OBJECT

  public:
    ~DownloadPreplannedOfflineMapJob() override;

    DownloadPreplannedOfflineMapParameters parameters() const;

    DownloadPreplannedOfflineMapResult* result() const;

    QString downloadDirectoryPath() const;

    Map* onlineMap() const;

    QRT_DEPRECATED PreplannedMapArea* preplannedMapArea() const;

    QRT_DEPRECATED bool excludeBasemap() const;

    /*!
       \internal
     */
    DownloadPreplannedOfflineMapJob(std::shared_ptr<QRTImpl::DownloadPreplannedOfflineMapJobImpl> impl, QObject* parent);

  private:
    DownloadPreplannedOfflineMapJob() = delete;

    Q_DISABLE_COPY(DownloadPreplannedOfflineMapJob)
  };
}
}

#endif // QRT_DownloadPreplannedOfflineMapJob_H
