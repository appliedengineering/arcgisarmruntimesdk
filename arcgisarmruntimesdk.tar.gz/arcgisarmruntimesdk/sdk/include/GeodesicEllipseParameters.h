// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GeodesicEllipseParameters.h

#ifndef QRT_GeodesicEllipseParameters_H
#define QRT_GeodesicEllipseParameters_H

// C++ API headers
#include "AngularUnit.h"
#include "LinearUnit.h"
#include "Point.h"

namespace QRTImpl {
  class GeodesicEllipseParametersImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class GeodesicEllipseParameters
  {
  public:
    GeodesicEllipseParameters();
    GeodesicEllipseParameters(const Point& center, double semiAxis1Length, double semiAxis2Length);
    GeodesicEllipseParameters(double axisDirection,
                              const AngularUnit& angularUnit,
                              const Point& center,
                              const LinearUnit& linearUnit,
                              unsigned int maxPointCount,
                              double maxSegmentLength,
                              GeometryType geometryType,
                              double semiAxis1Length,
                              double semiAxis2Length);
    GeodesicEllipseParameters(const GeodesicEllipseParameters& other);
    GeodesicEllipseParameters(GeodesicEllipseParameters&& other) noexcept;
    GeodesicEllipseParameters& operator=(const GeodesicEllipseParameters& other);
    GeodesicEllipseParameters& operator=(GeodesicEllipseParameters&& other) noexcept;
    ~GeodesicEllipseParameters();

    AngularUnit angularUnit() const;
    void setAngularUnit(const AngularUnit& angularUnit);
    double axisDirection() const;
    void setAxisDirection(double direction);
    Point center() const;
    void setCenter(const Point& center);
    GeometryType geometryType() const;
    void setGeometryType(GeometryType type);
    LinearUnit linearUnit() const;
    void setLinearUnit(const LinearUnit& linearUnit);
    unsigned int maxPointCount() const;
    void setMaxPointCount(unsigned int count);
    double maxSegmentLength() const;
    void setMaxSegmentLength(double length);
    double semiAxis1Length() const;
    void setSemiAxis1Length(double length);
    double semiAxis2Length() const;
    void setSemiAxis2Length(double length);

    /*!
       \internal
    */
    explicit GeodesicEllipseParameters(const std::shared_ptr<QRTImpl::GeodesicEllipseParametersImpl>& impl);
    std::shared_ptr<QRTImpl::GeodesicEllipseParametersImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::GeodesicEllipseParametersImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_GeodesicEllipseParameters_H
