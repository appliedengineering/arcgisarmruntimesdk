// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file Error.h

#ifndef QRT_Error_H
#define QRT_Error_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "Deprecated.h"
#include "ErrorTypes.h"

// Qt headers
#include <QMetaType>

// STL headers
#include <memory>

namespace QRTImpl { class ErrorImpl; }

namespace Esri {
namespace ArcGISRuntime {

class Error
{
public:
  Error();
  Error(QString message, QString additionalMessage,
        ExtendedErrorType extendedErrorType = ExtendedErrorType::None);
  Error(const Error& other);
  Error(Error&& other) noexcept;

  ~Error();

  Error& operator=(const Error& other);
  Error& operator=(Error&& other) noexcept;

  QString additionalMessage() const;
  QRT_DEPRECATED int code() const;
  ErrorDomainType domain() const;
  QString message() const;
  ExtendedErrorType extendedErrorType() const;

  ErrorType errorType() const;

  bool isEmpty() const;

  /*! \internal */
  explicit Error(std::shared_ptr<QRTImpl::ErrorImpl> impl);

private:
  std::shared_ptr<QRTImpl::ErrorImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::Error);

#endif // QRT_Error_H
