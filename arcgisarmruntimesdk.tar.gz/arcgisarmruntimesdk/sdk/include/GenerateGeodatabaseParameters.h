// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file GenerateGeodatabaseParameters.h

#ifndef QRT_GenerateGeodatabaseParameters_H
#define QRT_GenerateGeodatabaseParameters_H

// C++ API headers
#include "GenerateLayerOption.h"
#include "Geometry.h"
#include "SpatialReference.h"
#include "TaskTypes.h"

namespace QRTImpl {
  class GenerateGeodatabaseParametersImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class GenerateGeodatabaseParameters
  {
  public:
    GenerateGeodatabaseParameters();
    GenerateGeodatabaseParameters(const GenerateGeodatabaseParameters& other);
    GenerateGeodatabaseParameters(GenerateGeodatabaseParameters&& other) noexcept;
    ~GenerateGeodatabaseParameters();

    GenerateGeodatabaseParameters& operator=(const GenerateGeodatabaseParameters& other);
    GenerateGeodatabaseParameters& operator=(GenerateGeodatabaseParameters&& other) noexcept;

    bool isEmpty() const;

    AttachmentSyncDirection attachmentSyncDirection() const;
    void setAttachmentSyncDirection(AttachmentSyncDirection attachmentSyncDirection);

    Geometry extent() const;
    void setExtent(const Geometry& extent);

    QList<GenerateLayerOption> layerOptions() const;
    void setLayerOptions(const QList<GenerateLayerOption>& generateLayerOptions);

    SpatialReference outSpatialReference() const;
    void setOutSpatialReference(const SpatialReference& outSpatialReference);

    bool isReturnAttachments() const;
    void setReturnAttachments(bool returnAttachments);

    bool isSyncContingentValues() const;
    void setSyncContingentValues(bool syncContingentValues);

    SyncModel syncModel() const;
    void setSyncModel(SyncModel syncModel);

    UtilityNetworkSyncMode utilityNetworkSyncMode() const;
    void setUtilityNetworkSyncMode(UtilityNetworkSyncMode utilityNetworkSyncMode);

    /*! \internal */
    std::shared_ptr<QRTImpl::GenerateGeodatabaseParametersImpl> getImpl() const;
    explicit GenerateGeodatabaseParameters(const std::shared_ptr<QRTImpl::GenerateGeodatabaseParametersImpl>& impl);

  private:
    std::shared_ptr<QRTImpl::GenerateGeodatabaseParametersImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

Q_DECLARE_METATYPE(Esri::ArcGISRuntime::GenerateGeodatabaseParameters)

#endif // QRT_GenerateGeodatabaseParameters_H
