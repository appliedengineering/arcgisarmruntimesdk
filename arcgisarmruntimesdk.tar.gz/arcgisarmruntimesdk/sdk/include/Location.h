// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file Location.h

#ifndef QRT_Location_H
#define QRT_Location_H

// C++ API headers
#include "ArcGISQt_global.h"
#include "Point.h"

// Qt Header
#include <QDateTime>

namespace Esri {
  namespace ArcGISRuntime {
    enum class LocationType;
  }
}

namespace QRTImpl { class LocationImpl; }

namespace Esri {
namespace ArcGISRuntime {

class Location
{
public:
  Location(const QDateTime& timestamp,
           const Point& position,
           double horizontalAccuracy,
           double verticalAccuracy,
           double velocity,
           double course,
           bool lastKnown);

  Location(const Point& position,
           double horizontalAccuracy,
           double velocity,
           double course,
           bool lastKnown);

  Location();
  virtual ~Location();
  Location(const Location& other);
  Location(Location&& other) noexcept;
  Location& operator=(const Location& other);
  Location& operator=(Location&& other) noexcept;

  bool isEmpty() const;

  double course() const;

  double horizontalAccuracy() const;

  bool isLastKnown() const;

  Esri::ArcGISRuntime::LocationType locationType() const;

  Point position() const;

  double velocity() const;

  QDateTime timestamp() const;

  double verticalAccuracy() const;

  /*!
     \internal
   */
  explicit Location(std::shared_ptr<QRTImpl::LocationImpl> impl);
  std::shared_ptr<QRTImpl::LocationImpl> getImpl() const;

protected:
  std::shared_ptr<QRTImpl::LocationImpl> m_impl;
};

/*!
  \brief Type-safe cast helper for Location types.

  Casting a Location-derived class to the base Location type is always valid.

  However, casting from Location to a Location-derived class is valid only if \l Location::locationType
  is the same type as target type.

  \code
  connect(nmeaLocationDataSource, &NmeaLocationDataSource::locationChanged, this, [](const Location& location)
  {
    NmeaLocation nmeaLocation = location_cast<NmeaLocation>(location);
    QASSERT(!nmeaLocation.isEmpty()); // thus valid

    Location newLocation = location_cast<Location>(nmeaLocation);
    QASSERT(!newLocation.isEmpty()); // thus valid
  });

  connect(simulatedLocationDataSource, &SimulatedLocationDataSource::locationChanged, this, [](const Location& location)
  {
    Location newLocation = location_cast<Location>(location);
    NmeaLocation nmeaLocation = location_cast<NmeaLocation>(location);

    QASSERT(nmeaLocation.isEmpty()); // thus invalid
    QASSERT(!newLocation.isEmpty()); // thus valid
  });
  \endcode

  \since Esri::ArcGISRuntime 100.10
*/
template<typename T>
T location_cast(const Location&)
{
  return T();
}

template<>
inline Location location_cast<Location>(const Location& location)
{
  return location;
}

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_Location_H
