// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ClosestFacilityTask.h

#ifndef QRT_ClosestFacilityTask_H
#define QRT_ClosestFacilityTask_H

// C++ API headers
#include "ApiKeyResource.h"
#include "ClosestFacilityParameters.h"
#include "ClosestFacilityResult.h"
#include "ClosestFacilityTaskInfo.h"
#include "Credential.h"
#include "Loadable.h"
#include "Object.h"
#include "RemoteResource.h"
#include "TaskWatcher.h"
#include "TransportationNetworkDataset.h"

// Qt headers
#include <QUrl>
#include <QUuid>

namespace QRTImpl { class ClosestFacilityTaskImpl; }

namespace Esri {
namespace ArcGISRuntime {

class ClosestFacilityTask : public Object, public ApiKeyResource, public Loadable, public RemoteResource
{
  Q_OBJECT

public:
  ClosestFacilityTask(const QString& databasePath, const QString& networkName, QObject* parent = nullptr);
  ClosestFacilityTask(const QUrl& url, Credential* credential, QObject* parent = nullptr);
  explicit ClosestFacilityTask(const QUrl& url, QObject* parent = nullptr);
  explicit ClosestFacilityTask(TransportationNetworkDataset* transportationNetworkDataset, QObject* parent = nullptr);
  ~ClosestFacilityTask() override;

  ClosestFacilityTaskInfo closestFacilityTaskInfo() const;

  TransportationNetworkDataset* transportationNetworkDataset() const;

  TaskWatcher createDefaultParameters();

  TaskWatcher solveClosestFacility(const ClosestFacilityParameters& closestFacilityParameters);

  Error loadError() const override;
  LoadStatus loadStatus() const override;
  void cancelLoad() override;
  void load() override;
  void retryLoad() override;

  // RemoteResource interface methods
  QUrl url() const override;
  Credential* credential() const override;
  RequestConfiguration requestConfiguration() const override;
  void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

  // ApiKeyResource interface methods
  void setApiKey(const QString& apiKey) override;
  QString apiKey() const override;

  /*!
     \internal
   */
  ClosestFacilityTask(std::shared_ptr<QRTImpl::ClosestFacilityTaskImpl> impl, QObject* parent);

signals:
  void createDefaultParametersCompleted(QUuid taskId, Esri::ArcGISRuntime::ClosestFacilityParameters defaultParameters);
  void solveClosestFacilityCompleted(QUuid taskId, Esri::ArcGISRuntime::ClosestFacilityResult closestFacilityResult);
  void doneLoading(Esri::ArcGISRuntime::Error loadError);
  void loadStatusChanged(Esri::ArcGISRuntime::LoadStatus loadStatus);

private:
  Q_DISABLE_COPY(ClosestFacilityTask)

  void connectSignals();

  std::shared_ptr<QRTImpl::ClosestFacilityTaskImpl> m_impl;
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ClosestFacilityTask_H
