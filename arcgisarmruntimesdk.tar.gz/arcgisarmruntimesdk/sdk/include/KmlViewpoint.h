// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file KmlViewpoint.h

#ifndef QRT_KmlViewpoint_H
#define QRT_KmlViewpoint_H

// C++ API headers
#include "MapTypes.h"
#include "Point.h"

namespace QRTImpl { class KmlViewpointImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class Viewpoint;

  class KmlViewpoint
  {
  public:
    KmlViewpoint();
    KmlViewpoint(const KmlViewpoint& other);
    KmlViewpoint(KmlViewpoint&& other) noexcept;
    ~KmlViewpoint();

    KmlViewpoint& operator=(const KmlViewpoint& other);
    KmlViewpoint& operator=(KmlViewpoint&& other) noexcept;

    bool isEmpty() const;

    KmlAltitudeMode altitudeMode() const;
    double heading() const;
    Point location() const;
    double pitch() const;
    double range() const;
    double roll() const;
    KmlViewpointType type() const;

    static KmlViewpoint createCameraViewpoint(const Point& cameraLocation, double heading, double pitch, double roll, KmlAltitudeMode altitudeMode);

    static KmlViewpoint createLookAtViewpoint(const Point& lookAtLocation, double heading, double pitch, double range, KmlAltitudeMode altitudeMode);

    static KmlViewpoint createWithViewpoint(const Viewpoint& viewpoint);

    /*! \internal */
    explicit KmlViewpoint(std::shared_ptr<QRTImpl::KmlViewpointImpl> impl);
    std::shared_ptr<QRTImpl::KmlViewpointImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::KmlViewpointImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_KmlViewpoint_H
