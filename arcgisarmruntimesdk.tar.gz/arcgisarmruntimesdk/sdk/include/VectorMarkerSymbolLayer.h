// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file VectorMarkerSymbolLayer.h

#ifndef QRT_VectorMarkerSymbolLayer_H
#define QRT_VectorMarkerSymbolLayer_H

// C++ API headers
#include "MarkerSymbolLayer.h"
#include "VectorMarkerSymbolElement.h"
#include "VectorMarkerSymbolElementListModel.h"

// Qt headers
#include <QList>

namespace Esri {
namespace ArcGISRuntime {

  class VectorMarkerSymbolLayer : public MarkerSymbolLayer
  {
    Q_OBJECT

  public:
    explicit VectorMarkerSymbolLayer(const QList<VectorMarkerSymbolElement*>& vectorMarkerSymbolElements,
                                     QObject* parent = nullptr);
    ~VectorMarkerSymbolLayer() override;

    VectorMarkerSymbolElementListModel* vectorMarkerSymbolElements() const;

    /*! \internal */
    VectorMarkerSymbolLayer(std::shared_ptr<QRTImpl::SymbolLayerImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(VectorMarkerSymbolLayer)
    VectorMarkerSymbolLayer() = delete;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_VectorMarkerSymbolLayer_H
