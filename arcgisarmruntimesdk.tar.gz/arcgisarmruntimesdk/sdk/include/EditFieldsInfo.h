// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file EditFieldsInfo.h

#ifndef QRT_EditFieldsInfo_H
#define QRT_EditFieldsInfo_H

// Qt headers
#include <QString>

// STL headers
#include <memory>

namespace QRTImpl { class EditFieldsInfoImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class EditFieldsInfo
  {
  public:
    EditFieldsInfo();
    EditFieldsInfo(const EditFieldsInfo& other);
    EditFieldsInfo(EditFieldsInfo&& other) noexcept;
    ~EditFieldsInfo();

    EditFieldsInfo& operator=(const EditFieldsInfo& other);
    EditFieldsInfo& operator=(EditFieldsInfo&& other) noexcept;

    bool isEmpty() const;

    QString creationDateField() const;

    QString creatorField() const;

    QString editDateField() const;

    QString editorField() const;

    QString realm() const;

    explicit EditFieldsInfo(std::shared_ptr<QRTImpl::EditFieldsInfoImpl> impl);

  private:
    std::shared_ptr<QRTImpl::EditFieldsInfoImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_EditFieldsInfo_H
