// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file PortalItemCommentListModel.h

#ifndef QRT_PortalItemCommentListModel_H
#define QRT_PortalItemCommentListModel_H

// C++ API headers
#include "Deprecated.h"
#include "Error.h"
#include "Iterable.h"

// Qt headers
#include <QAbstractListModel>

namespace QRTImpl { class PortalItemCommentListImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class PortalItemComment;

  class PortalItemCommentListModel : public QAbstractListModel, Iterable<PortalItemComment*>
  {
    Q_OBJECT

  public:

    enum PortalItemCommentRoles
    {
      PortalItemCommentCommentRole = Qt::UserRole + 1, // read-only
      PortalItemCommentCommentIdRole = Qt::UserRole + 2, // read-only
      PortalItemCommentCreatedRole = Qt::UserRole + 3, // read-only
      PortalItemCommentOwnerRole = Qt::UserRole + 4  // read-only
    };

    ~PortalItemCommentListModel() override;

    bool isEmpty() const;

    QRT_DEPRECATED void clear();

    int size() const override;

    QRT_DEPRECATED void append(PortalItemComment* portalItemComment);

    QRT_DEPRECATED void insert(int index, PortalItemComment* portalItemComment);

    QRT_DEPRECATED void removeAt(int index);

    QRT_DEPRECATED void removeOne(PortalItemComment* portalItemComment);

    QRT_DEPRECATED void move(int from, int to);

    PortalItemComment* at(int index) const override;

    bool contains(PortalItemComment* portalItemComment) const;

    int indexOf(PortalItemComment* portalItemComment) const;

    PortalItemComment* first() const;

    PortalItemComment* last() const;

    Qt::ItemFlags flags(const QModelIndex& index) const override;

    int rowCount(const QModelIndex& parent = QModelIndex()) const override;

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override;

    bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

    /*!
       \internal
     */
    PortalItemCommentListModel(std::shared_ptr<QRTImpl::PortalItemCommentListImpl> impl, QObject* parent);

  signals:
    void errorOccurred(Esri::ArcGISRuntime::Error error);
    void portalItemCommentAdded(int index);
    void portalItemCommentRemoved(int index);

  protected:
    QHash<int, QByteArray> roleNames() const override;

  private:
    Q_DISABLE_COPY(PortalItemCommentListModel)

    PortalItemCommentListModel() = delete;
    void setupRoles();
    void connectSignals();

    QHash<int, QByteArray> m_roles;
    std::shared_ptr<QRTImpl::PortalItemCommentListImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_PortalItemCommentListModel_H
