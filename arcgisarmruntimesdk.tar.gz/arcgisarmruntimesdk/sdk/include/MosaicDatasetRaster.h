// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file MosaicDatasetRaster.h

#ifndef QRT_MosaicDatasetRaster_H
#define QRT_MosaicDatasetRaster_H

// C++ API headers
#include "AddRastersParameters.h"
#include "Geodatabase.h"
#include "Raster.h"
#include "SpatialReference.h"
#include "TaskWatcher.h"

namespace QRTImpl { class MosaicDatasetRasterImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class MosaicDatasetRaster : public Raster
  {
    Q_OBJECT

  public:
    MosaicDatasetRaster(const QString& path, const QString& tableName, QObject* parent = nullptr);
    ~MosaicDatasetRaster() override;

    QString tableName() const;

    TaskWatcher addRasters(const AddRastersParameters& parameters);

    static MosaicDatasetRaster* create(const QString& path, const QString& tableName,
                                       const SpatialReference& spatialReference, QObject* parent = nullptr);
    static MosaicDatasetRaster* create(Geodatabase* geodatabase, const QString& tableName,
                                       const SpatialReference& spatialReference, QObject* parent = nullptr);

    static void remove(Geodatabase* geodatabase, const QString& tableName);

    static QStringList tableNames(const QString& path);

    /*!
       \internal
     */
    MosaicDatasetRaster(std::shared_ptr<QRTImpl::MosaicDatasetRasterImpl> impl, QObject* parent);

  signals:
    void addRastersCompleted(QUuid taskId, Esri::ArcGISRuntime::Error error);

  private:
    Q_DISABLE_COPY(MosaicDatasetRaster)

    void connectSignals();
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_MosaicDatasetRaster_H
