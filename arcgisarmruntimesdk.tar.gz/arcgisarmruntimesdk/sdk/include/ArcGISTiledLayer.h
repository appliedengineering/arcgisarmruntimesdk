// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file ArcGISTiledLayer.h

#ifndef QRT_ArcGISTiledLayer_H
#define QRT_ArcGISTiledLayer_H

// C++ API headers
#include "ApiKeyResource.h"
#include "ArcGISMapServiceInfo.h"
#include "ArcGISSublayerListModel.h"
#include "Credential.h"
#include "ImageTiledLayer.h"
#include "Item.h"
#include "RemoteResource.h"
#include "TileCache.h"

// Qt headers
#include <QUrl>

namespace QRTImpl {
  class ArcGISTiledLayerImpl;
}

namespace Esri {
namespace ArcGISRuntime {

  class ArcGISTiledLayer : public ImageTiledLayer,
                           public ApiKeyResource,
                           public RemoteResource
  {
    Q_OBJECT

  public:
    explicit ArcGISTiledLayer(const QUrl& url, QObject* parent = nullptr);
    ArcGISTiledLayer(const QUrl& url, Credential* credential, QObject* parent = nullptr);
    explicit ArcGISTiledLayer(Item* item, QObject* parent = nullptr);
    explicit ArcGISTiledLayer(TileCache* tileCache, QObject* parent = nullptr);
    ~ArcGISTiledLayer() override;

    QList<ArcGISSublayer*> tiledSublayers() const;

    ArcGISMapServiceInfo mapServiceInfo() const;

    TileCache* tileCache() const;

    quint64 refreshInterval() const;
    void setRefreshInterval(quint64 milliseconds);

    // RemoteResource interface methods
    QUrl url() const override;
    Credential* credential() const override;
    RequestConfiguration requestConfiguration() const override;
    void setRequestConfiguration(const RequestConfiguration& requestConfiguration) override;

    // ApiKeyResource interface methods
    void setApiKey(const QString& apiKey) override;
    QString apiKey() const override;

    /*! \internal */
    ArcGISTiledLayer(std::shared_ptr<QRTImpl::ArcGISTiledLayerImpl> impl, QObject* parent);

  private:
    Q_DISABLE_COPY(ArcGISTiledLayer)
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_ArcGISTiledLayer_H
