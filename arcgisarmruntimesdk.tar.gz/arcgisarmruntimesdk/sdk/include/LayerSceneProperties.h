// COPYRIGHT 2021 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file LayerSceneProperties.h

#ifndef QRT_LayerSceneProperties_H
#define QRT_LayerSceneProperties_H

// C++ API headers
#include "SceneViewTypes.h"

// STL headers
#include <memory>

namespace QRTImpl { class LayerScenePropertiesImpl; }

namespace Esri {
namespace ArcGISRuntime {

  class LayerSceneProperties
  {
  public:
    LayerSceneProperties();
    LayerSceneProperties(SurfacePlacement surfacePlacement);
    LayerSceneProperties(const LayerSceneProperties& other);
    LayerSceneProperties(LayerSceneProperties&& other) noexcept;
    ~LayerSceneProperties();

    LayerSceneProperties& operator=(const LayerSceneProperties& other);
    LayerSceneProperties& operator=(LayerSceneProperties&& other) noexcept;

    bool isEmpty() const;

    SurfacePlacement surfacePlacement() const;
    void setSurfacePlacement(SurfacePlacement surfacePlacement);

    double altitudeOffset() const;
    void setAltitudeOffset(double altitudeOffset);

    /*! \internal */
    explicit LayerSceneProperties(const std::shared_ptr<QRTImpl::LayerScenePropertiesImpl>& impl);
    /*! \internal */
    std::shared_ptr<QRTImpl::LayerScenePropertiesImpl> getImpl() const;

  private:
    std::shared_ptr<QRTImpl::LayerScenePropertiesImpl> m_impl;
  };

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_LayerSceneProperties_H
