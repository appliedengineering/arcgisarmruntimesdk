// COPYRIGHT 2021 ESRI
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file Geotrigger.h

#ifndef QRT_Geotrigger_H
#define QRT_Geotrigger_H

// C++ API headers
#include "Object.h"

namespace QRTImpl { class GeotriggerImpl; }

namespace Esri {
namespace ArcGISRuntime {

class ArcadeExpression;
class GeotriggerFeed;
enum class GeotriggerType;

class Geotrigger : public Object
{
  Q_OBJECT
public:
  ~Geotrigger() override;

  GeotriggerFeed* feed() const;

  ArcadeExpression* messageExpression() const;
  void setMessageExpression(ArcadeExpression* messageExpression);

  QString name() const;
  void setName(const QString& name);

  GeotriggerType geotriggerType() const;

  QString geotriggerId() const;

  /*! internal */
  std::shared_ptr<QRTImpl::GeotriggerImpl> getImpl() const;

protected:
  Geotrigger(std::shared_ptr<QRTImpl::GeotriggerImpl> impl, QObject* parent);

  std::shared_ptr<QRTImpl::GeotriggerImpl> m_impl;
private:
  Q_DISABLE_COPY(Geotrigger)
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_Geotrigger_H
