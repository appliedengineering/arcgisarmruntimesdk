// COPYRIGHT 2021 ESRI
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// This material is licensed for use under the Esri Master License
// Agreement (MLA), and is bound by the terms of that agreement.
// You may redistribute and use this code without modification,
// provided you adhere to the terms of the MLA and include this
// copyright notice.
//
// See use restrictions at http://www.esri.com/legal/pdfs/mla_e204_e300/english
//
// For additional information, contact:
// Environmental Systems Research Institute, Inc.
// Attn: Contracts and Legal Services Department
// 380 New York Street
// Redlands, California, 92373
// USA
//
// email: contracts@esri.com
/// \file FeatureFenceParameters.h

#ifndef QRT_FeatureFenceParameters_H
#define QRT_FeatureFenceParameters_H

// C++ API headers
#include "FenceParameters.h"
#include "Geometry.h"

namespace QRTImpl { class FeatureFenceParametersImpl; }

namespace Esri {
namespace ArcGISRuntime {

class FeatureTable;

class FeatureFenceParameters : public FenceParameters
{
  Q_OBJECT
public:
  explicit FeatureFenceParameters(FeatureTable* featureTable, QObject* parent = nullptr);

  FeatureFenceParameters(FeatureTable* featureTable, double bufferDistance, QObject* parent = nullptr);

  ~FeatureFenceParameters() override;

  FeatureTable* featureTable() const;

  QString whereClause() const;
  void setWhereClause(const QString& whereClause);

  Geometry areaOfInterest() const;
  void setAreaOfInterest(const Geometry& areaOfInterest);

  FeatureFenceParameters(std::shared_ptr<QRTImpl::FenceParametersImpl> impl, QObject* parent);

  std::shared_ptr<QRTImpl::FeatureFenceParametersImpl> getImpl() const;

private:
  Q_DISABLE_COPY(FeatureFenceParameters)
};

} // namespace ArcGISRuntime
} // namespace Esri

#endif // QRT_FeatureFenceParameters_H
